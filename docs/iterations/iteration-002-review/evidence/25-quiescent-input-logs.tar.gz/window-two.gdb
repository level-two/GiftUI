set pagination off
set confirm off
target remote localhost:2331
monitor halt
break service
continue
set $prior=(unsigned int)giftui_signal_analyzer_current_revision()
set $enabled=(unsigned int)giftui_signal_analyzer_action_point(4)
set $point=$enabled
printf "BEFORE window-two revision=%u point=%u enabled=%u\n",$prior,$point,$enabled
set $observed=$prior
p (int)giftui_signal_analyzer_input_admit(0,$point&65535,$point>>16,$observed,1)
p (int)giftui_signal_analyzer_input_admit(2,$point&65535,$point>>16,$observed,0)
set $attempt=0
continue
set $pending=(unsigned short)giftui_signal_analyzer_input_pending_count()
while $pending>0 && $attempt<50
set $attempt=$attempt+1
continue
set $pending=(unsigned short)giftui_signal_analyzer_input_pending_count()
end
set $revision=(unsigned int)giftui_signal_analyzer_current_revision()
set $state=(unsigned int)giftui_signal_analyzer_acquisition_state()
set $capture=(unsigned int)giftui_signal_analyzer_capture_count()
set $actions=(unsigned short *)(production.regions.profile+3024+72)
printf "AFTER window-two revision=%u state=%u pending=%u capture=%u actions=%u,%u,%u\n",$revision,$state,$pending,$capture,$actions[0],$actions[1],$actions[2]
p fault_counts
x/3wx 0xE000ED28
delete breakpoints
monitor go
detach
