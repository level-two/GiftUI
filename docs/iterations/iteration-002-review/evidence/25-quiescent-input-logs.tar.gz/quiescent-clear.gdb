set pagination off
set confirm off
target remote localhost:2331
monitor halt
info registers pc sp
break service
continue
printf "QUIESCENT SERVICE BOUNDARY BEFORE CLEAR\n"
p (unsigned int)giftui_signal_analyzer_acquisition_state()
p (unsigned int)giftui_signal_analyzer_current_revision()
set $point=(unsigned int)giftui_signal_analyzer_action_point(2)
set $revision=(unsigned int)giftui_signal_analyzer_current_revision()
printf "CLEAR point=%u revision=%u\n", $point, $revision
if $point != 0
p (int)giftui_signal_analyzer_input_admit(0,$point&65535,$point>>16,$revision,1)
p (int)giftui_signal_analyzer_input_admit(2,$point&65535,$point>>16,$revision,0)
end
p (unsigned short)giftui_signal_analyzer_input_pending_count()
continue
printf "QUIESCENT SERVICE BOUNDARY AFTER CLEAR\n"
p (unsigned int)giftui_signal_analyzer_acquisition_state()
p (unsigned int)giftui_signal_analyzer_current_revision()
p (unsigned short)giftui_signal_analyzer_input_pending_count()
p (unsigned int)giftui_signal_analyzer_capture_count()
p (unsigned int)giftui_signal_analyzer_visible_window()
p fault_counts
x/3wx 0xE000ED28
delete breakpoints
monitor go
detach
