set pagination off
target remote localhost:2331
monitor halt
info registers pc sp
if $pc == 0x2473c
error Reset handler is not a valid ready application
end
p production
p (unsigned int)giftui_signal_analyzer_current_revision()
p (unsigned int)giftui_signal_analyzer_acquisition_state()
p (unsigned int)giftui_signal_analyzer_capture_count()
p (unsigned int)giftui_signal_analyzer_last_drawing_points()
dump binary memory .build/nrf52840/iteration-002-connected/acquisition-prefix.bin 0x20001488 0x20001588
p fault_counts
x/3wx 0xE000ED28
monitor go
detach
