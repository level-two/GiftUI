set pagination off
target remote localhost:2331
monitor reset
monitor halt
info registers pc sp
restore .build/nrf52840/iteration-002-connected/stack-paint.bin binary 0x20027e80
monitor go
detach
