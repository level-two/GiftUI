set pagination off
target remote localhost:2331
monitor halt
info registers pc sp
p z_main_thread.stack_info
monitor go
detach
