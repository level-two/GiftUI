set pagination off
target remote localhost:2331
monitor halt
p production
p (unsigned int)giftui_signal_analyzer_current_revision()
p (unsigned int)giftui_signal_analyzer_acquisition_state()
dump binary memory .build/nrf52840/iteration-002-connected/idle-stack.bin 0x20027e80 0x2002ea80
set $point=(unsigned int)giftui_signal_analyzer_action_point(0)
set $revision=(unsigned int)giftui_signal_analyzer_current_revision()
printf "SOFTWARE START point=%u revision=%u\n", $point, $revision
if $point != 0
p (int)giftui_signal_analyzer_input_admit(0,$point&65535,$point>>16,$revision,0)
p (int)giftui_signal_analyzer_input_admit(2,$point&65535,$point>>16,$revision,0)
end
p (unsigned short)giftui_signal_analyzer_input_pending_count()
p fault_counts
x/3wx 0xE000ED28
monitor go
detach
