from pathlib import Path
import tempfile,tarfile,subprocess,shutil
root=Path.cwd(); refs=root/'Tests/ContractFixtures/SPEC001/PixelReferences'; archive=root/'Tests/ContractFixtures/SPEC001/Evidence/milestone-10/pixel-review/recording-candidates.tar.gz'
with tempfile.TemporaryDirectory(prefix='giftui-pixel-review-',dir='/private/tmp') as tmp:
 base=Path(tmp)
 with tarfile.open(archive) as t:
  for m in t.getmembers():
   if '/captures/' in m.name and m.name.endswith('.rgb565'):
    p=base/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
 for profile,case in [('pi','pi-stopped-physical'),('nrf','nrf-diagnostic')]:
  changed=base/(profile+'-refs');shutil.copytree(refs,changed)
  p=changed/(case+'.rgb565');b=bytearray(p.read_bytes());b[0]^=1;p.write_bytes(b)
  images=base/(profile+'-images')
  r=subprocess.run(['python3',str(root/'scripts/contracts/render-spec-001-rasters.py'),'--profile',profile,'--captures',str(base/profile/'captures'),'--images',str(images),'--include-diagnostic','--references',str(changed)],capture_output=True,text=True)
  assert r.returncode==1,(case,r.stderr)
  assert 'raster_mismatch='+case in r.stderr,r.stderr
  assert (images/(case+'-diff.png')).exists(),case
  print(f'negative={case}; corrupted-byte=rejected; diff-image=created; status=pass')
