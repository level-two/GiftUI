set pagination off
target remote localhost:2331
set $point=(unsigned int)giftui_signal_analyzer_action_point(0)
set $x=$point&65535
set $y=$point>>16
set $revision=(unsigned int)giftui_signal_analyzer_current_revision()
printf "Start point=%u x=%u y=%u revision=%u\n",$point,$x,$y,$revision
p (int)giftui_signal_analyzer_input_admit(0,$x,$y,$revision,0)
p (int)giftui_signal_analyzer_input_admit(2,$x,$y,$revision,0)
p (unsigned short)giftui_signal_analyzer_input_pending_count()
break service
ignore 1 3500
continue
p (unsigned int)giftui_signal_analyzer_current_revision()
p (unsigned int)giftui_signal_analyzer_acquisition_state()
p (unsigned int)giftui_signal_analyzer_capture_count()
p (unsigned int)giftui_signal_analyzer_last_drawing_points()
p (unsigned short)giftui_signal_analyzer_input_pending_count()
set $point=(unsigned int)giftui_signal_analyzer_action_point(1)
set $revision=(unsigned int)giftui_signal_analyzer_current_revision()
p (int)giftui_signal_analyzer_input_admit(0,$point&65535,$point>>16,$revision,0)
p (int)giftui_signal_analyzer_input_admit(2,$point&65535,$point>>16,$revision,0)
ignore 1 100
continue
p (unsigned int)giftui_signal_analyzer_acquisition_state()
p (unsigned int)giftui_signal_analyzer_capture_count()
p (unsigned short)giftui_signal_analyzer_input_pending_count()
detach
