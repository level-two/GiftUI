from pathlib import Path
import hashlib, subprocess, json, re

root=Path('.build/closeout-20261003')
packet=Path('Tests/ContractFixtures/SPEC001/Evidence/milestone-10/iteration-closeout-20261003')
link='../../Tests/ContractFixtures/SPEC001/Evidence/milestone-10/iteration-closeout-20261003/README.md'
rows=[]
for line in (root/'repository-gate-final.log').read_text().splitlines():
    if line.startswith('pass: '): rows.append((line[6:],0))
    elif line.startswith('fail: '): raise RuntimeError(line)
assert len(rows)==72 and len({row[0] for row in rows})==72
(packet/'gate-ledger.tsv').write_text('check\texit_code\tevidence\n'+''.join(f'{name}\t{code}\trepository-gate-final.log\n' for name,code in rows))
inventory=[]
for folder in ['Sources','firmware','scripts']:
    for path in sorted(Path(folder).rglob('*')):
        if path.is_file() and not path.is_symlink() and path.name not in ['local.env']:
            inventory.append(f'{hashlib.sha256(path.read_bytes()).hexdigest()}\t{path}\n')
(root/'source-hashes.tsv').write_text('sha256\tpath\n'+''.join(inventory))
(root/'gate-final-identity.json').write_text(json.dumps({'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), 'checks':72,'failed':0,'console_sha256':hashlib.sha256((root/'repository-gate-final.log').read_bytes()).hexdigest(),'shared_metadata_note':'earlier sandboxed invocation interleaved with the initial portion; derive final ledger from separate final console log'},indent=2)+'\n')

def update(path, section, complete=False):
    path=Path(path); content=path.read_text()
    content=re.sub(r'^updated: .*$', 'updated: 2026-10-03', content, count=1, flags=re.M)
    if complete: content=re.sub(r'^status: (collecting|review)$','status: complete',content,count=1,flags=re.M)
    if section not in content: content+='\n'+section+'\n'
    path.write_text(content)

owner=f'''## Current final-artifact gate review — 2026-10-03

The [iteration closeout]({link}) records a complete final invocation of the
registered hardware-free gate: 72 checks pass, including this owner's four
profiles, current application integration, selected-runtime isolation, fault
corpora and reviewed pixel comparisons. This supersedes the earlier recorded
sandbox/profile failures and resolved production-join blockers for these
tested inputs; historical reports retain their original scope.

The criterion evidence has been reviewed against the current approved contract;
all existing owner acceptance rows retain their passing dispositions for the
applicable corpus. No new contract, exception, connected-hardware claim or
Specification status transition is inferred. The report is complete and
supports requesting an explicit human `implemented` transition for this owner.
'''
for number in [2,3,4,5,6,9,10,12,13,14]:
    paths=list(Path('docs/conformance').glob(f'spec-{number:03d}-conformance*.md'))
    assert len(paths)==1
    update(paths[0],owner,complete=True)

for number in [1,11,15]:
    paths=list(Path('docs/conformance').glob(f'spec-{number:03d}-conformance*.md'))
    section=f'''## Current connected closeout and maintainer dispositions — 2026-10-03

The [final-artifact closeout]({link}) supersedes earlier claims that no
production artifact was deployed/flashed or that calibration is provisional.
The maintainer explicitly confirmed touch calibration; that subtask is complete.
Pi timing work is postponed under FW-027, and macOS physical-pointer work is
postponed under FW-031. Neither postponement is an acceptance-criterion waiver.

All 72 final registered hardware-free checks pass, including this owner's four
profiles and current production-join/pixel evidence. The final Pi hash is
verified on the target. Its 32 measured updates average approximately 0.72
frames/second, with 1.294–1.522-second costs and 9,740 KiB peak sampled RSS;
bounded SIGINT teardown prints `status=completed`. The cleaned final nRF image
is flashed and running. Its recorded software Start succeeds, driver/CPU fault
samples are zero, and nine live records match the deterministic source prefix.
Observed presentation intervals of approximately 21 seconds fail cadence.

Complete connected physical/failure coverage, sustained 80-Hz acceptance,
target costs and full connected semantic/action/drawing trace comparison remain
unproved. The macOS physical-pointer subset is explicitly postponed. The
Specification and connected plan remain implementing/active; this complete
evidence disposition does not support a full `implemented` transition.
'''
    update(paths[0],section,complete=True)

for number in [4,13]:
    update(f'docs/implementation-plans/spec-{number:03d}-implementation-plan.md',f'''## Final owner-task reconciliation — 2026-10-03

Every planned owner task, including the amendment tasks where applicable, has
a completed disposition. The [72-check final gate]({link}) revalidates all four
owner profiles and actual production joins. The plan is `completed`; no
Specification `implemented` transition is performed by this reconciliation.
''')

update('docs/implementation-plans/spec-001-implementation-plan.md',f'''## Current iteration closeout — 2026-10-03

The [final-artifact packet]({link}) records 72 passing registered checks, both
verified target builds, final Pi deployment and nRF flashing, bounded connected
observations, source-prefix comparison and explicit remaining failures.

- Touch calibration is **complete**, explicitly confirmed by the maintainer.
- The Pi timing fix is postponed to the next iterations under FW-027; its
  measured cadence remains nonconforming and is not marked complete.
- The macOS physical-pointer campaign is postponed under FW-031.
- T8.1 retains unmet cadence and complete interaction/recovery/trace evidence.
- T8.2 retains unmet cadence, sustained-load and complete connected corpus.
- T8.3 has only a passing nRF deterministic capture-prefix comparison; full
  semantic/action/drawing equality remains open.

The final current criterion disposition is 41 scoped passes, two failures
(SA-AC-023/039 timing), and two blocked connected criteria (SA-AC-005/024).
Earlier tables and appendices remain historical where this record supersedes
them. The plan remains active and SPEC-001 remains implementing.
''')
update('docs/implementation-plans/spec-011-implementation-plan.md',f'''## Current connected campaign disposition — 2026-10-03

The [final-artifact packet]({link}) records all four passing owner profiles and
final target artifacts. Touch calibration is complete by explicit maintainer
confirmation. T9.3's macOS physical-pointer portion is postponed under FW-031;
its remaining Pi interaction corpus and T9.4's complete nRF physical/failure
corpus remain open. Existing physical control signoffs and new software-action
observations are preserved with their distinct scope. The plan remains active;
the connected gate is not waived by 72 passing hardware-free checks.
''')
update('docs/implementation-plans/spec-015-implementation-plan.md',f'''## Current assembled closeout — 2026-10-03

The [72-check final gate and connected packet]({link}) supersede historical
production-join/profile failures. Calibration is complete by explicit maintainer
confirmation; final Pi/nRF artifacts are deployed/flashed and identified.
Pi and nRF cadence measurements fail, and complete physical/fault/trace evidence
is absent. The assembled connected gate remains open. The plan stays active and
SPEC-015 implementing; work postponement is not an approved timing exception.
''')

path=Path('docs/conformance/spec-001-conformance.md'); content=path.read_text()
notes={
'SA-AC-005':('blocked','Reviewed host pixels pass and prior target display/control approvals are retained; complete final connected screen/input coverage is still open.'),
'SA-AC-023':('fail','Final ARMv6 artifact deployed and hash verified; 32 updates measure 0.72335 frames/second and 1.294–1.522-second costs. Display/control signoff is retained; timing work is explicitly postponed, without waiver.'),
'SA-AC-024':('blocked','Clean final firmware flashed; calibration confirmed, software Start accepted and live execution measured. Complete final physical interaction/display/failure corpus remains uncollected; cadence is separately failing.'),
'SA-AC-025':('pass','Historical painted stack-fit case passes within its recorded scope. Final firmware builds and runs at 191,104-byte RAM/275,600-byte flash; no current high-water is inferred from the unpainted diagnostic dump.'),
'SA-AC-039':('fail','Current firmware ABI/storage/build evidence passes, but approximately 21-second connected presentation intervals fail cadence. Compliant sustained admission/mutation/publication/frame timing remains unproved.')}
for criterion,(status,note) in notes.items():
    pattern=rf'^\| `{criterion}` \|.*$'
    replacement=f'| `{criterion}` | {status} | [current connected packet]({link}) | {note} |'
    content,count=re.subn(pattern,replacement,content,count=1,flags=re.M)
    assert count==1,criterion
path.write_text(content)

for number in [1,11]:
    path=Path(f'docs/implementation-plans/spec-{number:03d}-implementation-plan.md'); text=path.read_text()
    if number==1:
        marker='- [ ] `T8.2` — After explicit authorization, inspect and flash the exact `T6.5`'
        text=text.replace(marker,'- [ ] `T8.2` — **Current calibration subtask complete:** maintainer confirmation on 2026-10-03. Final firmware is flashed; full cadence/physical/fault corpus remains open. After explicit authorization, inspect and flash the exact `T6.5`',1)
    else:
        marker='- [ ] `T9.4` — With explicit authorization, build, inspect, flash, and exercise'
        text=text.replace(marker,'- [ ] `T9.4` — **Current calibration subtask complete:** maintainer confirmation on 2026-10-03. Final firmware is flashed; full physical/fault corpus remains open. With explicit authorization, build, inspect, flash, and exercise',1)
    path.write_text(text)

path=Path('docs/features.yaml'); content=path.read_text().replace('# Pi display/control signoff verified 2026-10-03; timing/recovery and full connected gates remain open.','# Pi display/control and nRF calibration confirmed 2026-10-03; full connected gates remain open.\n  # Pi timing is postponed under FW-027; current nRF cadence also fails.').replace('# Component distribution/integration review: FW-016 and FW-030; no split approved.','# Component distribution/integration review: FW-016 and FW-030; no split approved.\n    # macOS physical-pointer validation is postponed under FW-031.')
path.write_text(content)
