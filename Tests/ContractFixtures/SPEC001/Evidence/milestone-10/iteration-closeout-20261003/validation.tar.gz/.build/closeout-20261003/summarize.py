import json, re, pathlib, datetime, struct, statistics

root=pathlib.Path('.build/closeout-20261003')
pi=[json.loads(line) for line in (root/'pi-final-connected.jsonl').read_text().splitlines()]
frames=[row for row in pi if row['kind']=='trace' and row['line'].startswith('pi-frame-duration-us ')]
costs=[int(row['line'].split()[-1]) for row in frames]
times=[datetime.datetime.fromisoformat(row['utc']) for row in frames]
rss=[]
for row in pi:
    for value in row.get('rows',[]):
        if ' SignalAnalyzerR ' in value:
            rss.append(int(value.split()[2]))
summary={'pi':{'identity':pi[0], 'frames_observed':len(frames), 'frame_cost_us_min':min(costs), 'frame_cost_us_median':statistics.median(costs), 'frame_cost_us_max':max(costs), 'observed_frames_per_second':(len(times)-1)/(times[-1]-times[0]).total_seconds(), 'peak_sampled_rss_kib':max(rss), 'exit':pi[-1], 'cadence_pass':False, 'application_teardown':any(row.get('line')=='status=completed' for row in pi)}}
lines=(root/'acquisition/nrf-monitor.log').read_text().splitlines()
revisions=[]; faults=[]; cpu=[]
for line in lines:
    match=re.search(r'200009C0 = ([0-9A-F ]+)',line)
    if match:
        words=match[1].split()
        revision=int(words[2],16)
        if not revisions or revision!=revisions[-1]['revision']:
            revisions.append({'utc':line.split()[0], 'revision':revision})
    if '20027300 = ' in line or '20027310 = ' in line:
        faults.extend(int(word,16) for word in line.split(' = ')[1].split())
    if 'E000ED28 = ' in line:
        cpu.extend(int(word,16) for word in line.split(' = ')[1].split()[:2])
stack=(root/'nrf-main-stack.bin').read_bytes()
untouched=0
for byte in stack:
    if byte!=0xaa: break
    untouched+=1
capture=(root/'nrf-capture.bin').read_bytes()
records=[]
for index in range(9):
    seconds,packed=struct.unpack_from('<qQ',capture,index*16)
    records.append({'milliseconds':seconds*1000+(packed&((1<<60)-1))//10**15,'channel':(packed>>60)&7,'level':packed>>63})
expected=[{'milliseconds':0,'channel':channel,'level':0} for channel in range(1,5)]
seed=0x5eed
def interval():
    global seed
    seed=(seed*6364136223846793005+1)&((1<<64)-1)
    return 180+seed%420
nexts=[250,400,80,interval()]; levels=[0]*4; ch3=[80,80,80,1200,75,75,900]; ch3_index=1
for index in range(5):
    channel=min(range(4),key=lambda key:nexts[key])
    timestamp=nexts[channel]; levels[channel]^=1
    expected.append({'milliseconds':timestamp,'channel':channel+1,'level':levels[channel]})
    if channel==0: nexts[channel]+=250
    elif channel==1: nexts[channel]+=400
    elif channel==2:
        nexts[channel]+=ch3[ch3_index]; ch3_index=(ch3_index+1)%7
    else: nexts[channel]+=interval()
identity=json.loads((root/'acquisition/nrf-monitor-identity.json').read_text())
identity['requested_sample_count']=600
identity['requested_sleep_seconds']=60
identity['kind']='connected-target nonhalting SWD reads; host timestamps include probe overhead'
summary['nrf']={'identity':identity, 'presentation_changes':revisions, 'nonhalting_sample_count':sum('200009C0 = ' in line for line in lines), 'driver_faults_observed':sorted(set(faults)), 'cfsr_hfsr_observed':sorted(set(cpu)), 'stack_high_water_bytes':None, 'stack_measurement_note':'Single-thread Zephyr stack was not sentinel-painted; raw dump cannot establish high-water. Preserve historical painted measurement separately.', 'stack_reserved_bytes':len(stack), 'live_capture_prefix':records, 'expected_deterministic_prefix':expected, 'capture_prefix_matches':records==expected, 'cadence_pass':False, 'scope':'SWD timing and debugger-injected Start; halted snapshot has running state, capture count 9 and 40 drawing points; full connected corpus uncollected'}
(root/'measurements.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
