import subprocess, time, json, datetime, threading

print(json.dumps({'kind':'identity', 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'arch':subprocess.check_output(['uname','-m'],text=True).strip(), 'binary':subprocess.check_output(['sha256sum','/home/giftui/giftui/bin/SignalAnalyzerRaspberryPiARMv6'],text=True).strip()}), flush=True)
command=['sudo','-n','env','GIFTUI_PI_TRACE=1','SWIFT_BACKTRACE=enable=yes','timeout','--signal=INT','--kill-after=10','45','stdbuf','-oL','-eL','/home/giftui/giftui/bin/SignalAnalyzerRaspberryPiARMv6','--run-signal-analyzer']
p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
def output():
    for line in p.stdout:
        print(json.dumps({'kind':'trace','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'line':line.rstrip()}),flush=True)
thread=threading.Thread(target=output)
thread.start()
start=time.monotonic()
while p.poll() is None:
    result=subprocess.run(['ps','-eo','pid,ppid,rss,pcpu,comm,args'],capture_output=True,text=True)
    rows=[line for line in result.stdout.splitlines() if 'SignalAnalyzerRaspberryPiARMv6' in line and 'python' not in line]
    print(json.dumps({'kind':'process','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'rows':rows}),flush=True)
    time.sleep(1)
thread.join()
print(json.dumps({'kind':'exit','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start}),flush=True)
