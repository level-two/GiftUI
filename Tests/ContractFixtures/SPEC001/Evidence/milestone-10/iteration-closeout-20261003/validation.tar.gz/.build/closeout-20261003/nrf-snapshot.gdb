set pagination off
target remote localhost:2331
printf "HALTED SNAPSHOT: excluded from continuous cadence measurement\n"
p production
p (unsigned int)giftui_signal_analyzer_current_revision()
p (unsigned int)giftui_signal_analyzer_acquisition_state()
p (unsigned int)giftui_signal_analyzer_capture_count()
p (unsigned int)giftui_signal_analyzer_last_drawing_points()
p (unsigned short)giftui_signal_analyzer_input_pending_count()
p fault_counts
x/3wx 0xE000ED28
dump binary memory .build/closeout-20261003/nrf-profile.bin production.regions.profile ((char*)production.regions.profile+39696)
dump binary memory .build/closeout-20261003/nrf-capture.bin production.regions.capture ((char*)production.regions.capture+115392)
dump binary memory .build/closeout-20261003/nrf-main-stack.bin 0x20027e40 (0x20027e40+27648)
set $point=(unsigned int)giftui_signal_analyzer_action_point(1)
set $revision=(unsigned int)giftui_signal_analyzer_current_revision()
printf "software_stop_point=%u revision=%u\n", $point, $revision
if $point != 0
p (int)giftui_signal_analyzer_input_admit(0,$point&65535,$point>>16,$revision,0)
p (int)giftui_signal_analyzer_input_admit(2,$point&65535,$point>>16,$revision,0)
end
monitor go
detach
