from pathlib import Path
import tarfile, hashlib, shutil

root=Path('.build/closeout-20261003')
packet=Path('Tests/ContractFixtures/SPEC001/Evidence/milestone-10/iteration-closeout-20261003')
destination=root/'driver-logs'
destination.mkdir(exist_ok=True)
for path in Path('.build/test-reports/all-hardware-free/logs').iterdir():
    if path.is_file(): shutil.copy2(path,destination/path.name)
archive=packet/'validation.tar.gz'
with tarfile.open(archive,'w:gz') as output:
    output.add(root,arcname=str(root))
    for path in [Path('scripts/contracts/run-spec-001.sh'), Path('scripts/contracts/run-spec-015.sh'), packet/'README.md', packet/'measurements.json', packet/'gate-ledger.tsv']:
        output.add(path,arcname=str(path))
(packet/'archive.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  validation.tar.gz\n')
print(f'ARCHIVE={archive} BYTES={archive.stat().st_size}')
