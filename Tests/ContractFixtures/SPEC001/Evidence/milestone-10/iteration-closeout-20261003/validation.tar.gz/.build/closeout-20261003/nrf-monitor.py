import subprocess, time, re, json, datetime, pathlib, hashlib, sys

root = pathlib.Path('.build/closeout-20261003')
if len(sys.argv) > 1:
    root = root / sys.argv[1]
    root.mkdir(exist_ok=True)
elf = pathlib.Path('.build/nrf52840/signal-analyzer-static/zephyr/zephyr.elf')
nm = subprocess.check_output(['.toolchains/nrf52840/zephyr-sdk-0.17.4/arm-zephyr-eabi/bin/arm-zephyr-eabi-nm', '-n', str(elf)], text=True)
symbols = {line.split()[-1]: int(line.split()[0], 16) for line in nm.splitlines() if len(line.split()) == 3}
production = symbols['production']
fault = symbols['fault_counts']
commands = ['connect', 'go']
for index in range(int(sys.argv[2]) if len(sys.argv) > 2 else 1800):
    commands += [f'mem32 0x{production+48:08X}, 10', f'mem32 0x{fault:08X}, 5', 'mem32 0xE000ED28, 3', 'mem32 0xE000EDF0, 1', 'sleep 100']
commands += ['q']
(root/'nrf-monitor.jlink').write_text('\n'.join(commands)+'\n')
(root/'nrf-monitor-identity.json').write_text(json.dumps({'elf_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(), 'production':production, 'fault_counts':fault, 'kind':'connected-target nonhalting SWD reads; 45-second requested sampling window; host timestamps include probe overhead', 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2))
p = subprocess.Popen(['JLinkExe', '-device', 'NRF52840_XXAA', '-if', 'SWD', '-speed', '4000', '-autoconnect', '1', '-CommanderScript', str(root/'nrf-monitor.jlink')], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
with (root/'nrf-monitor.log').open('w') as log:
    for line in p.stdout:
        log.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+' '+line)
        log.flush()
raise SystemExit(p.wait())
