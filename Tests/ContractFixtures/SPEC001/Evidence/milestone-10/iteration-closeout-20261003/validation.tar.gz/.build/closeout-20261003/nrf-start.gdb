set pagination off
target remote localhost:2331
printf "CONNECTED SOFTWARE ACTION: debugger injection, not physical touch\n"
p production
p (unsigned int)giftui_signal_analyzer_acquisition_state()
set $point=(unsigned int)giftui_signal_analyzer_action_point(0)
set $revision=(unsigned int)giftui_signal_analyzer_current_revision()
printf "start_point=%u revision=%u\n", $point, $revision
if $point != 0
p (int)giftui_signal_analyzer_input_admit(0,$point&65535,$point>>16,$revision,0)
p (int)giftui_signal_analyzer_input_admit(2,$point&65535,$point>>16,$revision,0)
end
p (unsigned short)giftui_signal_analyzer_input_pending_count()
p fault_counts
monitor go
detach
