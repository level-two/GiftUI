from pathlib import Path
import re

packet=Path('Tests/ContractFixtures/SPEC001/Evidence/milestone-10/iteration-closeout-20261003')
link='../../Tests/ContractFixtures/SPEC001/Evidence/milestone-10/iteration-closeout-20261003/README.md'
for number in [1,13,15]:
    path=Path(f'docs/conformance/spec-{number:03d}-conformance.md')
    content=path.read_text()
    title=f'# SPEC-{number:03d} Conformance Report\n'
    if number==1:
        note=f'\n> **Current disposition — 2026-10-03:** [Final-artifact closeout]({link}): 41 scoped passes, two timing failures and two connected-evidence blockers. Calibration is confirmed. Pi timing and macOS pointer work are postponed without waiver. The final current-artifact startup/idle stack measurement is 19,480 / 27,648 bytes. Historical sections below retain their original scope.\n'
    elif number==13:
        note=f'\n> **Current disposition — 2026-10-03:** [Final owner review]({link}) closes the amended seam and production-join applicability blockers. All four owner profiles and the complete 72-check gate pass; all owner task dispositions are complete. The Specification awaits explicit human transition authorization.\n'
    else:
        note=f'\n> **Current disposition — 2026-10-03:** [Final-artifact closeout]({link}) revalidates the approved seam and all four hardware-free profiles. Calibration is confirmed and final artifacts are deployed/flashed. Connected cadence and complete physical/fault/trace coverage remain open.\n'
    content=content.replace(title,title+note,1)
    content=content.replace('**Current applicability — 2026-10-02:**','**Historical amendment applicability — 2026-10-02:**')
    content=content.replace('Final firmware builds and runs at 191,104-byte RAM/275,600-byte flash; no current high-water is inferred from the unpainted diagnostic dump.','Final firmware builds and runs at 191,104-byte RAM/275,600-byte flash; fresh painted startup/idle stack high-water is 19,480 / 27,648 bytes. The unpainted diagnostic dump is excluded.')
    path.write_text(content.rstrip()+'\n')

for number in [4,13]:
    path=Path(f'docs/implementation-plans/spec-{number:03d}-implementation-plan.md')
    content=re.sub(r'^updated: .*$', 'updated: 2026-10-03',path.read_text(),count=1,flags=re.M)
    path.write_text(content)

for number,tasks in [(1,['T8.1','T8.2','T8.3','T10.8']), (11,['T9.3','T9.4'])]:
    path=Path(f'Tests/ContractFixtures/SPEC{number:03d}/task-evidence.yaml')
    lines=path.read_text().splitlines()
    files=[str(p) for p in sorted(packet.iterdir()) if p.is_file()]
    # Include the packet and digest after the archive is written, too.
    files += [str(packet/'validation.tar.gz'),str(packet/'archive.sha256')]
    files=list(dict.fromkeys(files))
    for index,line in enumerate(lines):
        if any(line.startswith('  '+task+': ') for task in tasks):
            current=next(task for task in tasks if line.startswith('  '+task+': '))
            old=re.search(r'evidence: \[(.*?)\]',line).group(1)
            existing=[value.strip().strip('"') for value in old.split(',') if value.strip()]
            merged=list(dict.fromkeys(existing+files))
            line=re.sub(r'evidence: \[.*?\]','evidence: ['+', '.join(merged)+']',line,count=1)
            if current!='T10.8':
                line=line.replace('disposition: pending','disposition: blocked')
                line=re.sub(r'blockers: \[.*?\]','blockers: ['+str(packet/'README.md')+']',line,count=1)
            lines[index]=line
    path.write_text('\n'.join(lines)+'\n')

for number in [1,11,15]:
    path=Path(f'docs/conformance/spec-{number:03d}-conformance.md')
    text=path.read_text()
    text+='\n## Final current-artifact stack case — 2026-10-03\n\nThe [painted final-firmware snapshot]('+link+') measures 19,480 / 27,648 bytes after startup/idle, with zero driver/CFSR/HFSR faults and production revision 1. This closes the current startup/idle measurement subcase; it does not establish sustained-load timing or exhaustive worst-case stack use.\n'
    path.write_text(text.rstrip()+'\n')
