; ModuleID = '/Users/eugene/work/GiftUI/.build/contract-reports/spec-013/amended-carriers/nrf52840-embedded/carriers.ll'
source_filename = "/Users/eugene/work/GiftUI/.build/contract-reports/spec-013/amended-carriers/nrf52840-embedded/carriers.ll"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "thumbv7em-none-none-eabihf"

%TSi = type <{ i32 }>
%T17GiftUIRuntimeCore29RuntimePipelineMutationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [3 x i8], [1 x i8] }>
%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [2 x i8] }>
%T17GiftUIRuntimeCore32RuntimePipelinePublicationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [5 x i8], [1 x i8] }>
%T17GiftUIRuntimeCore26RuntimePipelineOfferResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [4 x i8], [1 x i8] }>
%T24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV = type <{ %TSb, [3 x i8], %Ts6UInt32V }>
%TSb = type <{ i1 }>
%Ts6UInt32V = type <{ i32 }>
%TSvSg = type <{ [4 x i8] }>

@"$es16_emptyBoxStorageSi_Sitvp" = linkonce_odr protected global <{ %TSi, %TSi }> <{ %TSi zeroinitializer, %TSi <{ i32 -1 }> }>, align 4
@_swift1_autolink_entries = private constant [0 x i8] zeroinitializer, section ".swift1_autolink_entries", no_sanitize_address, align 4
@llvm.used = appending global [2 x ptr] [ptr @_swift1_autolink_entries, ptr @_swift_exceptionPersonality], section "llvm.metadata"
@"switch.table.$e17GiftUIRuntimeCore23RuntimeCompletePipelineO7cleanup33_B50B70A3773317B519FF1D925FDD955DLL5after8acquired5owneryAA0D16CoordinatorStageO_AA0D14CleanupActionsVxztAA0deF5OwnerRzRi_zlFZ24SignalAnalyzerTargetHost014InlineMutationV033_237593586C97A618E94E19970675F7E8LLV_Tt2g5" = private unnamed_addr constant [7 x i16] [i16 449, i16 480, i16 497, i16 504, i16 506, i16 282, i16 260], align 2

; Function Attrs: minsize nounwind optsize
define protected swiftcc i1 @"$e24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO21__derived_enum_equalsySbAC_ACtFZ"(i8 %0, i8 %1) local_unnamed_addr #0 {
entry:
  %2 = and i8 %0, 16
  %.not.not = icmp eq i8 %2, 0
  %3 = and i8 %1, 16
  %.not.not3 = icmp eq i8 %3, 0
  br i1 %.not.not, label %5, label %4

4:                                                ; preds = %entry
  br i1 %.not.not3, label %11, label %8

5:                                                ; preds = %entry
  br i1 %.not.not3, label %6, label %11

6:                                                ; preds = %5
  %7 = tail call swiftcc i1 @"$e17GiftUIRuntimeCore19RuntimeOwnerFailureO21__derived_enum_equalsySbAC_ACtFZ"(i8 %0, i8 %1)
  br label %11

8:                                                ; preds = %4
  %9 = icmp eq i8 %0, %1
  br i1 %9, label %11, label %10

10:                                               ; preds = %8
  br label %11

11:                                               ; preds = %5, %4, %8, %6, %10
  %12 = phi i1 [ false, %10 ], [ %7, %6 ], [ true, %8 ], [ false, %4 ], [ false, %5 ]
  ret i1 %12
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #1

; Function Attrs: minsize nounwind optsize
define protected swiftcc i1 @"$e24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAASQ2eeoiySbx_xtFZTW"(ptr noalias readonly captures(none) dereferenceable(1) %0, ptr noalias readonly captures(none) dereferenceable(1) %1, ptr readnone swiftself captures(none) %2, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #0 {
entry:
  %3 = load i8, ptr %0, align 1
  %4 = load i8, ptr %1, align 1
  %5 = tail call swiftcc i1 @"$e24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO21__derived_enum_equalsySbAC_ACtFZ"(i8 %3, i8 %4) #14
  ret i1 %5
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_framework_owner() local_unnamed_addr #2 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost20size_framework_owners6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_application_owner() local_unnamed_addr #2 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost22size_application_owners6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_framework_failure() local_unnamed_addr #2 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost22size_framework_failures6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_application_failure() local_unnamed_addr #2 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost24size_application_failures6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_framework_cycle() local_unnamed_addr #2 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost20size_framework_cycles6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_application_cycle() local_unnamed_addr #2 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost22size_application_cycles6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_mutation_result() local_unnamed_addr #2 {
entry:
  ret i32 4
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost20size_mutation_results6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 4
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_pipeline_result() local_unnamed_addr #2 {
entry:
  ret i32 24
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost20size_pipeline_results6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 24
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_framework_first_failure() local_unnamed_addr #2 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost28size_framework_first_failures6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected noundef i32 @size_first_failure() local_unnamed_addr #2 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i32 @"$e24SignalAnalyzerTargetHost18size_first_failures6UInt32VyF"() local_unnamed_addr #2 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV12admitAndSeal17GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read)
define protected swiftcc range(i32 16778265, 16843802) i32 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17applyAdmittedWork17GiftUIRuntimeCore015RuntimePipelineF6ResultOyAA0ab5CycleG7FailureOGyF"(ptr readonly swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #3 {
entry:
  %1 = load i1, ptr %0, align 4
  %temp-coercion.coerced.sroa.0.0.insert.insert = select i1 %1, i32 16843801, i32 16778265
  ret i32 %temp-coercion.coerced.sroa.0.0.insert.insert
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV016freezeObservableF017GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV42beginObservableCandidateAndExpandSemantics17GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV13resolveLayout17GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV27invokeCanvasesAndDerivePlan17GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV23preflightCombinedRender17GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV25buildInteractionCandidate17GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc { i32, i16 } @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV37publishSemanticAndObservableCandidate17GiftUIRuntimeCore32RuntimePipelinePublicationResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret { i32, i16 } { i32 1, i16 1 }
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc noundef i16 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17allocateCandidate17GiftUIRuntimeCore25RuntimePipelineStepResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret i16 -256
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc { i32, i8 } @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV15offerAndProduce17GiftUIRuntimeCore26RuntimePipelineOfferResultOyAA0ab5CycleG7FailureOGyF"(ptr readnone swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #2 {
entry:
  ret { i32, i8 } { i32 1, i8 3 }
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV7cleanupyy17GiftUIRuntimeCore20RuntimeCleanupActionOF"(i8 %0, ptr readnone swiftself captures(none) dereferenceable(8) %1) local_unnamed_addr #2 {
entry:
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV16applyDispositionyy17GiftUIRuntimeCore015RuntimePipelineO0VF"(i32 %0, i16 %1, ptr readnone swiftself captures(none) dereferenceable(8) %2) local_unnamed_addr #2 {
entry:
  ret void
}

; Function Attrs: minsize nounwind optsize
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV16finalizePipelineyyF"(ptr swiftself captures(none) dereferenceable(8) %0) local_unnamed_addr #0 {
entry:
  %.finalizations = getelementptr inbounds nuw i8, ptr %0, i32 4
  %1 = load i32, ptr %.finalizations, align 4
  %2 = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %1, i32 1)
  %3 = extractvalue { i32, i1 } %2, 1
  br i1 %3, label %6, label %4, !prof !6

4:                                                ; preds = %entry
  %5 = extractvalue { i32, i1 } %2, 0
  store i32 %5, ptr %.finalizations, align 4
  ret void

6:                                                ; preds = %entry
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP17applyAdmittedWorkAE0qsF6ResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore29RuntimePipelineMutationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 4)) %0, ptr readonly swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #4 {
entry:
  %2 = tail call swiftcc i32 @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17applyAdmittedWork17GiftUIRuntimeCore015RuntimePipelineF6ResultOyAA0ab5CycleG7FailureOGyF"(ptr nonnull swiftself captures(none) dereferenceable(8) %1) #14
  %temp-coercion.coerced.sroa.0.0.extract.trunc = trunc i32 %2 to i24
  store i24 %temp-coercion.coerced.sroa.0.0.extract.trunc, ptr %0, align 1
  %3 = getelementptr inbounds nuw i8, ptr %0, i32 3
  store i8 1, ptr %3, align 1
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #5 {
entry:
  store i16 -256, ptr %0, align 1
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP37publishSemanticAndObservableCandidateAE0qS17PublicationResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore32RuntimePipelinePublicationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 6)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #5 {
entry:
  store i32 1, ptr %0, align 4
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  store i8 1, ptr %2, align 4
  %3 = getelementptr inbounds nuw i8, ptr %0, i32 5
  store i8 0, ptr %3, align 1
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP15offerAndProduceAE0qS11OfferResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore26RuntimePipelineOfferResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 5)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #5 {
entry:
  store i32 1, ptr %0, align 4
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  store i8 3, ptr %2, align 4
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP7cleanupyyAE0Q13CleanupActionOFTW"(i8 %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #2 {
entry:
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP16applyDispositionyyAE0qsU0VFTW"(i32 %0, i16 %1, ptr readnone swiftself captures(none) dereferenceable(8) %2, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #2 {
entry:
  ret void
}

; Function Attrs: minsize nounwind optsize
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP08finalizeS0yyFTW"(ptr swiftself captures(none) dereferenceable(8) %0, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) local_unnamed_addr #0 {
entry:
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV16finalizePipelineyyF"(ptr nonnull swiftself captures(none) dereferenceable(8) %0) #14
  ret void
}

; Function Attrs: minsize nounwind optsize
define protected range(i32 1, 4) i32 @carrier_mutation_probe(i8 zeroext %0) local_unnamed_addr #0 {
entry:
  %1 = tail call swiftcc i32 @"$e24SignalAnalyzerTargetHost20carrierMutationProbeys6UInt32Vs5UInt8VF"(i8 %0) #14
  ret i32 %1
}

; Function Attrs: minsize nounwind optsize
define protected swiftcc range(i32 1, 4) i32 @"$e24SignalAnalyzerTargetHost20carrierMutationProbeys6UInt32Vs5UInt8VF"(i8 %0) local_unnamed_addr #0 {
entry:
  %1 = alloca %T24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV, align 4
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %1)
  %2 = icmp ne i8 %0, 0
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %1, align 4
  %.finalizations = getelementptr inbounds nuw i8, ptr %1, i32 4
  store i32 0, ptr %.finalizations, align 4
  call swiftcc void @"$e17GiftUIRuntimeCore23RuntimeCompletePipelineO7cleanup33_B50B70A3773317B519FF1D925FDD955DLL5after8acquired5owneryAA0D16CoordinatorStageO_AA0D14CleanupActionsVxztAA0deF5OwnerRzRi_zlFZ24SignalAnalyzerTargetHost014InlineMutationV033_237593586C97A618E94E19970675F7E8LLV_Tt2g5"(i8 0, i16 0, ptr nonnull captures(none) dereferenceable(8) %1)
  %4 = select i1 %2, i32 3, i32 1
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %1)
  ret i32 %4
}

; Function Attrs: minsize nounwind optsize
define linkonce_odr hidden swiftcc i1 @"$e17GiftUIRuntimeCore19RuntimeOwnerFailureO21__derived_enum_equalsySbAC_ACtFZ"(i8 %0, i8 %1) local_unnamed_addr #0 {
entry:
  %2 = lshr i8 %0, 5
  switch i8 %2, label %3 [
    i8 0, label %28
    i8 1, label %4
    i8 2, label %5
    i8 3, label %6
    i8 4, label %7
  ]

3:                                                ; preds = %entry
  unreachable

4:                                                ; preds = %entry
  %.mask14 = and i8 %1, -32
  %.not13 = icmp eq i8 %.mask14, 32
  br i1 %.not13, label %23, label %31

5:                                                ; preds = %entry
  %.mask12 = and i8 %1, -32
  %.not11 = icmp eq i8 %.mask12, 64
  br i1 %.not11, label %18, label %31

6:                                                ; preds = %entry
  %.mask = and i8 %1, -32
  %.not10 = icmp eq i8 %.mask, 96
  br i1 %.not10, label %13, label %31

7:                                                ; preds = %entry
  %.not = icmp slt i8 %1, -96
  br i1 %.not, label %8, label %31

8:                                                ; preds = %7
  %9 = xor i8 %1, %0
  %10 = and i8 %9, 31
  %11 = icmp eq i8 %10, 0
  br i1 %11, label %12, label %31

12:                                               ; preds = %8
  br label %31

13:                                               ; preds = %6
  %14 = xor i8 %1, %0
  %15 = and i8 %14, 31
  %16 = icmp eq i8 %15, 0
  br i1 %16, label %17, label %31

17:                                               ; preds = %13
  br label %31

18:                                               ; preds = %5
  %19 = xor i8 %1, %0
  %20 = and i8 %19, 31
  %21 = icmp eq i8 %20, 0
  br i1 %21, label %22, label %31

22:                                               ; preds = %18
  br label %31

23:                                               ; preds = %4
  %24 = xor i8 %1, %0
  %25 = and i8 %24, 31
  %26 = icmp eq i8 %25, 0
  br i1 %26, label %27, label %31

27:                                               ; preds = %23
  br label %31

28:                                               ; preds = %entry
  %.not15 = icmp ult i8 %1, 32
  br i1 %.not15, label %29, label %31

29:                                               ; preds = %28
  %30 = icmp eq i8 %0, %1
  br label %31

31:                                               ; preds = %29, %7, %6, %5, %4, %28, %23, %18, %13, %8, %27, %22, %17, %12
  %32 = phi i1 [ true, %12 ], [ true, %17 ], [ true, %22 ], [ true, %27 ], [ false, %8 ], [ false, %13 ], [ false, %18 ], [ false, %23 ], [ false, %28 ], [ false, %4 ], [ false, %5 ], [ false, %6 ], [ false, %7 ], [ %30, %29 ]
  ret i1 %32
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #6

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #7

; Function Attrs: minsize nounwind optsize
define linkonce_odr hidden swiftcc void @"$e17GiftUIRuntimeCore23RuntimeCompletePipelineO7cleanup33_B50B70A3773317B519FF1D925FDD955DLL5after8acquired5owneryAA0D16CoordinatorStageO_AA0D14CleanupActionsVxztAA0deF5OwnerRzRi_zlFZ24SignalAnalyzerTargetHost014InlineMutationV033_237593586C97A618E94E19970675F7E8LLV_Tt2g5"(i8 %0, i16 %1, ptr captures(none) dereferenceable(8) %2) local_unnamed_addr #0 {
entry:
  %3 = zext i8 %0 to i32
  %switch.gep = getelementptr inbounds nuw [7 x i16], ptr @"switch.table.$e17GiftUIRuntimeCore23RuntimeCompletePipelineO7cleanup33_B50B70A3773317B519FF1D925FDD955DLL5after8acquired5owneryAA0D16CoordinatorStageO_AA0D14CleanupActionsVxztAA0deF5OwnerRzRi_zlFZ24SignalAnalyzerTargetHost014InlineMutationV033_237593586C97A618E94E19970675F7E8LLV_Tt2g5", i32 0, i32 %3
  %switch.load = load i16, ptr %switch.gep, align 2
  %4 = and i16 %switch.load, %1
  br label %.backedge

.backedge:                                        ; preds = %.backedge.backedge, %entry
  %5 = phi i16 [ %4, %entry ], [ %.be, %.backedge.backedge ]
  %6 = and i16 %5, 1
  %.not = icmp eq i16 %6, 0
  br i1 %.not, label %9, label %7

7:                                                ; preds = %.backedge
  %8 = and i16 %5, -2
  br label %.backedge.backedge

9:                                                ; preds = %.backedge
  %10 = and i16 %5, 2
  %.not1 = icmp eq i16 %10, 0
  br i1 %.not1, label %13, label %11

11:                                               ; preds = %9
  %12 = and i16 %5, -4
  br label %.backedge.backedge

13:                                               ; preds = %9
  %14 = and i16 %5, 4
  %.not2 = icmp eq i16 %14, 0
  br i1 %.not2, label %17, label %15

15:                                               ; preds = %13
  %16 = and i16 %5, -8
  br label %.backedge.backedge

17:                                               ; preds = %13
  %18 = and i16 %5, 8
  %.not3 = icmp eq i16 %18, 0
  br i1 %.not3, label %21, label %19

19:                                               ; preds = %17
  %20 = and i16 %5, -16
  br label %.backedge.backedge

21:                                               ; preds = %17
  %22 = and i16 %5, 16
  %.not4 = icmp eq i16 %22, 0
  br i1 %.not4, label %25, label %23

23:                                               ; preds = %21
  %24 = and i16 %5, -32
  br label %.backedge.backedge

25:                                               ; preds = %21
  %26 = and i16 %5, 32
  %.not5 = icmp eq i16 %26, 0
  br i1 %.not5, label %29, label %27

27:                                               ; preds = %25
  %28 = and i16 %5, -64
  br label %.backedge.backedge

29:                                               ; preds = %25
  %30 = and i16 %5, 64
  %.not6 = icmp eq i16 %30, 0
  br i1 %.not6, label %33, label %31

31:                                               ; preds = %29
  %32 = and i16 %5, -128
  br label %.backedge.backedge

33:                                               ; preds = %29
  %34 = and i16 %5, 128
  %.not7 = icmp eq i16 %34, 0
  br i1 %.not7, label %37, label %35

35:                                               ; preds = %33
  %36 = and i16 %5, -256
  br label %.backedge.backedge

37:                                               ; preds = %33
  %38 = and i16 %5, 256
  %.not8 = icmp eq i16 %38, 0
  br i1 %.not8, label %39, label %.backedge.backedge

.backedge.backedge:                               ; preds = %37, %35, %31, %27, %23, %19, %15, %11, %7
  %.be = phi i16 [ %36, %35 ], [ %32, %31 ], [ %28, %27 ], [ %24, %23 ], [ %20, %19 ], [ %16, %15 ], [ %12, %11 ], [ %8, %7 ], [ 0, %37 ]
  br label %.backedge

39:                                               ; preds = %37
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_allocEmptyBox() local_unnamed_addr #0 {
entry:
  %0 = load atomic i32, ptr getelementptr inbounds nuw (i8, ptr @"$es16_emptyBoxStorageSi_Sitvp", i32 4) monotonic, align 4
  %1 = and i32 %0, 2147483647
  %2 = icmp eq i32 %1, 2147483647
  br i1 %2, label %5, label %3

3:                                                ; preds = %entry
  %4 = atomicrmw add ptr getelementptr inbounds nuw (i8, ptr @"$es16_emptyBoxStorageSi_Sitvp", i32 4), i32 1 monotonic, align 4
  br label %5

5:                                                ; preds = %entry, %3
  ret ptr @"$es16_emptyBoxStorageSi_Sitvp"
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_allocObject(ptr %0, i32 %1, i32 %2) local_unnamed_addr #0 {
entry:
  %3 = tail call swiftcc ptr @"$es17swift_allocObject8metadata12requiredSize0E13AlignmentMaskSpys04HeapC0VGSpys13ClassMetadataVG_S2itF"(ptr %0, i32 %1, i32 %2)
  ret ptr %3
}

; Function Attrs: minsize nounwind optsize sspreq
define linkonce_odr hidden swiftcc ptr @"$es17swift_allocObject8metadata12requiredSize0E13AlignmentMaskSpys04HeapC0VGSpys13ClassMetadataVG_S2itF"(ptr %0, i32 %1, i32 %2) local_unnamed_addr #8 {
entry:
  %3 = alloca %TSvSg, align 4
  %4 = icmp eq i32 %2, -1
  br i1 %4, label %10, label %5

5:                                                ; preds = %entry
  %6 = tail call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %2, i32 1)
  %7 = extractvalue { i32, i1 } %6, 1
  br i1 %7, label %17, label %8, !prof !6

8:                                                ; preds = %5
  %9 = extractvalue { i32, i1 } %6, 0
  %. = tail call i32 @llvm.smax.i32(i32 %9, i32 4)
  br label %10

10:                                               ; preds = %entry, %8
  %11 = phi i32 [ %., %8 ], [ 16, %entry ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %3)
  store i32 0, ptr %3, align 4
  %12 = call i32 @posix_memalign(ptr nonnull %3, i32 %11, i32 %1)
  %13 = load i32, ptr %3, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %3)
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %18, label %15

15:                                               ; preds = %10
  %16 = inttoptr i32 %13 to ptr
  store ptr %0, ptr %16, align 4, !tbaa !7
  %.refcount = getelementptr inbounds nuw i8, ptr %16, i32 4
  store i32 1, ptr %.refcount, align 4
  ret ptr %16

17:                                               ; preds = %5
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable

18:                                               ; preds = %10
  call void asm sideeffect "", "n"(i32 1) #15
  call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_initStackObject(ptr %0, ptr %1) local_unnamed_addr #0 {
entry:
  store ptr %0, ptr %1, align 4, !tbaa !7
  %.refcount = getelementptr inbounds nuw i8, ptr %1, i32 4
  store i32 -2147483647, ptr %.refcount, align 4
  ret ptr %1
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_initStaticObject(ptr %0, ptr %1) local_unnamed_addr #0 {
entry:
  store ptr %0, ptr %1, align 4, !tbaa !7
  %.refcount = getelementptr inbounds nuw i8, ptr %1, i32 4
  store i32 -1, ptr %.refcount, align 4
  ret ptr %1
}

; Function Attrs: minsize nounwind optsize
define private void @0(ptr %0, i32 %1, i32 %2) local_unnamed_addr #0 {
entry:
  tail call void @free(ptr %0)
  ret void
}

; Function Attrs: minsize mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #9

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_deallocClassInstance(ptr %0, i32 %1, i32 %2) local_unnamed_addr #0 {
entry:
  %.refcount = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %.refcount, align 4
  %.not = icmp sgt i32 %3, -1
  br i1 %.not, label %4, label %5

4:                                                ; preds = %entry
  tail call void @free(ptr nonnull %0)
  br label %5

5:                                                ; preds = %entry, %4
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_deallocPartialClassInstance(ptr %0, ptr %1, i32 %2, i32 %3) local_unnamed_addr #0 {
entry:
  %4 = load ptr, ptr %0, align 4, !tbaa !7
  br label %5

5:                                                ; preds = %11, %entry
  %6 = phi ptr [ %4, %entry ], [ %12, %11 ]
  %.not = icmp eq ptr %6, %1
  br i1 %.not, label %13, label %7

7:                                                ; preds = %5
  %arrayidx.i = getelementptr inbounds nuw i8, ptr %6, i32 8
  %8 = load ptr, ptr %arrayidx.i, align 4, !tbaa !12
  %tobool.not.i = icmp eq ptr %8, null
  br i1 %tobool.not.i, label %_swift_embedded_invoke_heap_object_optional_ivardestroyer.exit, label %if.then.i

if.then.i:                                        ; preds = %7
  tail call swiftcc void %8(ptr noundef nonnull swiftself %0) #16
  br label %_swift_embedded_invoke_heap_object_optional_ivardestroyer.exit

_swift_embedded_invoke_heap_object_optional_ivardestroyer.exit: ; preds = %7, %if.then.i
  %9 = load i32, ptr %6, align 4
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %13, label %11

11:                                               ; preds = %_swift_embedded_invoke_heap_object_optional_ivardestroyer.exit
  %12 = inttoptr i32 %9 to ptr
  br label %5

13:                                               ; preds = %_swift_embedded_invoke_heap_object_optional_ivardestroyer.exit, %5
  ret void
}

; Function Attrs: minsize nounwind optsize sspreq
define weak_odr protected ptr @swift_slowAlloc(i32 %0, i32 %1) local_unnamed_addr #8 {
entry:
  %2 = alloca %TSvSg, align 4
  %3 = icmp eq i32 %1, -1
  br i1 %3, label %9, label %4

4:                                                ; preds = %entry
  %5 = tail call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %1, i32 1)
  %6 = extractvalue { i32, i1 } %5, 1
  br i1 %6, label %14, label %7, !prof !6

7:                                                ; preds = %4
  %8 = extractvalue { i32, i1 } %5, 0
  %. = tail call i32 @llvm.smax.i32(i32 %8, i32 4)
  br label %9

9:                                                ; preds = %entry, %7
  %10 = phi i32 [ %., %7 ], [ 16, %entry ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2)
  store i32 0, ptr %2, align 4
  %11 = call i32 @posix_memalign(ptr nonnull %2, i32 %10, i32 %0)
  %12 = load i32, ptr %2, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2)
  %13 = inttoptr i32 %12 to ptr
  ret ptr %13

14:                                               ; preds = %4
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #6

; Function Attrs: minsize nofree nounwind optsize
declare i32 @posix_memalign(ptr, i32, i32) local_unnamed_addr #10

; Function Attrs: minsize nounwind optsize
define weak_odr protected swiftcc void @swift_willThrow(ptr swiftself %0, ptr noalias swifterror captures(none) dereferenceable(4) %1) local_unnamed_addr #0 {
entry:
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected swiftcc void @swift_errorInMain(ptr %0) local_unnamed_addr #0 {
entry:
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected swiftcc void @swift_unexpectedError(ptr %0, ptr %1, i32 %2, i1 %3, i32 %4) local_unnamed_addr #0 {
entry:
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_release(ptr %0) local_unnamed_addr #0 {
entry:
  %1 = icmp eq ptr %0, null
  br i1 %1, label %19, label %2

2:                                                ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %4 = load atomic i32, ptr %3 monotonic, align 4
  %5 = and i32 %4, 2147483647
  %6 = icmp eq i32 %5, 2147483647
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  %8 = atomicrmw sub ptr %3, i32 1 acq_rel, align 4
  %9 = tail call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %8, i32 -1)
  %10 = extractvalue { i32, i1 } %9, 1
  br i1 %10, label %20, label %11, !prof !6

11:                                               ; preds = %7
  %12 = extractvalue { i32, i1 } %9, 0
  %13 = and i32 %12, 2147483647
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %19

15:                                               ; preds = %11
  %16 = or i32 %4, 2147483647
  store atomic i32 %16, ptr %3 monotonic, align 4
  %17 = load ptr, ptr %0, align 4, !tbaa !7
  %arrayidx.i = getelementptr inbounds nuw i8, ptr %17, i32 4
  %18 = load ptr, ptr %arrayidx.i, align 4, !tbaa !12
  tail call swiftcc void %18(ptr noundef nonnull swiftself %0) #16
  br label %19

19:                                               ; preds = %11, %entry, %2, %15
  ret void

20:                                               ; preds = %7
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #6

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_release_n(ptr %0, i32 %1) local_unnamed_addr #0 {
entry:
  %2 = icmp eq ptr %0, null
  br i1 %2, label %22, label %3

3:                                                ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %5 = load atomic i32, ptr %4 monotonic, align 4
  %6 = and i32 %5, 2147483647
  %7 = icmp eq i32 %6, 2147483647
  br i1 %7, label %22, label %8

8:                                                ; preds = %3
  %9 = icmp slt i32 %1, 0
  br i1 %9, label %23, label %10, !prof !6

10:                                               ; preds = %8
  %11 = atomicrmw sub ptr %4, i32 %1 acq_rel, align 4
  %12 = tail call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %11, i32 %1)
  %13 = extractvalue { i32, i1 } %12, 1
  br i1 %13, label %24, label %14, !prof !6

14:                                               ; preds = %10
  %15 = extractvalue { i32, i1 } %12, 0
  %16 = and i32 %15, 2147483647
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %22

18:                                               ; preds = %14
  %19 = or i32 %5, 2147483647
  store atomic i32 %19, ptr %4 monotonic, align 4
  %20 = load ptr, ptr %0, align 4, !tbaa !7
  %arrayidx.i = getelementptr inbounds nuw i8, ptr %20, i32 4
  %21 = load ptr, ptr %arrayidx.i, align 4, !tbaa !12
  tail call swiftcc void %21(ptr noundef nonnull swiftself %0) #16
  br label %22

22:                                               ; preds = %14, %entry, %3, %18
  ret void

23:                                               ; preds = %8
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable

24:                                               ; preds = %10
  tail call void asm sideeffect "", "n"(i32 1) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_setDeallocating(ptr %0) local_unnamed_addr #0 {
entry:
  ret void
}

; Function Attrs: minsize nounwind optsize
define private ptr @1(ptr %0, i32 %1) local_unnamed_addr #0 {
  %3 = tail call ptr @swift_retain_nTm(ptr %0, i32 %1) #0
  ret ptr %3
}

; Function Attrs: minsize nounwind optsize
define internal ptr @swift_retain_nTm(ptr %0, i32 %1) local_unnamed_addr #0 {
entry:
  %2 = icmp eq ptr %0, null
  br i1 %2, label %12, label %3

3:                                                ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %5 = load atomic i32, ptr %4 monotonic, align 4
  %6 = and i32 %5, 2147483647
  %7 = icmp eq i32 %6, 2147483647
  br i1 %7, label %12, label %8

8:                                                ; preds = %3
  %9 = icmp slt i32 %1, 0
  br i1 %9, label %13, label %10, !prof !6

10:                                               ; preds = %8
  %11 = atomicrmw add ptr %4, i32 %1 monotonic, align 4
  br label %12

12:                                               ; preds = %entry, %3, %10
  ret ptr %0

13:                                               ; preds = %8
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_bridgeObjectRelease_n(ptr %0, i32 %1) local_unnamed_addr #0 {
entry:
  tail call void @swift_release_n(ptr %0, i32 %1)
  ret void
}

; Function Attrs: minsize nounwind optsize
define private ptr @2(ptr %0) local_unnamed_addr #0 {
entry:
  %1 = icmp eq ptr %0, null
  br i1 %1, label %9, label %2

2:                                                ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %4 = load atomic i32, ptr %3 monotonic, align 4
  %5 = and i32 %4, 2147483647
  %6 = icmp eq i32 %5, 2147483647
  br i1 %6, label %9, label %7

7:                                                ; preds = %2
  %8 = atomicrmw add ptr %3, i32 1 monotonic, align 4
  br label %9

9:                                                ; preds = %entry, %2, %7
  ret ptr %0
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_bridgeObjectRelease(ptr %0) local_unnamed_addr #0 {
entry:
  tail call void @swift_release_n(ptr %0, i32 1)
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected zeroext i1 @swift_isUniquelyReferenced_native(ptr %0) local_unnamed_addr #0 {
entry:
  %1 = icmp eq ptr %0, null
  br i1 %1, label %6, label %2

2:                                                ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %4 = load atomic i32, ptr %3 acquire, align 4
  %5 = icmp eq i32 %4, 1
  br label %6

6:                                                ; preds = %entry, %2
  %7 = phi i1 [ %5, %2 ], [ false, %entry ]
  ret i1 %7
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected zeroext i1 @swift_isUniquelyReferenced_nonNull_native(ptr %0) local_unnamed_addr #0 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load atomic i32, ptr %1 acquire, align 4
  %3 = icmp eq i32 %2, 1
  ret i1 %3
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected zeroext i1 @swift_isEscapingClosureAtFileLocation(ptr %0, ptr %1, i32 %2, i32 %3, i32 %4, i32 %5) local_unnamed_addr #0 {
entry:
  %6 = icmp eq ptr %0, null
  br i1 %6, label %10, label %7

7:                                                ; preds = %entry
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %9 = load atomic i32, ptr %8 acquire, align 4
  %.not = icmp eq i32 %9, 1
  br i1 %.not, label %10, label %11, !prof !13

10:                                               ; preds = %entry, %7
  ret i1 false

11:                                               ; preds = %7
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_dynamicCastClass(ptr %0, ptr %1) local_unnamed_addr #0 {
entry:
  %2 = load ptr, ptr %0, align 4, !tbaa !7
  br label %3

3:                                                ; preds = %8, %entry
  %4 = phi ptr [ %2, %entry ], [ %9, %8 ]
  %.not = icmp eq ptr %4, %1
  br i1 %.not, label %10, label %5

5:                                                ; preds = %3
  %6 = load i32, ptr %4, align 4
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %10, label %8

8:                                                ; preds = %5
  %9 = inttoptr i32 %6 to ptr
  br label %3

10:                                               ; preds = %3, %5
  %11 = phi ptr [ null, %5 ], [ %0, %3 ]
  ret ptr %11
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_dynamicCastClassUnconditional(ptr %0, ptr %1, ptr %2, i32 %3, i32 %4) local_unnamed_addr #0 {
entry:
  %5 = load ptr, ptr %0, align 4, !tbaa !7
  br label %6

6:                                                ; preds = %12, %entry
  %7 = phi ptr [ %5, %entry ], [ %13, %12 ]
  %.not = icmp eq ptr %7, %1
  br i1 %.not, label %8, label %9

8:                                                ; preds = %6
  ret ptr %0

9:                                                ; preds = %6
  %10 = load i32, ptr %7, align 4
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %14, label %12

12:                                               ; preds = %9
  %13 = inttoptr i32 %10 to ptr
  br label %6

14:                                               ; preds = %9
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_once(ptr %0, ptr %1, ptr %2) local_unnamed_addr #0 {
entry:
  %3 = load atomic i32, ptr %0 acquire, align 4
  %4 = icmp slt i32 %3, 0
  br i1 %4, label %.loopexit, label %5

5:                                                ; preds = %entry
  %6 = cmpxchg ptr %0, i32 0, i32 1 monotonic monotonic, align 4
  %7 = extractvalue { i32, i1 } %6, 1
  br i1 %7, label %10, label %.preheader

.preheader:                                       ; preds = %5, %.preheader
  %8 = load atomic i32, ptr %0 acquire, align 4
  %9 = icmp sgt i32 %8, -1
  br i1 %9, label %.preheader, label %.loopexit

10:                                               ; preds = %5
  tail call void %1(ptr %2) #15
  store atomic i32 -1, ptr %0 release, align 4
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader, %entry, %10
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_beginAccess(ptr %0, ptr %1, i32 %2, ptr %3) local_unnamed_addr #0 {
entry:
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_endAccess(ptr %0) local_unnamed_addr #0 {
entry:
  ret void
}

; Function Attrs: minsize nounwind optsize sspreq
define weak_odr protected ptr @swift_coroFrameAlloc(i32 %0, i64 %1) local_unnamed_addr #8 {
entry:
  %2 = alloca %TSvSg, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2)
  store i32 0, ptr %2, align 4
  %3 = call i32 @posix_memalign(ptr nonnull %2, i32 16, i32 %0)
  %4 = load i32, ptr %2, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2)
  %5 = inttoptr i32 %4 to ptr
  ret ptr %5
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_deletedMethodError() local_unnamed_addr #0 {
entry:
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected i32 @_swift_exceptionPersonality(i32 %0, i32 %1, i64 %2, ptr %3, ptr %4) #0 {
entry:
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize noinline nounwind optsize
define weak_odr protected void @swift_clearSensitive(ptr %0, i32 %1) local_unnamed_addr #11 {
entry:
  %2 = icmp slt i32 %1, 0
  br i1 %2, label %5, label %3, !prof !6

3:                                                ; preds = %entry
  %4 = icmp eq i32 %1, 0
  br i1 %4, label %.loopexit, label %.preheader.preheader

.preheader.preheader:                             ; preds = %3
  tail call void @llvm.memset.p0.i32(ptr align 1 %0, i8 0, i32 %1, i1 false)
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader.preheader, %3
  ret void

5:                                                ; preds = %entry
  tail call void asm sideeffect "", "n"(i32 0) #15
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected i32 @swift_retainCount(ptr %0) local_unnamed_addr #0 {
entry:
  %1 = icmp eq ptr %0, null
  br i1 %1, label %6, label %2

2:                                                ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %4 = load atomic i32, ptr %3 acquire, align 4
  %5 = and i32 %4, 2147483647
  br label %6

6:                                                ; preds = %entry, %2
  %7 = phi i32 [ %5, %2 ], [ 0, %entry ]
  ret i32 %7
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #12

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i32(ptr writeonly captures(none), i8, i32, i1 immarg) #13

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP12admitAndSealAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) local_unnamed_addr #5 {
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #5
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP42beginObservableCandidateAndExpandSemanticsAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) local_unnamed_addr #5 {
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #5
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP13resolveLayoutAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) local_unnamed_addr #5 {
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #5
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP27invokeCanvasesAndDerivePlanAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) local_unnamed_addr #5 {
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #5
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP23preflightCombinedRenderAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) local_unnamed_addr #5 {
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #5
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP25buildInteractionCandidateAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) local_unnamed_addr #5 {
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #5
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define protected swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP17allocateCandidateAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) local_unnamed_addr #5 {
  tail call swiftcc void @"$e24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #5
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_retain(ptr %0) local_unnamed_addr #0 {
  %2 = tail call ptr @2(ptr %0) #0
  ret ptr %2
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_bridgeObjectRetain(ptr %0) local_unnamed_addr #0 {
  %2 = tail call ptr @2(ptr %0) #0
  ret ptr %2
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_retain_n(ptr %0, i32 %1) local_unnamed_addr #0 {
  %3 = tail call ptr @1(ptr %0, i32 %1) #0
  ret ptr %3
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected ptr @swift_bridgeObjectRetain_n(ptr %0, i32 %1) local_unnamed_addr #0 {
  %3 = tail call ptr @1(ptr %0, i32 %1) #0
  ret ptr %3
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_deallocUninitializedObject(ptr %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  tail call void @0(ptr %0, i32 %1, i32 %2) #0
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_deallocObject(ptr %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  tail call void @0(ptr %0, i32 %1, i32 %2) #0
  ret void
}

; Function Attrs: minsize nounwind optsize
define weak_odr protected void @swift_slowDealloc(ptr %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  tail call void @0(ptr %0, i32 %1, i32 %2) #0
  ret void
}

attributes #0 = { minsize nounwind optsize "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #3 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #4 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #5 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #8 = { minsize nounwind optsize sspreq "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #9 = { minsize mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #10 = { minsize nofree nounwind optsize "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #11 = { minsize noinline nounwind optsize "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="cortex-m4" "target-features"="+armv7e-m,+dsp,+fp16,+hwdiv,+thumb-mode,+vfp2sp,+vfp3d16sp,+vfp4d16sp,-aes,-bf16,-cdecp0,-cdecp1,-cdecp2,-cdecp3,-cdecp4,-cdecp5,-cdecp6,-cdecp7,-crc,-crypto,-d32,-dotprod,-fp-armv8,-fp-armv8d16,-fp-armv8d16sp,-fp-armv8sp,-fp16fml,-fp64,-fullfp16,-hwdiv-arm,-i8mm,-lob,-mve,-mve.fp,-neon,-pacbti,-ras,-sb,-sha2,-vfp2,-vfp3,-vfp3d16,-vfp3sp,-vfp4,-vfp4d16,-vfp4sp" }
attributes #12 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #14 = { noinline }
attributes #15 = { nounwind }
attributes #16 = { nounwind optsize }

!swift.module.flags = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}
!llvm.linker.options = !{}

!0 = !{!"standard-library", i1 false}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 1, !"min_enum_size", i32 4}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 4, !"Objective-C Garbage Collection", i32 100861696}
!5 = !{i32 1, !"Swift Version", i32 7}
!6 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!7 = !{!8, !9, i64 0}
!8 = !{!"EmbeddedHeapObject", !9, i64 0}
!9 = !{!"any pointer", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C/C++ TBAA"}
!12 = !{!9, !9, i64 0}
!13 = !{!"branch_weights", !"expected", i32 2000, i32 1}
