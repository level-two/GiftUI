; ModuleID = '/Users/eugene/work/GiftUI/.build/contract-reports/spec-013/amended-carriers/macos/carriers.ll'
source_filename = "/Users/eugene/work/GiftUI/.build/contract-reports/spec-013/amended-carriers/macos/carriers.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%swift.type = type { i64 }
%swift.protocol_conformance_descriptor = type { i32, i32, i32, i32 }
%swift.type_descriptor = type opaque
%swift.protocol = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32 }
%swift.method_descriptor = type { i32, i32 }
%swift.enum_vwtable = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, ptr, ptr, ptr }
%swift.vwtable = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32 }
%swift.type_metadata_record = type { i32 }
%T26SignalAnalyzerPresentation0aB16RuntimeConditionO = type <{ i8 }>
%T17GiftUIRuntimeCore19RuntimeOwnerFailureO = type <{ [1 x i8] }>
%T17GiftUIRuntimeCore29RuntimePipelineMutationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [3 x i8], [1 x i8] }>
%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [2 x i8] }>
%T17GiftUIRuntimeCore32RuntimePipelinePublicationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [5 x i8], [1 x i8] }>
%T17GiftUIRuntimeCore26RuntimePipelineOfferResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [4 x i8], [1 x i8] }>
%T24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV = type <{ %TSb, [3 x i8], %Ts6UInt32V }>
%TSb = type <{ i1 }>
%Ts6UInt32V = type <{ i32 }>
%T17GiftUIRuntimeCore29RuntimeCompletePipelineResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG = type <{ [20 x i8], [1 x i8] }>
%T15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OG = type <{ [1 x i8], [1 x i8] }>
%T15GiftUIExecution24SemanticCycleDispositionO = type <{ i8 }>
%swift.opaque = type opaque
%swift.metadata_response = type { ptr, i64 }

@"$s26SignalAnalyzerPresentation0aB16RuntimeConditionON" = external global %swift.type, align 8
@"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOACSQAAWL" = linkonce_odr hidden local_unnamed_addr global ptr null, align 8
@"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOSQAAMc" = external global %swift.protocol_conformance_descriptor, align 4
@"$s17GiftUIRuntimeCore19RuntimeOwnerFailureON" = external global %swift.type, align 8
@"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOACSQAAWL" = linkonce_odr hidden local_unnamed_addr global ptr null, align 8
@"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOSQAAMc" = external global %swift.protocol_conformance_descriptor, align 4
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVAD17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAWL" = internal unnamed_addr global ptr null, align 8
@"$s15GiftUIExecution15RunCycleFailureOMn" = external global %swift.type_descriptor, align 4
@"got.$s15GiftUIExecution15RunCycleFailureOMn" = private unnamed_addr constant ptr @"$s15GiftUIExecution15RunCycleFailureOMn"
@"symbolic _____y_____G 15GiftUIExecution15RunCycleFailureO 24SignalAnalyzerTargetHost0fgd5OwnerE0O" = linkonce_odr hidden constant <{ i8, i32, [1 x i8], i8, i32, [1 x i8], i8 }> <{ i8 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$s15GiftUIExecution15RunCycleFailureOMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, [1 x i8], i8, i32, [1 x i8], i8 }>, ptr @"symbolic _____y_____G 15GiftUIExecution15RunCycleFailureO 24SignalAnalyzerTargetHost0fgd5OwnerE0O", i32 0, i32 1) to i64)) to i32), [1 x i8] c"y", i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, [1 x i8], i8, i32, [1 x i8], i8 }>, ptr @"symbolic _____y_____G 15GiftUIExecution15RunCycleFailureO 24SignalAnalyzerTargetHost0fgd5OwnerE0O", i32 0, i32 4) to i64)) to i32), [1 x i8] c"G", i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGMd" = linkonce_odr hidden global { ptr } zeroinitializer, align 8
@"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGMR" = linkonce_odr hidden constant { i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____y_____G 15GiftUIExecution15RunCycleFailureO 24SignalAnalyzerTargetHost0fgd5OwnerE0O" to i64), i64 ptrtoint (ptr @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGMR" to i64)) to i32), i32 12 }, align 8
@"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGACyxGSQAAWL" = linkonce_odr hidden local_unnamed_addr global ptr null, align 8
@"$s15GiftUIExecution15RunCycleFailureOyxGSQAAMc" = external global %swift.protocol_conformance_descriptor, align 4
@"$s15GiftUIExecution24SemanticCycleDispositionON" = external global %swift.type, align 8
@"$s15GiftUIExecution24SemanticCycleDispositionOACSQAAWL" = linkonce_odr hidden local_unnamed_addr global ptr null, align 8
@"$s15GiftUIExecution24SemanticCycleDispositionOSQAAMc" = external global %swift.protocol_conformance_descriptor, align 4
@"$sSQMp" = external global %swift.protocol, align 4
@"got.$sSQMp" = private unnamed_addr constant ptr @"$sSQMp"
@"$sSQ2eeoiySbx_xtFZTq" = external global %swift.method_descriptor, align 4
@"got.$sSQ2eeoiySbx_xtFZTq" = private unnamed_addr constant ptr @"$sSQ2eeoiySbx_xtFZTq"
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMcMK" = internal global [16 x ptr] zeroinitializer
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc" = constant { i32, i32, i32, i32, i32, i32, i32, i16, i16, i32, i32 } { i32 add (i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$sSQMp" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc" to i64)) to i32), i32 1), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i32, i32, i32, i16, i16, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc", i32 0, i32 1) to i64)) to i32), i32 0, i32 196608, i32 1, i32 add (i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$sSQ2eeoiySbx_xtFZTq" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i32, i32, i32, i16, i16, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc", i32 0, i32 5) to i64)) to i32), i32 1), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAASQ2eeoiySbx_xtFZTW" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i32, i32, i32, i16, i16, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc", i32 0, i32 6) to i64)) to i32), i16 0, i16 1, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMcMK" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i32, i32, i32, i16, i16, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc", i32 0, i32 10) to i64)) to i32) }, section "__TEXT,__const", no_sanitize_address, align 4
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOWV" = internal constant %swift.enum_vwtable { ptr @__swift_memcpy1_1, ptr @__swift_noop_void_return, ptr @__swift_memcpy1_1, ptr @__swift_memcpy1_1, ptr @__swift_memcpy1_1, ptr @__swift_memcpy1_1, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwet", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwst", i64 1, i64 1, i32 2097152, i32 0, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwug", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwup", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwui" }, align 8
@.str.24.SignalAnalyzerTargetHost = private constant [25 x i8] c"SignalAnalyzerTargetHost\00"
@"$s24SignalAnalyzerTargetHostMXM" = linkonce_odr hidden constant <{ i32, i32, i32 }> <{ i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.24.SignalAnalyzerTargetHost to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHostMXM", i32 0, i32 2) to i64)) to i32) }>, section "__TEXT,__constg_swiftt", align 4
@.str.31.SignalAnalyzerCycleOwnerFailure = private constant [32 x i8] c"SignalAnalyzerCycleOwnerFailure\00"
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn" = constant <{ i32, i32, i32, i32, i32, i32, i32 }> <{ i32 82, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHostMXM" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn", i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.31.SignalAnalyzerCycleOwnerFailure to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn", i32 0, i32 2) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMa" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn", i32 0, i32 3) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn", i32 0, i32 4) to i64)) to i32), i32 2, i32 0 }>, section "__TEXT,__constg_swiftt", align 4
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMf" = internal constant <{ ptr, ptr, i64, ptr }> <{ ptr null, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOWV", i64 513, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn" }>, align 8
@"symbolic _____ 24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ 24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMB" = internal constant { i32, i32, i32, i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMB" to i64)) to i32), i32 1, i32 65537, i32 1, i32 0 }, section "__TEXT,__swift5_builtin, regular", no_sanitize_address, align 4
@"\01l__swift5_reflection_descriptor" = private constant { i32, i32, i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO" to i64), i64 ptrtoint (ptr @"\01l__swift5_reflection_descriptor" to i64)) to i32), i32 196609, i32 1, i32 16 }, section "__TEXT,__swift5_mpenum, regular", no_sanitize_address, align 4
@"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOMn" = external global %swift.type_descriptor, align 4
@"got.$s17GiftUIRuntimeCore19RuntimeOwnerFailureOMn" = private unnamed_addr constant ptr @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOMn"
@"symbolic _____ 17GiftUIRuntimeCore19RuntimeOwnerFailureO" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$s17GiftUIRuntimeCore19RuntimeOwnerFailureOMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ 17GiftUIRuntimeCore19RuntimeOwnerFailureO", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@0 = private constant [8 x i8] c"runtime\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOMn" = external global %swift.type_descriptor, align 4
@"got.$s26SignalAnalyzerPresentation0aB16RuntimeConditionOMn" = private unnamed_addr constant ptr @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOMn"
@"symbolic _____ 26SignalAnalyzerPresentation0aB16RuntimeConditionO" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$s26SignalAnalyzerPresentation0aB16RuntimeConditionOMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ 26SignalAnalyzerPresentation0aB16RuntimeConditionO", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@1 = private constant [12 x i8] c"application\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF" = internal constant { i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF" to i64)) to i32), i32 0, i16 3, i16 12, i32 2, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 17GiftUIRuntimeCore19RuntimeOwnerFailureO" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF", i32 0, i32 6) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @0 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF", i32 0, i32 7) to i64)) to i32), i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 26SignalAnalyzerPresentation0aB16RuntimeConditionO" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF", i32 0, i32 9) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @1 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF", i32 0, i32 10) to i64)) to i32) }, section "__TEXT,__swift5_fieldmd, regular", no_sanitize_address, align 4
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVWV" = internal constant %swift.vwtable { ptr @__swift_memcpy8_4, ptr @__swift_noop_void_return, ptr @__swift_memcpy8_4, ptr @__swift_memcpy8_4, ptr @__swift_memcpy8_4, ptr @__swift_memcpy8_4, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVwet", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVwst", i64 8, i64 8, i32 3, i32 254 }, align 8
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMXX" = linkonce_odr hidden constant <{ i32, i32 }> <{ i32 66, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHostMXM" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMXX", i32 0, i32 1) to i64)) to i32) }>, section "__TEXT,__constg_swiftt", align 4
@.str.19.InlineMutationOwner = private constant [20 x i8] c"InlineMutationOwner\00"
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn" = internal constant <{ i32, i32, i32, i32, i32, i32, i32 }> <{ i32 81, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMXX" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn", i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @.str.19.InlineMutationOwner to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn", i32 0, i32 2) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMa" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn", i32 0, i32 3) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i32, i32, i32, i32, i32, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn", i32 0, i32 4) to i64)) to i32), i32 2, i32 2 }>, section "__TEXT,__constg_swiftt", align 4
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMf" = internal constant <{ ptr, ptr, i64, ptr, i32, i32 }> <{ ptr null, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVWV", i64 512, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn", i32 0, i32 4 }>, align 8
@"symbolic _____ 24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 1, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ 24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"symbolic Sb" = linkonce_odr hidden constant <{ [2 x i8], i8 }> <{ [2 x i8] c"Sb", i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@2 = private constant [8 x i8] c"applied\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@"$ss6UInt32VMn" = external global %swift.type_descriptor, align 4
@"got.$ss6UInt32VMn" = private unnamed_addr constant ptr @"$ss6UInt32VMn"
@"symbolic _____ s6UInt32V" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$ss6UInt32VMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ s6UInt32V", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@3 = private constant [14 x i8] c"finalizations\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF" = internal constant { i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF" to i64)) to i32), i32 0, i16 0, i16 12, i32 2, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic Sb" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF", i32 0, i32 6) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @2 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF", i32 0, i32 7) to i64)) to i32), i32 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ s6UInt32V" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF", i32 0, i32 9) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @3 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i16, i16, i32, i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF", i32 0, i32 10) to i64)) to i32) }, section "__TEXT,__swift5_fieldmd, regular", no_sanitize_address, align 4
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOACSQAAWL" = linkonce_odr hidden local_unnamed_addr global ptr null, align 8
@"associated conformance 24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AA0G7FailureAeFP_SQ" = linkonce_odr hidden constant <{ i8, i8, i32, i8 }> <{ i8 -1, i8 7, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AA0G7FailureAeFP_SQWT" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i8, i32, i8 }>, ptr @"associated conformance 24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AA0G7FailureAeFP_SQ", i32 0, i32 2) to i64)) to i32), i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAWP" = internal global [17 x ptr] [ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc", ptr getelementptr (i8, ptr @"associated conformance 24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AA0G7FailureAeFP_SQ", i64 1), ptr getelementptr inbounds (i8, ptr @"symbolic _____ 24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO", i64 1), ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP12admitAndSealAE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP17applyAdmittedWorkAE0qsF6ResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP42beginObservableCandidateAndExpandSemanticsAE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP13resolveLayoutAE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP27invokeCanvasesAndDerivePlanAE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP23preflightCombinedRenderAE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP25buildInteractionCandidateAE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP37publishSemanticAndObservableCandidateAE0qS17PublicationResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP17allocateCandidateAE0qS10StepResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP15offerAndProduceAE0qS11OfferResultOy0G7FailureQzGyFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP7cleanupyyAE0Q13CleanupActionOFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP16applyDispositionyyAE0qsU0VFTW", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP08finalizeS0yyFTW"], align 8
@"symbolic $s17GiftUIRuntimeCore28RuntimeCompletePipelineOwnerP" = linkonce_odr hidden constant <{ [52 x i8], i8 }> <{ [52 x i8] c"$s17GiftUIRuntimeCore28RuntimeCompletePipelineOwnerP", i8 0 }>, section "__TEXT,__swift5_typeref, regular", no_sanitize_address, align 2
@4 = private constant [13 x i8] c"OwnerFailure\00", section "__TEXT,__swift5_reflstr, regular", no_sanitize_address
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMA" = internal constant { i32, i32, i32, i32, i32, i32 } { i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMA" to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic $s17GiftUIRuntimeCore28RuntimeCompletePipelineOwnerP" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMA", i32 0, i32 1) to i64)) to i32), i32 1, i32 8, i32 trunc (i64 sub (i64 ptrtoint (ptr @4 to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMA", i32 0, i32 4) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ 24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMA", i32 0, i32 5) to i64)) to i32) }, section "__TEXT,__swift5_assocty, regular", no_sanitize_address, align 4
@"$s17GiftUIRuntimeCore28RuntimeCompletePipelineOwnerMp" = external global %swift.protocol, align 4
@"got.$s17GiftUIRuntimeCore28RuntimeCompletePipelineOwnerMp" = private unnamed_addr constant ptr @"$s17GiftUIRuntimeCore28RuntimeCompletePipelineOwnerMp"
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMcMK" = internal global [16 x ptr] zeroinitializer
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc" = internal constant { i32, i32, i32, i32, i16, i16, i32, i32 } { i32 add (i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$s17GiftUIRuntimeCore28RuntimeCompletePipelineOwnerMp" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc" to i64)) to i32), i32 1), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i16, i16, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc", i32 0, i32 1) to i64)) to i32), i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAWP" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i16, i16, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc", i32 0, i32 2) to i64)) to i32), i32 131072, i16 17, i16 1, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMcMK" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32, i16, i16, i32, i32 }, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc", i32 0, i32 7) to i64)) to i32) }, section "__TEXT,__const", no_sanitize_address, align 4
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAHc" = private constant i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAHc" to i64)) to i32), section "__TEXT, __swift5_proto, regular", no_sanitize_address, align 4
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAHc" = private constant i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAHc" to i64)) to i32), section "__TEXT, __swift5_proto, regular", no_sanitize_address, align 4
@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOHn" = private constant %swift.type_metadata_record { i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOHn" to i64)) to i32) }, section "__TEXT, __swift5_types, regular", no_sanitize_address, align 4
@"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVHn" = private constant %swift.type_metadata_record { i32 trunc (i64 sub (i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMn" to i64), i64 ptrtoint (ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVHn" to i64)) to i32) }, section "__TEXT, __swift5_types, regular", no_sanitize_address, align 4
@__swift_reflection_version = linkonce_odr hidden constant i16 3
@llvm.used = appending global [37 x ptr] [ptr @"\01l__swift5_reflection_descriptor", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO21__derived_enum_equalsySbAC_ACtFZ", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOHn", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMB", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMF", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMa", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMn", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureON", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAHc", ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc", ptr @"$s24SignalAnalyzerTargetHost18size_first_failures6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAHc", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMA", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVHn", ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMF", ptr @"$s24SignalAnalyzerTargetHost20carrierMutationProbeys6UInt32Vs5UInt8VF", ptr @"$s24SignalAnalyzerTargetHost20size_framework_cycles6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost20size_framework_owners6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost20size_mutation_results6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost20size_pipeline_results6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost22size_application_cycles6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost22size_application_owners6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost22size_framework_failures6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost24size_application_failures6UInt32VyF", ptr @"$s24SignalAnalyzerTargetHost28size_framework_first_failures6UInt32VyF", ptr @__swift_reflection_version, ptr @carrier_mutation_probe, ptr @size_application_cycle, ptr @size_application_failure, ptr @size_application_owner, ptr @size_first_failure, ptr @size_framework_cycle, ptr @size_framework_failure, ptr @size_framework_first_failure, ptr @size_framework_owner, ptr @size_mutation_result, ptr @size_pipeline_result], section "llvm.metadata"

@"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureON" = alias %swift.type, getelementptr inbounds (<{ ptr, ptr, i64, ptr }>, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMf", i32 0, i32 2)

; Function Attrs: minsize optsize
define swiftcc i1 @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO21__derived_enum_equalsySbAC_ACtFZ"(i8 %0, i8 %1) #0 {
entry:
  %2 = alloca %T26SignalAnalyzerPresentation0aB16RuntimeConditionO, align 1
  %3 = alloca %T26SignalAnalyzerPresentation0aB16RuntimeConditionO, align 1
  %4 = alloca %T17GiftUIRuntimeCore19RuntimeOwnerFailureO, align 1
  %5 = alloca %T17GiftUIRuntimeCore19RuntimeOwnerFailureO, align 1
  %6 = and i8 %0, 16
  %.not.not = icmp eq i8 %6, 0
  %7 = and i8 %1, 16
  %.not.not2 = icmp eq i8 %7, 0
  br i1 %.not.not, label %9, label %8

8:                                                ; preds = %entry
  br i1 %.not.not2, label %18, label %13

9:                                                ; preds = %entry
  br i1 %.not.not2, label %10, label %18

10:                                               ; preds = %9
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %4)
  store i8 %0, ptr %4, align 1
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %5)
  store i8 %1, ptr %5, align 1
  %11 = tail call ptr @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOACSQAAWl"() #14
  %12 = call swiftcc i1 @"$sSQ2eeoiySbx_xtFZTj"(ptr noalias nonnull %4, ptr noalias nonnull %5, ptr nonnull swiftself @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureON", ptr nonnull @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureON", ptr %11)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %5)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %4)
  br label %18

13:                                               ; preds = %8
  %14 = and i8 %0, -17
  %15 = and i8 %1, -17
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %2)
  store i8 %14, ptr %2, align 1
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %3)
  store i8 %15, ptr %3, align 1
  %16 = tail call ptr @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOACSQAAWl"() #14
  %17 = call swiftcc i1 @"$sSQ2eeoiySbx_xtFZTj"(ptr noalias nonnull %2, ptr noalias nonnull %3, ptr nonnull swiftself @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionON", ptr nonnull @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionON", ptr %16)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %3)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %2)
  br label %18

18:                                               ; preds = %13, %9, %8, %10
  %19 = phi i1 [ %12, %10 ], [ false, %8 ], [ false, %9 ], [ %17, %13 ]
  ret i1 %19
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #1

; Function Attrs: minsize optsize
declare swiftcc i1 @"$sSQ2eeoiySbx_xtFZTj"(ptr noalias, ptr noalias, ptr swiftself, ptr, ptr) local_unnamed_addr #0

; Function Attrs: minsize nofree noinline nosync nounwind optsize memory(none)
define linkonce_odr hidden ptr @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOACSQAAWl"() local_unnamed_addr #2 {
entry:
  %0 = load ptr, ptr @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOACSQAAWL", align 8
  %1 = icmp eq ptr %0, null
  br i1 %1, label %cacheIsNull, label %cont

cacheIsNull:                                      ; preds = %entry
  %2 = tail call ptr @swift_getWitnessTable(ptr nonnull @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOSQAAMc", ptr nonnull @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionON", ptr undef) #15
  store atomic ptr %2, ptr @"$s26SignalAnalyzerPresentation0aB16RuntimeConditionOACSQAAWL" release, align 8
  br label %cont

cont:                                             ; preds = %cacheIsNull, %entry
  %3 = phi ptr [ %0, %entry ], [ %2, %cacheIsNull ]
  ret ptr %3
}

; Function Attrs: nofree nounwind memory(read)
declare ptr @swift_getWitnessTable(ptr, ptr, ptr) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #1

; Function Attrs: minsize nofree noinline nosync nounwind optsize memory(none)
define linkonce_odr hidden ptr @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOACSQAAWl"() local_unnamed_addr #2 {
entry:
  %0 = load ptr, ptr @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOACSQAAWL", align 8
  %1 = icmp eq ptr %0, null
  br i1 %1, label %cacheIsNull, label %cont

cacheIsNull:                                      ; preds = %entry
  %2 = tail call ptr @swift_getWitnessTable(ptr nonnull @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOSQAAMc", ptr nonnull @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureON", ptr undef) #15
  store atomic ptr %2, ptr @"$s17GiftUIRuntimeCore19RuntimeOwnerFailureOACSQAAWL" release, align 8
  br label %cont

cont:                                             ; preds = %cacheIsNull, %entry
  %3 = phi ptr [ %0, %entry ], [ %2, %cacheIsNull ]
  ret ptr %3
}

; Function Attrs: minsize optsize
define internal swiftcc i1 @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAASQ2eeoiySbx_xtFZTW"(ptr noalias readonly captures(none) dereferenceable(1) %0, ptr noalias readonly captures(none) dereferenceable(1) %1, ptr readnone swiftself captures(none) %2, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #0 {
entry:
  %3 = load i8, ptr %0, align 1
  %4 = load i8, ptr %1, align 1
  %5 = tail call swiftcc i1 @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureO21__derived_enum_equalsySbAC_ACtFZ"(i8 %3, i8 %4) #16
  ret i1 %5
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_framework_owner() #4 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost20size_framework_owners6UInt32VyF"() #4 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_application_owner() #4 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost22size_application_owners6UInt32VyF"() #4 {
entry:
  ret i32 1
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_framework_failure() #4 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost22size_framework_failures6UInt32VyF"() #4 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_application_failure() #4 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost24size_application_failures6UInt32VyF"() #4 {
entry:
  ret i32 2
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_framework_cycle() #4 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost20size_framework_cycles6UInt32VyF"() #4 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_application_cycle() #4 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost22size_application_cycles6UInt32VyF"() #4 {
entry:
  ret i32 64
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_mutation_result() #4 {
entry:
  ret i32 4
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost20size_mutation_results6UInt32VyF"() #4 {
entry:
  ret i32 4
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_pipeline_result() #4 {
entry:
  ret i32 24
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost20size_pipeline_results6UInt32VyF"() #4 {
entry:
  ret i32 24
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_framework_first_failure() #4 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost28size_framework_first_failures6UInt32VyF"() #4 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define noundef i32 @size_first_failure() #4 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc noundef i32 @"$s24SignalAnalyzerTargetHost18size_first_failures6UInt32VyF"() #4 {
entry:
  ret i32 28
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read)
define internal swiftcc range(i32 16778265, 16843802) i32 @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17applyAdmittedWork17GiftUIRuntimeCore015RuntimePipelineF6ResultOyAA0ab5CycleG7FailureOGyF"(ptr nonnull readonly swiftself captures(none) dereferenceable(8) %0) unnamed_addr #5 {
entry:
  %1 = load i1, ptr %0, align 4
  %temp-coercion.coerced.sroa.0.0.insert.insert = select i1 %1, i32 16843801, i32 16778265
  ret i32 %temp-coercion.coerced.sroa.0.0.insert.insert
}

; Function Attrs: minsize optsize
define internal swiftcc range(i64 0, 8589934592) i64 @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV37publishSemanticAndObservableCandidate17GiftUIRuntimeCore32RuntimePipelinePublicationResultOyAA0ab5CycleG7FailureOGyF"() unnamed_addr #0 {
entry:
  %0 = tail call swiftcc i32 @"$s15GiftUIExecution16SemanticRevisionV8rawValueACs6UInt32V_tcfC"(i32 1)
  %1 = tail call swiftcc i64 @"$s17GiftUIRuntimeCore26RuntimePipelinePublicationV16semanticRevision7changedAC0A11UIExecution08SemanticH0V_SbtcfC"(i32 %0, i1 true)
  %temp-coercion.coerced1.sroa.0.0.insert.ext = and i64 %1, 8589934591
  ret i64 %temp-coercion.coerced1.sroa.0.0.insert.ext
}

; Function Attrs: minsize optsize
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV16finalizePipelineyyF"(ptr nonnull swiftself captures(none) dereferenceable(8) %0) unnamed_addr #0 {
entry:
  %.finalizations = getelementptr inbounds nuw i8, ptr %0, i64 4
  %1 = load i32, ptr %.finalizations, align 4
  %2 = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %1, i32 1)
  %3 = extractvalue { i32, i1 } %2, 1
  br i1 %3, label %6, label %4, !prof !17

4:                                                ; preds = %entry
  %5 = extractvalue { i32, i1 } %2, 0
  store i32 %5, ptr %.finalizations, align 4
  ret void

6:                                                ; preds = %entry
  tail call void asm sideeffect "", "n"(i32 0) #17
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP17applyAdmittedWorkAE0qsF6ResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore29RuntimePipelineMutationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 4)) %0, ptr readonly swiftself captures(none) dereferenceable(8) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #6 {
entry:
  %2 = tail call swiftcc i32 @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17applyAdmittedWork17GiftUIRuntimeCore015RuntimePipelineF6ResultOyAA0ab5CycleG7FailureOGyF"(ptr swiftself captures(none) dereferenceable(8) %1) #16
  %temp-coercion.coerced.sroa.0.0.extract.trunc = trunc i32 %2 to i24
  store i24 %temp-coercion.coerced.sroa.0.0.extract.trunc, ptr %0, align 1
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 3
  store i8 1, ptr %3, align 1
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #7 {
entry:
  store i16 -256, ptr %0, align 1
  ret void
}

; Function Attrs: minsize optsize
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP37publishSemanticAndObservableCandidateAE0qS17PublicationResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore32RuntimePipelinePublicationResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 6)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #0 {
entry:
  %2 = tail call swiftcc i64 @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV37publishSemanticAndObservableCandidate17GiftUIRuntimeCore32RuntimePipelinePublicationResultOyAA0ab5CycleG7FailureOGyF"() #16
  %temp-coercion.coerced.sroa.0.0.extract.trunc = trunc nuw nsw i64 %2 to i40
  store i40 %temp-coercion.coerced.sroa.0.0.extract.trunc, ptr %0, align 4
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 5
  store i8 0, ptr %3, align 1
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP15offerAndProduceAE0qS11OfferResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore26RuntimePipelineOfferResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 5)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #7 {
entry:
  store i32 1, ptr %0, align 4
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 4
  store i8 3, ptr %2, align 4
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP7cleanupyyAE0Q13CleanupActionOFTW"(i8 %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #4 {
entry:
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP16applyDispositionyyAE0qsU0VFTW"(i64 %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #4 {
entry:
  ret void
}

; Function Attrs: minsize optsize
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP08finalizeS0yyFTW"(ptr swiftself captures(none) dereferenceable(8) %0, ptr readnone captures(none) %Self, ptr readnone captures(none) %SelfWitnessTable) #0 {
entry:
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV16finalizePipelineyyF"(ptr swiftself captures(none) dereferenceable(8) %0) #16
  ret void
}

; Function Attrs: minsize optsize
define i32 @carrier_mutation_probe(i8 zeroext %0) #0 {
entry:
  %1 = tail call swiftcc i32 @"$s24SignalAnalyzerTargetHost20carrierMutationProbeys6UInt32Vs5UInt8VF"(i8 %0) #16
  ret i32 %1
}

; Function Attrs: minsize optsize
define swiftcc i32 @"$s24SignalAnalyzerTargetHost20carrierMutationProbeys6UInt32Vs5UInt8VF"(i8 %0) #0 {
entry:
  %1 = alloca %T24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV, align 4
  %2 = alloca %T17GiftUIRuntimeCore29RuntimeCompletePipelineResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG, align 8
  %3 = alloca %T15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OG, align 1
  %4 = alloca %T15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OG, align 1
  %5 = alloca %T15GiftUIExecution24SemanticCycleDispositionO, align 1
  %6 = alloca %T15GiftUIExecution24SemanticCycleDispositionO, align 1
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %1)
  %7 = icmp ne i8 %0, 0
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %1, align 4
  %.finalizations = getelementptr inbounds nuw i8, ptr %1, i64 4
  store i32 0, ptr %.finalizations, align 4
  call void @llvm.lifetime.start.p0(i64 21, ptr nonnull %2)
  %9 = tail call fastcc ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVAD17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAWl"() #14
  call swiftcc void @"$s17GiftUIRuntimeCore23RuntimeCompletePipelineO3run5ownerAA0deF6ResultOy12OwnerFailureQzGxz_tAA0defJ0RzRi_zlFZ"(ptr noalias nonnull sret(%swift.opaque) %2, ptr nonnull %1, ptr nonnull getelementptr inbounds nuw (i8, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMf", i64 16), ptr %9)
  %10 = getelementptr inbounds nuw i8, ptr %2, i64 20
  %11 = load i8, ptr %10, align 4
  %.not = icmp eq i8 %11, 1
  br i1 %.not, label %12, label %25

12:                                               ; preds = %entry
  %13 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %14 = load i64, ptr %13, align 8
  %15 = load i64, ptr %2, align 8
  %16 = lshr i64 %15, 8
  %17 = trunc i64 %16 to i8
  %18 = lshr i64 %15, 16
  %19 = trunc i64 %18 to i8
  call void @llvm.lifetime.end.p0(i64 21, ptr nonnull %2)
  %20 = call ptr @__swift_instantiateConcreteTypeFromMangledNameV2(ptr nonnull @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGMd", ptr nonnull @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGMR") #15
  call void @llvm.lifetime.start.p0(i64 2, ptr nonnull %3)
  store i8 %17, ptr %3, align 1
  %21 = getelementptr inbounds nuw i8, ptr %3, i64 1
  store i8 %19, ptr %21, align 1
  call void @llvm.lifetime.start.p0(i64 2, ptr nonnull %4)
  store i8 25, ptr %4, align 1
  %22 = getelementptr inbounds nuw i8, ptr %4, i64 1
  store i8 4, ptr %22, align 1
  %23 = tail call ptr @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGACyxGSQAAWl"() #14
  %24 = call swiftcc i1 @"$sSQ2eeoiySbx_xtFZTj"(ptr noalias nonnull %3, ptr noalias nonnull %4, ptr swiftself %20, ptr %20, ptr %23)
  call void @llvm.lifetime.end.p0(i64 2, ptr nonnull %4)
  call void @llvm.lifetime.end.p0(i64 2, ptr nonnull %3)
  br i1 %24, label %26, label %35

25:                                               ; preds = %entry
  call void @llvm.lifetime.end.p0(i64 21, ptr nonnull %2)
  br label %35

26:                                               ; preds = %12
  %27 = lshr i64 %14, 8
  %28 = trunc i64 %27 to i8
  %29 = load i32, ptr %.finalizations, align 4
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %5)
  store i8 %28, ptr %5, align 1
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %6)
  store i8 2, ptr %6, align 1
  %30 = tail call ptr @"$s15GiftUIExecution24SemanticCycleDispositionOACSQAAWl"() #14
  %31 = call swiftcc i1 @"$sSQ2eeoiySbx_xtFZTj"(ptr noalias nonnull %5, ptr noalias nonnull %6, ptr nonnull swiftself @"$s15GiftUIExecution24SemanticCycleDispositionON", ptr nonnull @"$s15GiftUIExecution24SemanticCycleDispositionON", ptr %30)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %6)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %5)
  %. = select i1 %31, i32 2, i32 0
  %32 = call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %29, i32 %.)
  %33 = extractvalue { i32, i1 } %32, 0
  %34 = extractvalue { i32, i1 } %32, 1
  br i1 %34, label %37, label %35, !prof !17

35:                                               ; preds = %12, %26, %25
  %36 = phi i32 [ 0, %25 ], [ %33, %26 ], [ 0, %12 ]
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %1)
  ret i32 %36

37:                                               ; preds = %26
  call void asm sideeffect "", "n"(i32 0) #17
  call void @llvm.trap()
  unreachable
}

; Function Attrs: minsize optsize
declare swiftcc void @"$s17GiftUIRuntimeCore23RuntimeCompletePipelineO3run5ownerAA0deF6ResultOy12OwnerFailureQzGxz_tAA0defJ0RzRi_zlFZ"(ptr noalias sret(%swift.opaque), ptr, ptr, ptr) local_unnamed_addr #0

; Function Attrs: minsize nofree noinline nosync nounwind optsize memory(none)
define internal fastcc ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVAD17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAWl"() unnamed_addr #2 {
entry:
  %0 = load ptr, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVAD17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAWL", align 8
  %1 = icmp eq ptr %0, null
  br i1 %1, label %cacheIsNull, label %cont

cacheIsNull:                                      ; preds = %entry
  %2 = tail call ptr @swift_getWitnessTable(ptr nonnull @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAMc", ptr nonnull getelementptr inbounds nuw (i8, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMf", i64 16), ptr undef) #15
  store atomic ptr %2, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVAD17GiftUIRuntimeCore023RuntimeCompletePipelineG0AAWL" release, align 8
  br label %cont

cont:                                             ; preds = %cacheIsNull, %entry
  %3 = phi ptr [ %0, %entry ], [ %2, %cacheIsNull ]
  ret ptr %3
}

; Function Attrs: minsize mustprogress nofree noinline nounwind optsize willreturn memory(read)
define linkonce_odr hidden ptr @__swift_instantiateConcreteTypeFromMangledNameV2(ptr %0, ptr %1) local_unnamed_addr #8 {
entry:
  %2 = load atomic ptr, ptr %0 monotonic, align 8
  %3 = icmp eq ptr %2, null
  %4 = ptrtoint ptr %2 to i64
  %5 = and i64 %4, 1
  %6 = icmp ne i64 %5, 0
  %7 = or i1 %3, %6
  br i1 %7, label %10, label %8

8:                                                ; preds = %10, %entry
  %9 = phi ptr [ %2, %entry ], [ %17, %10 ]
  ret ptr %9

10:                                               ; preds = %entry
  %11 = load i64, ptr %1, align 8
  %12 = ashr i64 %11, 32
  %sext = shl i64 %11, 32
  %13 = ashr exact i64 %sext, 32
  %14 = ptrtoint ptr %1 to i64
  %15 = add i64 %13, %14
  %16 = inttoptr i64 %15 to ptr
  %17 = tail call swiftcc ptr @swift_getTypeByMangledNameInContext2(ptr %16, i64 %12, ptr null, ptr null) #18
  store atomic ptr %17, ptr %0 monotonic, align 8
  br label %8
}

; Function Attrs: nounwind memory(argmem: readwrite)
declare swiftcc ptr @swift_getTypeByMangledNameInContext2(ptr, i64, ptr, ptr) local_unnamed_addr #9

; Function Attrs: minsize nofree noinline nosync nounwind optsize memory(none)
define linkonce_odr hidden ptr @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGACyxGSQAAWl"() local_unnamed_addr #2 {
entry:
  %0 = load ptr, ptr @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGACyxGSQAAWL", align 8
  %1 = icmp eq ptr %0, null
  br i1 %1, label %cacheIsNull, label %cont

cacheIsNull:                                      ; preds = %entry
  %2 = tail call ptr @__swift_instantiateConcreteTypeFromMangledNameAbstractV2(ptr nonnull @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGMd", ptr nonnull @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGMR") #15
  %3 = tail call ptr @swift_getWitnessTable(ptr nonnull @"$s15GiftUIExecution15RunCycleFailureOyxGSQAAMc", ptr %2, ptr undef) #15
  store atomic ptr %3, ptr @"$s15GiftUIExecution15RunCycleFailureOy24SignalAnalyzerTargetHost0fgd5OwnerE0OGACyxGSQAAWL" release, align 8
  br label %cont

cont:                                             ; preds = %cacheIsNull, %entry
  %4 = phi ptr [ %0, %entry ], [ %3, %cacheIsNull ]
  ret ptr %4
}

; Function Attrs: minsize mustprogress nofree noinline nounwind optsize willreturn memory(read)
define linkonce_odr hidden ptr @__swift_instantiateConcreteTypeFromMangledNameAbstractV2(ptr %0, ptr %1) local_unnamed_addr #8 {
entry:
  %2 = load atomic ptr, ptr %0 monotonic, align 8
  %3 = icmp eq ptr %2, null
  br i1 %3, label %9, label %4

4:                                                ; preds = %9, %entry
  %5 = phi ptr [ %2, %entry ], [ %19, %9 ]
  %6 = ptrtoint ptr %5 to i64
  %7 = and i64 %6, -2
  %8 = inttoptr i64 %7 to ptr
  ret ptr %8

9:                                                ; preds = %entry
  %10 = load i64, ptr %1, align 8
  %11 = ashr i64 %10, 32
  %sext = shl i64 %10, 32
  %12 = ashr exact i64 %sext, 32
  %13 = ptrtoint ptr %1 to i64
  %14 = add i64 %12, %13
  %15 = inttoptr i64 %14 to ptr
  %16 = tail call swiftcc ptr @swift_getTypeByMangledNameInContextInMetadataState2(i64 255, ptr %15, i64 %11, ptr null, ptr null) #18
  %17 = ptrtoint ptr %16 to i64
  %18 = or i64 %17, 1
  %19 = inttoptr i64 %18 to ptr
  store atomic ptr %19, ptr %0 monotonic, align 8
  br label %4
}

; Function Attrs: nounwind memory(argmem: readwrite)
declare swiftcc ptr @swift_getTypeByMangledNameInContextInMetadataState2(i64, ptr, i64, ptr, ptr) local_unnamed_addr #9

; Function Attrs: minsize nofree noinline nosync nounwind optsize memory(none)
define linkonce_odr hidden ptr @"$s15GiftUIExecution24SemanticCycleDispositionOACSQAAWl"() local_unnamed_addr #2 {
entry:
  %0 = load ptr, ptr @"$s15GiftUIExecution24SemanticCycleDispositionOACSQAAWL", align 8
  %1 = icmp eq ptr %0, null
  br i1 %1, label %cacheIsNull, label %cont

cacheIsNull:                                      ; preds = %entry
  %2 = tail call ptr @swift_getWitnessTable(ptr nonnull @"$s15GiftUIExecution24SemanticCycleDispositionOSQAAMc", ptr nonnull @"$s15GiftUIExecution24SemanticCycleDispositionON", ptr undef) #15
  store atomic ptr %2, ptr @"$s15GiftUIExecution24SemanticCycleDispositionOACSQAAWL" release, align 8
  br label %cont

cont:                                             ; preds = %cacheIsNull, %entry
  %3 = phi ptr [ %0, %entry ], [ %2, %cacheIsNull ]
  ret ptr %3
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #10

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #11

; Function Attrs: minsize nounwind optsize
define linkonce_odr hidden ptr @__swift_memcpy1_1(ptr %0, ptr %1, ptr %2) #12 {
entry:
  %3 = load i8, ptr %1, align 1
  store i8 %3, ptr %0, align 1
  ret ptr %0
}

; Function Attrs: minsize nounwind optsize
define linkonce_odr hidden void @__swift_noop_void_return(ptr %0, ptr %1) #12 {
entry:
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read)
define internal i32 @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwet"(ptr noalias readonly captures(none) %value, i32 %numEmptyCases, ptr readnone captures(none) %SignalAnalyzerCycleOwnerFailure) #5 {
entry:
  %0 = icmp eq i32 %numEmptyCases, 0
  br i1 %0, label %26, label %1

1:                                                ; preds = %entry
  %2 = add i32 %numEmptyCases, 255
  %3 = icmp ult i32 %2, 65280
  %4 = icmp ult i32 %2, 16776960
  %5 = select i1 %4, i32 2, i32 4
  %6 = select i1 %3, i32 1, i32 %5
  %7 = getelementptr inbounds nuw i8, ptr %value, i64 1
  switch i32 %6, label %16 [
    i32 4, label %14
    i32 1, label %8
    i32 2, label %11
  ]

8:                                                ; preds = %1
  %9 = load i8, ptr %7, align 1
  %10 = zext i8 %9 to i32
  br label %17

11:                                               ; preds = %1
  %12 = load i16, ptr %7, align 1
  %13 = zext i16 %12 to i32
  br label %17

14:                                               ; preds = %1
  %15 = load i32, ptr %7, align 1
  br label %17

16:                                               ; preds = %1
  unreachable

17:                                               ; preds = %14, %11, %8
  %18 = phi i32 [ %10, %8 ], [ %13, %11 ], [ %15, %14 ]
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %26, label %20

20:                                               ; preds = %17
  %21 = shl i32 %18, 8
  %22 = load i8, ptr %value, align 1
  %23 = zext i8 %22 to i32
  %24 = add i32 %21, -255
  %25 = add i32 %24, %23
  br label %26

26:                                               ; preds = %entry, %17, %20
  %27 = phi i32 [ %25, %20 ], [ 0, %17 ], [ 0, %entry ]
  ret i32 %27
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal void @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwst"(ptr noalias writeonly captures(none) %value, i32 %whichCase, i32 %numEmptyCases, ptr readnone captures(none) %SignalAnalyzerCycleOwnerFailure) #7 {
entry:
  %0 = getelementptr inbounds nuw i8, ptr %value, i64 1
  %.not = icmp eq i32 %numEmptyCases, 0
  br i1 %.not, label %7, label %1

1:                                                ; preds = %entry
  %2 = add i32 %numEmptyCases, 255
  %3 = icmp ult i32 %2, 65280
  %4 = icmp ult i32 %2, 16776960
  %5 = select i1 %4, i32 2, i32 4
  %6 = select i1 %3, i32 1, i32 %5
  br label %7

7:                                                ; preds = %1, %entry
  %8 = phi i32 [ 0, %entry ], [ %6, %1 ]
  %9 = icmp eq i32 %whichCase, 0
  br i1 %9, label %10, label %15

10:                                               ; preds = %7
  switch i32 %8, label %14 [
    i32 0, label %26
    i32 1, label %11
    i32 2, label %12
    i32 4, label %13
  ]

11:                                               ; preds = %10
  store i8 0, ptr %0, align 1
  br label %26

12:                                               ; preds = %10
  store i16 0, ptr %0, align 1
  br label %26

13:                                               ; preds = %10
  store i32 0, ptr %0, align 1
  br label %26

14:                                               ; preds = %10
  unreachable

15:                                               ; preds = %7
  %16 = add i32 %whichCase, -1
  %17 = lshr i32 %16, 8
  %18 = add nuw nsw i32 %17, 1
  %19 = trunc i32 %16 to i8
  store i8 %19, ptr %value, align 1
  switch i32 %8, label %25 [
    i32 0, label %26
    i32 1, label %20
    i32 2, label %22
    i32 4, label %24
  ]

20:                                               ; preds = %15
  %21 = trunc i32 %18 to i8
  store i8 %21, ptr %0, align 1
  br label %26

22:                                               ; preds = %15
  %23 = trunc i32 %18 to i16
  store i16 %23, ptr %0, align 1
  br label %26

24:                                               ; preds = %15
  store i32 %18, ptr %0, align 1
  br label %26

25:                                               ; preds = %15
  unreachable

26:                                               ; preds = %11, %12, %13, %10, %20, %22, %24, %15
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read)
define internal range(i32 0, 2) i32 @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwug"(ptr noalias readonly captures(none) %value, ptr readnone captures(none) %SignalAnalyzerCycleOwnerFailure) #5 {
entry:
  %0 = load i8, ptr %value, align 1
  %1 = lshr i8 %0, 4
  %2 = and i8 %1, 1
  %3 = zext nneg i8 %2 to i32
  ret i32 %3
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwup"(ptr noalias captures(none) %value, ptr readnone captures(none) %SignalAnalyzerCycleOwnerFailure) #6 {
entry:
  %0 = load i8, ptr %value, align 1
  %1 = and i8 %0, -17
  store i8 %1, ptr %value, align 1
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite)
define internal void @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOwui"(ptr noalias captures(none) %value, i32 %tag, ptr readnone captures(none) %SignalAnalyzerCycleOwnerFailure) #6 {
entry:
  %0 = load i8, ptr %value, align 1
  %1 = and i8 %0, -17
  %2 = trunc i32 %tag to i8
  %3 = shl i8 %2, 4
  %4 = and i8 %3, 16
  %5 = or disjoint i8 %1, %4
  store i8 %5, ptr %value, align 1
  ret void
}

; Function Attrs: minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define swiftcc %swift.metadata_response @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMa"(i64 %0) #13 {
entry:
  ret %swift.metadata_response { ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr }>, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMf", i32 0, i32 2), i64 0 }
}

; Function Attrs: minsize nounwind optsize
define linkonce_odr hidden ptr @__swift_memcpy8_4(ptr %0, ptr %1, ptr %2) #12 {
entry:
  %3 = load i64, ptr %1, align 4
  store i64 %3, ptr %0, align 4
  ret ptr %0
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read)
define internal i32 @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVwet"(ptr noalias readonly captures(none) %value, i32 %numEmptyCases, ptr readnone captures(none) %InlineMutationOwner) #5 {
entry:
  %0 = icmp eq i32 %numEmptyCases, 0
  br i1 %0, label %21, label %1

1:                                                ; preds = %entry
  %2 = icmp ugt i32 %numEmptyCases, 254
  br i1 %2, label %3, label %11

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %value, i64 8
  %5 = load i8, ptr %4, align 1
  %6 = icmp eq i8 %5, 0
  br i1 %6, label %11, label %7

7:                                                ; preds = %3
  %8 = load i64, ptr %value, align 1
  %9 = trunc i64 %8 to i32
  %10 = add i32 %9, 254
  br label %21

11:                                               ; preds = %3, %1
  %12 = load i8, ptr %value, align 4
  %13 = icmp ult i8 %12, 2
  br i1 %13, label %21, label %14

14:                                               ; preds = %11
  %15 = zext i8 %12 to i31
  %16 = and i31 %15, 1
  %17 = and i31 %15, 254
  %18 = add nsw i31 %17, -2
  %19 = or disjoint i31 %18, %16
  %20 = zext nneg i31 %19 to i32
  br label %21

21:                                               ; preds = %entry, %11, %14, %7
  %22 = phi i32 [ %10, %7 ], [ -1, %11 ], [ %20, %14 ], [ -1, %entry ]
  %23 = add i32 %22, 1
  ret i32 %23
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVwst"(ptr noalias writeonly captures(none) %value, i32 %whichCase, i32 %numEmptyCases, ptr readnone captures(none) %InlineMutationOwner) #7 {
entry:
  %0 = getelementptr inbounds nuw i8, ptr %value, i64 8
  %1 = icmp ugt i32 %numEmptyCases, 254
  %2 = icmp ult i32 %whichCase, 255
  br i1 %2, label %3, label %14

3:                                                ; preds = %entry
  br i1 %1, label %4, label %5

4:                                                ; preds = %3
  store i8 0, ptr %0, align 4
  br label %5

5:                                                ; preds = %3, %4
  %6 = icmp eq i32 %whichCase, 0
  br i1 %6, label %18, label %7

7:                                                ; preds = %5
  %8 = trunc nuw i32 %whichCase to i8
  %9 = add i8 %8, -1
  %10 = and i8 %9, 1
  %11 = and i8 %9, -2
  %12 = add nuw i8 %11, 2
  %13 = or disjoint i8 %12, %10
  store i8 %13, ptr %value, align 4
  br label %18

14:                                               ; preds = %entry
  %15 = add i32 %whichCase, -255
  %16 = zext i32 %15 to i64
  store i64 %16, ptr %value, align 4
  br i1 %1, label %17, label %18

17:                                               ; preds = %14
  store i8 1, ptr %0, align 4
  br label %18

18:                                               ; preds = %14, %17, %7, %5
  ret void
}

; Function Attrs: minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none)
define internal swiftcc %swift.metadata_response @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMa"(i64 %0) #13 {
entry:
  ret %swift.metadata_response { ptr getelementptr inbounds (<{ ptr, ptr, i64, ptr, i32, i32 }>, ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLVMf", i32 0, i32 2), i64 0 }
}

; Function Attrs: minsize nofree noinline nosync nounwind optsize memory(none)
define internal swiftcc ptr @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AA0G7FailureAeFP_SQWT"(ptr readnone captures(none) %InlineMutationOwner.OwnerFailure, ptr readnone captures(none) %InlineMutationOwner, ptr readnone captures(none) %InlineMutationOwner.RuntimeCompletePipelineOwner) #2 {
entry:
  %0 = tail call ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOACSQAAWl"() #14
  ret ptr %0
}

; Function Attrs: minsize nofree noinline nosync nounwind optsize memory(none)
define linkonce_odr hidden ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOACSQAAWl"() local_unnamed_addr #2 {
entry:
  %0 = load ptr, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOACSQAAWL", align 8
  %1 = icmp eq ptr %0, null
  br i1 %1, label %cacheIsNull, label %cont

cacheIsNull:                                      ; preds = %entry
  %2 = tail call ptr @swift_getWitnessTable(ptr nonnull @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOSQAAMc", ptr nonnull getelementptr inbounds nuw (i8, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOMf", i64 16), ptr undef) #15
  store atomic ptr %2, ptr @"$s24SignalAnalyzerTargetHost0aB17CycleOwnerFailureOACSQAAWL" release, align 8
  br label %cont

cont:                                             ; preds = %cacheIsNull, %entry
  %3 = phi ptr [ %0, %entry ], [ %2, %cacheIsNull ]
  ret ptr %3
}

; Function Attrs: minsize optsize
declare swiftcc i32 @"$s15GiftUIExecution16SemanticRevisionV8rawValueACs6UInt32V_tcfC"(i32) local_unnamed_addr #0

; Function Attrs: minsize optsize
declare swiftcc i64 @"$s17GiftUIRuntimeCore26RuntimePipelinePublicationV16semanticRevision7changedAC0A11UIExecution08SemanticH0V_SbtcfC"(i32, i1) local_unnamed_addr #0

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP12admitAndSealAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7 {
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP42beginObservableCandidateAndExpandSemanticsAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7 {
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP13resolveLayoutAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7 {
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP27invokeCanvasesAndDerivePlanAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7 {
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP23preflightCombinedRenderAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7 {
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP25buildInteractionCandidateAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7 {
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7
  ret void
}

; Function Attrs: minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write)
define internal swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP17allocateCandidateAE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7 {
  tail call swiftcc void @"$s24SignalAnalyzerTargetHost19InlineMutationOwner33_237593586C97A618E94E19970675F7E8LLV17GiftUIRuntimeCore023RuntimeCompletePipelineG0AaeFP016freezeObservableF0AE0qS10StepResultOy0G7FailureQzGyFTW"(ptr noalias writeonly sret(%T17GiftUIRuntimeCore25RuntimePipelineStepResultOy24SignalAnalyzerTargetHost0hI17CycleOwnerFailureOG) captures(none) initializes((0, 2)) %0, ptr readnone swiftself captures(none) %1, ptr readnone captures(none) %2, ptr readnone captures(none) %3) #7
  ret void
}

attributes #0 = { minsize optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { minsize nofree noinline nosync nounwind optsize memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #3 = { nofree nounwind memory(read) }
attributes #4 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #5 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: read) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #6 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: readwrite) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #7 = { minsize mustprogress nofree norecurse nosync nounwind optsize willreturn memory(argmem: write) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #8 = { minsize mustprogress nofree noinline nounwind optsize willreturn memory(read) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #9 = { nounwind memory(argmem: readwrite) }
attributes #10 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #12 = { minsize nounwind optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #13 = { minsize mustprogress nofree noinline norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #14 = { nounwind memory(none) }
attributes #15 = { nounwind memory(read) }
attributes #16 = { noinline }
attributes #17 = { nounwind }
attributes #18 = { nounwind memory(argmem: read) }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5, !6, !7, !8, !9, !10, !11}
!swift.module.flags = !{!12}
!llvm.linker.options = !{!13, !14, !15, !16}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 26, i32 5]}
!1 = !{i32 1, !"Objective-C Version", i32 2}
!2 = !{i32 1, !"Objective-C Image Info Version", i32 0}
!3 = !{i32 1, !"Objective-C Image Info Section", !"__DATA,__objc_imageinfo,regular,no_dead_strip"}
!4 = !{i32 4, !"Objective-C Garbage Collection", i32 100861696}
!5 = !{i32 1, !"Objective-C Class Properties", i32 64}
!6 = !{i32 1, !"Objective-C Enforce ClassRO Pointer Signing", i8 0}
!7 = !{i32 1, !"wchar_size", i32 4}
!8 = !{i32 8, !"PIC Level", i32 2}
!9 = !{i32 7, !"uwtable", i32 1}
!10 = !{i32 7, !"frame-pointer", i32 1}
!11 = !{i32 1, !"Swift Version", i32 7}
!12 = !{!"standard-library", i1 false}
!13 = !{!"-lswiftCore"}
!14 = !{!"-lswift_StringProcessing"}
!15 = !{!"-lswift_Concurrency"}
!16 = !{!"-lobjc"}
!17 = !{!"branch_weights", !"expected", i32 1, i32 2000}
