import GiftUIExecution
import GiftUIRuntimeCore
import SignalAnalyzerPresentation
@_cdecl("size_framework_owner")
public func size_framework_owner() -> UInt32 { UInt32(MemoryLayout<RuntimeOwnerFailure>.stride) }
@_cdecl("size_application_owner")
public func size_application_owner() -> UInt32 { UInt32(MemoryLayout<SignalAnalyzerCycleOwnerFailure>.stride) }
@_cdecl("size_framework_failure")
public func size_framework_failure() -> UInt32 { UInt32(MemoryLayout<RunCycleFailure<RuntimeOwnerFailure>>.stride) }
@_cdecl("size_application_failure")
public func size_application_failure() -> UInt32 { UInt32(MemoryLayout<RunCycleFailure<SignalAnalyzerCycleOwnerFailure>>.stride) }
@_cdecl("size_framework_cycle")
public func size_framework_cycle() -> UInt32 { UInt32(MemoryLayout<RunCycleResult<RuntimeOwnerFailure>>.stride) }
@_cdecl("size_application_cycle")
public func size_application_cycle() -> UInt32 { UInt32(MemoryLayout<RunCycleResult<SignalAnalyzerCycleOwnerFailure>>.stride) }
@_cdecl("size_mutation_result")
public func size_mutation_result() -> UInt32 { UInt32(MemoryLayout<RuntimePipelineMutationResult<SignalAnalyzerCycleOwnerFailure>>.stride) }
@_cdecl("size_pipeline_result")
public func size_pipeline_result() -> UInt32 { UInt32(MemoryLayout<RuntimeCompletePipelineResult<SignalAnalyzerCycleOwnerFailure>>.stride) }
@_cdecl("size_framework_first_failure")
public func size_framework_first_failure() -> UInt32 { UInt32(MemoryLayout<RuntimeFocusedFailureState<RuntimeOwnerFailure>>.stride) }
@_cdecl("size_first_failure")
public func size_first_failure() -> UInt32 { UInt32(MemoryLayout<RuntimeFocusedFailureState<SignalAnalyzerCycleOwnerFailure>>.stride) }

private struct InlineMutationOwner: RuntimeCompletePipelineOwner {
    typealias OwnerFailure = SignalAnalyzerCycleOwnerFailure
    let applied: Bool
    var finalizations: UInt32 = 0
    mutating func admitAndSeal() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func applyAdmittedWork() -> RuntimePipelineMutationResult<OwnerFailure> {
        .failure(.focusedOwner(.application(.captureRevisionMismatch)), mutationApplied: applied)
    }
    mutating func freezeObservableMutation() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func beginObservableCandidateAndExpandSemantics() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func resolveLayout() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func invokeCanvasesAndDerivePlan() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func preflightCombinedRender() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func buildInteractionCandidate() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func publishSemanticAndObservableCandidate() -> RuntimePipelinePublicationResult<OwnerFailure> {
        .published(RuntimePipelinePublication(semanticRevision: SemanticRevision(rawValue: 1), changed: true))
    }
    mutating func allocateCandidate() -> RuntimePipelineStepResult<OwnerFailure> { .advanced }
    mutating func offerAndProduce() -> RuntimePipelineOfferResult<OwnerFailure> { .backpressured }
    mutating func cleanup(_: RuntimeCleanupAction) {}
    mutating func applyDisposition(_: RuntimePipelineDisposition) {}
    mutating func finalizePipeline() { finalizations += 1 }
}

@_cdecl("carrier_mutation_probe")
public func carrierMutationProbe(_ applied: UInt8) -> UInt32 {
    var owner = InlineMutationOwner(applied: applied != 0)
    guard case .failed(let record) = RuntimeCompletePipeline.run(owner: &owner),
        record.failure == .focusedOwner(.application(.captureRevisionMismatch)) else { return 0 }
    return owner.finalizations + (record.disposition.semanticDisposition == .dirty ? 2 : 0)
}
