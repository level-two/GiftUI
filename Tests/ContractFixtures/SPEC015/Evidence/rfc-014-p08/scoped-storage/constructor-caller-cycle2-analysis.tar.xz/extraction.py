import hashlib,importlib.util,json,lzma,pathlib,re,subprocess,tarfile
root=pathlib.Path.cwd();obj=root/'.build/nrf52840/contracts/p08-counter-9sc79u_m/P08CounterRuntime.o';sp=importlib.util.spec_from_file_location('facts',root/'scripts/contracts/p08_layout_facts.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);elf=m.ELF(obj.read_bytes());byname={s['name']:s for s in elf.symbols if s['type']==2 and s['size']}
old={};a=root/'Tests/ContractFixtures/SPEC015/Evidence/rfc-014-p08/scoped-storage/constructor-caller-cycle1-analysis.tar.xz'
with tarfile.open(a) as t:
 for f in t.getmembers():
  if f.name.endswith('bounded-frames-and-calls.json'):
   for r in json.load(t.extractfile(f))['rows']:old[r['section']]=r
wanted=[4269,4281,4029,4037,4044,4048,210,10407,3433,3967,3863,3823,3740,3728,3716,3477,3990,4301,4308,3238,3882,3994]+[3437,3441,3445,3449,3453,3457,3461,3465,3469,3473]
selected={};missing=[]
for n in wanted:
 if n not in old:missing.append(n);continue
 v=byname.get(old[n]['symbol']['name'])
 if v:selected[v['owner']]=v
 else:missing.append(n)
for n,v in byname.items():
 if any(x in n for x in ['p08RequireSecondNamespaces','p08ConstructStaticHost','p08CheckStaticHostConfiguration','p08RunPreparedStaticHost','p08InstallEmbeddedHostPlan','p08ClearHostPlan','p08RunOneMetadataHost','p08RunMetadataTwoHosts','p08RunStaticSessionPhase','p08RunStaticHostPhase','p08CheckStaticHostJoins','prepareSession','matchesBackend','matchesRoot','matchesAction','matchesCandidate']):selected[v['owner']]=v
for n,v in byname.items():
 if 'P08EmbeddedOuter' in n and n.endswith('VfD'):selected[v['owner']]=v
for sym in list(selected.values()):
 for rel in elf.relocations(sym):
  if 'withSemanticRecordStore' in rel['symbol']:
   v=elf.symbol_tables[rel['symbol_table']][rel['symbol_index']];selected[v['owner']]=v
packet=root/'Tests/ContractFixtures/SPEC015/Evidence/rfc-014-p08/scoped-storage/constructor-caller-cycle2-screen';packet.mkdir(exist_ok=True)
sections=sorted(selected);symbols=[selected[n] for n in sections];tool=root/'.toolchains/nrf52840/zephyr-sdk-0.17.4/arm-zephyr-eabi/bin/arm-zephyr-eabi-objdump';demangler=root/'.toolchains/host/swift-6.4.0-RELEASE-osx/usr/bin/swift-demangle';names=subprocess.run([str(demangler),'--compact'],input='\n'.join(s['name'] for s in symbols)+'\n',text=True,capture_output=True,check=True).stdout.splitlines();rows=[]
for n,sym,name in zip(sections,symbols,names):
 argv=[str(tool),'-dr','--start-address=0','--stop-address=128','-j',elf.sections[n]['name'],str(obj)];text=subprocess.run(argv,text=True,capture_output=True,check=True).stdout;(packet/f'prologue-{n}.txt.xz').write_bytes(lzma.compress(text.encode()));instructions=[]
 for line in text.splitlines():
  match=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{4}\s+)+(.+)',line)
  if match:instructions.append((int(match[1],16),match[2].strip()))
 frame=0;terms=[];unknown=[]
 for addr,ins in instructions:
  op=ins.split()[0];operands=ins[len(op):].strip()
  if op.startswith(('bl','b.')) or op in ('b','bx','cbz','cbnz'):break
  if op in ('push','push.w','vpush') or op in ('stmdb','stmdb.w','vstmdb') and operands.startswith('sp!'):
   regs=re.search(r'\{([^}]+)\}',operands).group(1);count=0
   for reg in regs.split(','):
    reg=reg.strip()
    if '-' in reg:
     x,y=reg.split('-');count+=int(re.search(r'\d+',y).group())-int(re.search(r'\d+',x).group())+1
    else:count+=1
   amount=count*(8 if op.startswith('v') else 4);frame+=amount;terms.append([addr,ins,amount])
  elif re.match(r'sub(?:\.w|w)?$',op) and re.match(r'sp,\s*(?:sp,\s*)?#',operands):
   amount=int(re.search(r'#(0x[0-9a-f]+|[0-9]+)',operands).group(1),0);frame+=amount;terms.append([addr,ins,amount])
  elif re.match(r'str(?:\.w)?$',op) and re.search(r'\[sp,\s*#-(0x[0-9a-f]+|[0-9]+)\]!',operands):
   amount=int(re.search(r'#-(0x[0-9a-f]+|[0-9]+)',operands).group(1),0);frame+=amount;terms.append([addr,ins,amount])
  elif operands.startswith('sp,') and op.startswith(('sub','bic','bfc','and')):unknown.append([addr,ins])
 relocs=elf.relocations(sym)
 for rel in relocs:
  target=elf.symbol_tables[rel['symbol_table']][rel['symbol_index']];rel.update(target_section=target['owner'],target_type=target['type'],target_size=target['size'])
 rows.append(dict(section=n,symbol=sym,demangled=name,entry_fixed_stack_lower_bound=frame,prologue_terms=terms,unknown_stack_adjustments=unknown,first_instructions=instructions,relocations=relocs,command=argv))
(packet/'bounded-frames-and-calls.json').write_text(json.dumps(dict(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),parser_scope='fixed prologue before first branch/call; lower bound only; sub/sub.w/subw included',missing_prior_symbols=missing,rows=rows),indent=2)+'\n')
for r in rows:print(r['section'],r['entry_fixed_stack_lower_bound'],r['demangled'][:115])
