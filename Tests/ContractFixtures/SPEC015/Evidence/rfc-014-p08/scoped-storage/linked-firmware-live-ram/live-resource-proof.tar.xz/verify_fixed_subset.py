#!/usr/bin/env python3
"""Read-only mechanical check of the selected fixed-entry ledger, not a whole-program stack analyser.
The separately recorded source/CFG custody proof is a required premise; this script does not establish path feasibility.
"""
import argparse, hashlib, json, pathlib, re, struct, subprocess
p=argparse.ArgumentParser();p.add_argument('--elf',required=True,type=pathlib.Path);p.add_argument('--objdump',required=True,type=pathlib.Path);a=p.parse_args();base=pathlib.Path(__file__).resolve().parent
ledger=json.loads((base/'required-live-fixed-subset.json').read_text());ram=json.loads((base/'ram-reconciliation.json').read_text());binary=a.elf.read_bytes();assert hashlib.sha256(binary).hexdigest()==ledger['elf_sha256']==ram['elf_sha256']
raw=subprocess.run([str(a.objdump),'-d',str(a.elf)],check=True,capture_output=True,text=True).stdout;instructions={}
for line in raw.splitlines():
 m=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{4}\s+)+(.+)',line)
 if m:instructions[int(m[1],16)]=m[2].strip()
def norm(s):return ' '.join(s.split())
def amount(ins):
 if re.match(r'(push|stmdb(?:\.w)?)\s+',ins):
  assert 'sp!' in ins or ins.startswith('push');regs=re.search(r'\{([^}]+)\}',ins)[1].split(',');assert all('-' not in x for x in regs);return 4*len(regs)
 m=re.match(r'subw?(?:\.w)?\s+sp,(?:\s*sp,)?\s*#(\d+)',ins);assert m,ins;return int(m[1])
for f in ledger['frames']:
 assert f['terms'] and (f['terms'][0][0]==f['address'] or f['address']==0x2c73c and f['terms'][0][0]==0x2c744);previous=f['address']-1
 for pc,ins,n in f['terms']:
  assert f['address']<=pc<f['address']+f['size'] and pc>previous;previous=pc
  assert norm(instructions[pc])==norm(ins),(hex(pc),instructions.get(pc),ins)
  assert amount(ins)==n
  # Every charged term precedes the first control transfer or SP alignment in this entry.
  for q,i in instructions.items():
   if f['address']<=q<pc and f['address']!=0x2c73c:
    op=i.split()[0];assert not (op.startswith('b') and not op.startswith(('bic','bfc')) or op in ('cbz','cbnz','pop')), (hex(f['address']),i)
 assert sum(t[2] for t in f['terms'])==f['reserved_bytes']
selected=sum(f['reserved_bytes'] for f in ledger['frames']);assert selected==ledger['selected_bytes']==56888
phoff=struct.unpack_from('<I',binary,28)[0];ents,n=struct.unpack_from('<HH',binary,42);segments=[]
for j in range(n):
 typ,off,va,pa,fs,ms,fl,al=struct.unpack_from('<8I',binary,phoff+j*ents)
 if typ==1 and 0x20000000<=va<0x20040000:segments.append((va,ms))
segments.sort();assert all(segments[j][0]+segments[j][1]<=segments[j+1][0] for j in range(len(segments)-1));total=sum(ms for va,ms in segments);assert total==170620
# ELF32 symbol table: verify both actual stack reservations including their guard.
shoff=struct.unpack_from('<I',binary,32)[0];shents,shnum=struct.unpack_from('<HH',binary,46);sections=[struct.unpack_from('<10I',binary,shoff+j*shents) for j in range(shnum)];stacks={}
for s in sections:
 if s[1]!=2:continue
 strings=sections[s[6]];names=binary[strings[4]:strings[4]+strings[5]]
 for off in range(s[4],s[4]+s[5],s[9]):
  name,value,size,info,other,owner=struct.unpack_from('<IIIBBH',binary,off);name=names[name:names.index(b'\0',name)].decode()
  if name in ('z_main_stack','z_interrupt_stacks'):stacks[name]=(value,size)
assert stacks['z_main_stack']==(0x20022e40,27712);assert stacks['z_interrupt_stacks']==(0x20022600,2112)
assert stacks['z_main_stack'][1]-27648==64 and stacks['z_interrupt_stacks'][1]-2048==64
assert all(any(va<=v and v+sz<=va+ms for va,ms in segments) for v,sz in stacks.values())
other=total-27648;required=other+selected;assert other==142972 and required==199860 and required-196608==3252
print(json.dumps(dict(mechanical_ledger='PASS',source_feasibility='separate required audit premise',selected_frames=len(ledger['frames']),selected_stack_lower_bound=selected,other_ram_including_guards=other,whole_ram_lower_bound=required,limit=196608,lower_bound_excess=3252,complete_peak=False,sufficient_stack_reservation=None),indent=2))
