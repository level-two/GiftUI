# Source feasibility and simultaneous fixed-frame custody

The mechanical verifier checks bytes, frame arithmetic and RAM. It deliberately does
not claim to prove path feasibility. The following is the separate source/CFG premise.
All addresses are Thumb-cleared identities in ELF e649c5d26a676140b473e8fa1de5b075a479d8282a7f6d69e0034fb215884c38.
Complete selected bodies and current source snapshots accompany the ledger.

1. `counter_main.c` supplies a nonnil backing pointer and the exact138880-byte
   extent to `giftui_rfc014_counter_entry`. Swift entry0x2c73c passes those
   backing/extent guards before its8-byte push.
   `p08RunEmbeddedCorpus` calls graph, scoped and host corpora sequentially.
   Select only `p08EmbeddedHost`, at 0x1c3bc; no scoped-corpus frame is charged.
2. `CounterScopedStorage.swift:3838` executes `.host(0)` in the 0...8 loop.
   `P08CallerCustody.run` invokes `p08RunMetadataCase`. Its `.host` arm tail-
   branches at 0x1c1d4 to 0x4affc after restoring its own 64-byte frame. The
   dispatch frame is NOT charged. `p08RunMetadataHost` passes nil `before` and
   nil `transcript` to `p08RunOneMetadataHost`. No `.twoHosts` frame is charged.
3. `.host(0)` establishes failAfterRuntime=false, early=0, candidateFailure=nil,
   reuse=nil and baseline=nil. `p08RunPreparedStaticHost` -> original model
   lender -> root body -> semantic store lender -> semantic callback body ->
   owner.withStorage is the source's nested positive path. Direct BLs and actual
   callback literals/forwarders are the same frozen ones independently reviewed
   with the preceding cold resource packet; their complete bodies are included.
   Literal 0x1a884 plus ADD-PC at 0x1a7a0 yields Thumb callback0x517d5;
   literal0x1aab4 plus ADD-PC at0x1aa26 yields0x519b5;
   literal0x1abec plus ADD-PC at0x1aba6 yields0x51a6d.
4. `withStorage` at source1238 nests the original b0/b1/b2/b3/g0/g1/g2/g3/g4/
   c0/h0/r0/r1/h1 loans and invokes the one supplied body before `requireEmpty`
   and lifecycle=.idle. This bridge is a source-required callback chain, NOT
   an invented direct withStorage->session edge. ALL interposed bank callback,
   lender, forwarder and scoped consuming-body frames are charged ZERO in this
   proof; the discovery path through generic slot alternatives is not used to
   establish their feasibility or numeric cost. Its endpoint `p08RunStaticSessionPhase`
   remains an actual non-tail function entered by the supplied body.
5. The session constructs its host, lets the constructor return, then calls
   `p08RunStaticHostPhase` before cleanup. The constructor/factory frames have
   returned and are NOT charged on this live path. With nil reuse, early0 and
   no candidate fault, host phase selects `counterRunHostLifecycle`, not
   `p08RunReuseHost`. For `.host(0)`, idleQuiesceMode=0; normal activation and
   paced service succeed before the required `counterHostCorpus` call.
6. `CounterHostCorpus.swift:95` exercises actual input/action cycles, then
   `return checks + counterWakeControls(...)` at source137. Actual BL0x1d6c6
   retains its 7584-byte frame. `counterWakeControls` at0x1d710 has a9360-byte
   frame. This is nested invocation, not addition of two sequential alternatives.
   A successful admitted-work service (for example the coalesced semanticDirty/
   presentationPending/admittedWork service at source202, actual BL0x1dd06) calls the actual host
   opportunity, owner pipeline, semantic candidate bridge and record expansion.
7. The authored CounterScreen body (`Counter.swift:40`) contains background ->
   VStack/TupleView5 -> disabled Increment Button -> Text("Increment"). The
   success path traverses this finite declaration chain; disabled is a semantic
   value, not an omission of the Button's label. Four texts and22 scalars are
   independently required by `counterCheckHostFrame`; the label is not a
   hypothetical extra view or input. Complete linked direct-call bodies from
   0x38b2c through Text traversal0x6b7c identify those concrete generic types.
   At0x6be4, Text expansion BLs physical merged `enterDeclarationRole`0x3982e.
   Its representative symbol names CounterScreen, but this is code merging,
   not recursive CounterScreen expansion. Stop after its1072-byte entry reserve;
   the subsequent identity equality callee and all deeper work are omitted.
8. Every charged entry push/immediate reservation remains allocated at the
   named nested call. The complete bodies show the later matching epilogues;
   register SP alignment/temporary areas move below the fixed frame, not above
   it at those calls. The two semantic helpers at0x3a38a/0x3a45c restore their
   frames before tail forwarding, so both chargeZERO. The generic declaration
   traversal is finite over this authored view; no arbitrary recursive type
   or unbounded callback family is assumed in the selected path.

The47 charged fixed-entry terms sum56888. No per-function maximum, frame from
another phase, contract object, dynamic alignment area, bank-loan frame, FPU
exception area, ISR frame or enclosing startup frame is needed for that sum.
The broader provisional analyser remains discovery only: its65224 uniform-frame
subtotal mixed mutually exclusive plans and is NOT a bound or required peak.
The source-specific ordinary-host route above is the premise of the fixed subset.
