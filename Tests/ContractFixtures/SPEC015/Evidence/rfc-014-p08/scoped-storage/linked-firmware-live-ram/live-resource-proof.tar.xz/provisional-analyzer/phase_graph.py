import sys,json,collections,hashlib,pathlib
sys.dont_write_bytecode=True
import local_sp as S
p=S.out;N=json.loads((p/'names.json').read_text());F=S.F
# Explicit binary/source family mappings are recorded separately; none is a guessed per-call byte allowance.
manual={0x5a380:[0x5a094],0x430e4:[0x51002],0x42c52:[0x4f6da,0x4f6de,0x4f75c,0x4f73e],0x43040:[0x2264c,0x22670,0x4f6da,0x4f6de],0x43368:[0x2264c,0x22670],0x5956e:[0x519b4],0x5996c:[0x519b4],0x5c8ea:[0x5a584],0x27864:[205718],0x3096c:[0x2cb5c],0x5dcf4:[0x5e150,0x5e15c],0x5e57c:[0x5e150,0x5e15c],0x5dcc0:[0x2dc58]}

# nRF52 delay thunk is intentionally emitted in .rodata, so SHF_EXECINSTR inventory needs this explicit code-as-data root.
assert S.readword(0x61950)==0xd8fd3803
F[0x61950]=dict(address=0x61950,size=6,aliases=[dict(name='nrfx delay_machine_code')],instructions=[(0x61950,'subs r0, #3'),(0x61952,'bhi.n 61950 <delay_machine_code>'),(0x61954,'bx lr')],direct=[],indirect=[],sp_writes=[])
N[str(0x61950)]='nrfx delay_machine_code'

sensitive={a for a,f in F.items() if f['indirect']}
while True:
 more={a for a,f in F.items() if any(e['target'] in sensitive for e in f['direct'])}
 if more<=sensitive:break
 sensitive|=more
print('input-sensitive functions',len(sensitive),flush=True)
contexts={};todo=collections.deque();byfunc=collections.Counter()
def canonical(a):
 seen=set()
 while a in F and a not in seen:
  seen.add(a);ins=F[a]['instructions']
  if len(ins)!=1 or not ins[0][1].startswith(('b.w','b.n','b\t')):break
  import re
  q=re.match(r'b(?:\.[nw])?\s+([0-9a-f]+)',ins[0][1])
  if not q:break
  a=int(q[1],16)
 return a
def seed(c):
 R={};M={}
 for k,v in c.get('args',{}).items():
  if k not in ('r0','r1','r2','r3','r8','r10') or not v or v[0]!='c':continue
  xs=S.cset(v)
  if xs and all((x&~1) in F or x==0 for x in xs):R[k]=S.setval((canonical(x&~1)|1) if x else 0 for x in xs)
 R['r13']=('s',0,0)
 return R,M
def add(a,init,parent=None,phase=None):
 a=canonical(a)
 if a not in F:return None
 if a not in sensitive:init=({'r13':('s',0,0)}, {})
 R,M=init
 keydata=(a,sorted(R.items()),sorted(M.items()),phase);key=hashlib.sha256(repr(keydata).encode()).hexdigest()[:20]
 if key not in contexts:
  contexts[key]=dict(address=a,phase=phase,initial=init,parents=[parent] if parent else [],edges=[],unresolved=[]);todo.append(key);byfunc[a]+=1
 else:
  if parent:contexts[key]['parents'].append(parent)
 return key
root=add(S.D['roots']['main'],({'r13':('s',0,0)},{}));steps=0
while todo:
 key=todo.popleft();ct=contexts[key];a=ct['address'];r=S.solve(F[a],ct['initial']);r.pop('exits');ct['analysis']=r
 for site,c in r['calls'].items():
  t=c['target']
  ts=[(x&0xfffffffe) for x in S.cset(t)] if c['indirect'] and t and t[0]=='c' and S.cset(t) else [t] if not c['indirect'] else []
  targets=[x for x in ts if x in F]
  if not targets and c['indirect']:targets=manual.get(a,[])
  if c['indirect'] and not targets and a==0x4312c and str(site).split(':')[-1] in ('274756','274774'):targets=[0x2264c,0x22670]
  if c['indirect'] and not targets and a in (0x457a2,0x15c7c):targets=[ct['phase']] if ct['phase'] else [0x51a6c,0x4b3ba]
  if c['indirect'] and not targets:ct['unresolved'].append((site,c))
  for target in targets:
   ph=ct['phase']
   if target==0x10cb8:
    v=c.get('args',{}).get('r1');xs=S.cset(v) if v and v[0]=='c' else None
    if xs and len(xs)==1:ph=xs[0]&~1
   k=add(target,seed(c),[key,str(site)],ph);ct['edges'].append(dict(site=str(site),target=k,address=target,sp=c['sp']))
 steps+=1
 if steps%500==0:print('progress',steps,'contexts',len(contexts),'queue',len(todo),flush=True)
 if len(contexts)>25000:print('context cap');break
unknown=collections.defaultdict(list)
for k,v in contexts.items():
 for site,c in v['unresolved']:unknown[v['address']].append((k,str(site),c))
print('contexts',len(contexts),'solved',steps,'functions',len(byfunc),'unresolved',sum(map(len,unknown.values())),len(unknown))
for a,sites in unknown.items():print(hex(a),len(sites),N[str(a)][:160],','.join(s for _,s,_ in sites[:4]))
# JSON map represents memory keys as list-of-pairs to remain portable.
for c in contexts.values():
 R,M=c['initial'];c['initial']=[R,list(M.items())]
(p/'phase-graph.json').write_text(json.dumps(dict(root=root,contexts=contexts,manual_targets=manual,remaining_queue=list(todo)),indent=2)+'\n')
