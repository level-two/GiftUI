# Current Pi collection/image receipt packet

Run `python3 verify.py` after extraction on the pinned repository host. It checks
all packet members, the preserved full 934-file local snapshot (including binary
hashes), all 228 current/snapshot input hashes and all 409 log classifiers/twins.
The full local snapshot is required; binaries are intentionally not committed.
The archive preserves textual receipts, generated probe source, logs, map,
readelf reports, command/source/tool/configuration identities and external-diff
provenance. It never builds or executes the target. Changed current inputs fail
freshness validation rather than silently inheriting the result. Collection/link
PASS is not complete stack, allocator, physical-fit, deployment or P08 acceptance.
