import GiftUI
import GiftUIDrawing
import GiftUIExecution
import GiftUIRuntimeCore

/// Binds generated Static storage and callable tables to Runtime Core's one
/// shared lifecycle while leaving each focused algorithm with its owner.
package struct StaticRuntimeProfileBinding<Regions, Metadata>: ~Copyable
where
    Regions: StaticProfileStorageRegions & ~Copyable,
    Metadata: RuntimeStaticCanvasAuditMetadata & StaticCanvasCallableTable
{
    private var storage: StaticProfileStorage<Regions, Metadata>
    private var lifecycle: RuntimeCoordinatorLifecycle

    package init?(
        structuralIdentity: StaticStructuralIdentity,
        limits: RuntimeProfileLimits,
        regions: consuming Regions,
        metadata: consuming Metadata
    ) {
        guard
            let storage = StaticProfileStorage(
                structuralIdentity: structuralIdentity,
                limits: limits,
                regions: consume regions,
                metadata: consume metadata
            )
        else {
            return nil
        }
        var lifecycle = RuntimeCoordinatorLifecycle()
        guard lifecycle.validate(storage.audit()) == nil,
            lifecycle.enterIdle() == nil
        else {
            return nil
        }
        self.storage = consume storage
        self.lifecycle = lifecycle
    }

    package var profile: RuntimeProfileKind { .static }

    package var storageAudit: RuntimeStorageAudit? {
        lifecycle.storageAudit
    }

    package var executionContext: ExecutionContext {
        lifecycle.executionContext
    }

    package var isQuiescent: Bool {
        lifecycle.isQuiescent
    }

    package var storageLifetimeState: StaticStorageLifetimeState {
        storage.storageLifetimeState
    }

    package mutating func beginOpportunity(
        context: ExecutionContext
    ) -> ExecutionError? {
        guard let error = lifecycle.beginOpportunity(context: context) else {
            guard storage.beginAttempt() else { return .invariantViolation }
            return nil
        }
        return error
    }

    package mutating func recordActiveContext(
        _ context: ExecutionContext
    ) -> ExecutionError? {
        lifecycle.recordActiveContext(context)
    }

    package mutating func reserve(
        _ count: UInt16,
        for limit: RuntimeStorageLimit
    ) -> StaticStorageReservation {
        storage.reserve(count, for: limit)
    }

    /// Lends one generated region only while its retained or attempt-local
    /// lifetime is active. The buffer cannot escape the synchronous body.
    package mutating func withRegion<Result>(
        _ family: RuntimeStorageFamily,
        _ body: (UnsafeMutableRawBufferPointer) throws -> Result
    ) rethrows -> Result? {
        try storage.withRegion(family, body)
    }

    package mutating func withSemanticRegions<Result>(
        _ body: (
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer
        ) throws -> Result
    ) rethrows -> Result? {
        try storage.withSemanticRegions(body)
    }

    package mutating func withLayoutRegions<Result>(
        _ body: (
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer
        ) throws -> Result
    ) rethrows -> Result? {
        try storage.withLayoutRegions(body)
    }

    package mutating func withSemanticCandidateAndLayoutRegions<Result>(
        _ body: (
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer
        ) throws -> Result
    ) rethrows -> Result? {
        try storage.withSemanticCandidateAndLayoutRegions(body)
    }

    package mutating func withPresentationRegions<Result>(
        _ body: (
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer,
            UnsafeMutableRawBufferPointer
        ) throws -> Result
    ) rethrows -> Result? {
        try storage.withPresentationRegions(body)
    }

    package mutating func stageCanvas<Identity>(
        identity: consuming Identity,
        callableID: UInt16,
        declaredCaptureByteCount: UInt16,
        capture: consuming Metadata.CaptureStorage
    ) -> StaticCanvasOccurrence<Identity, Metadata.CaptureStorage>?
    where Identity: Equatable & Sendable {
        storage.stageCanvas(
            identity: consume identity,
            callableID: callableID,
            declaredCaptureByteCount: declaredCaptureByteCount,
            capture: consume capture
        )
    }

    package mutating func invokeCanvas<Identity>(
        occurrence: inout StaticCanvasOccurrence<Identity, Metadata.CaptureStorage>,
        context: inout GraphicsContext,
        size: Size,
        read: borrowing _GiftUIFrameRead<Metadata.Domain>
    ) throws(DrawingError)
    where Identity: Equatable & Sendable {
        try storage.invokeCanvas(
            occurrence: &occurrence,
            context: &context,
            size: size,
            read: read
        )
    }

    package mutating func finishOpportunity(
        context: ExecutionContext
    ) -> ExecutionError? {
        storage.finishAttempt()
        guard let error = lifecycle.finishOpportunity(context: context) else {
            finishTeardownIfQuiescent()
            return nil
        }
        return error
    }

    package mutating func runActivePipeline<Owner>(
        owner: inout Owner
    ) -> RuntimeCompletePipelineResult<Owner.OwnerFailure>
    where Owner: RuntimeCompletePipelineOwner & ~Copyable & ~Escapable {
        guard storage.storageLifetimeState == .attemptActive else {
            return RuntimeCompletePipeline.rejectInactive(owner: &owner)
        }
        return RuntimeCompletePipeline.run(owner: &owner)
    }

    package mutating func quiesce() {
        lifecycle.requestQuiescence()
        storage.quiesce()
        finishTeardownIfQuiescent()
    }

    private mutating func finishTeardownIfQuiescent() {
        guard lifecycle.isQuiescent,
            storage.storageLifetimeState == .tornDown
        else {
            return
        }
        _ = lifecycle.completeTeardown()
    }
}
