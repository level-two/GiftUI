import json,sys,collections
sys.setrecursionlimit(10000)
p=str(__import__('pathlib').Path(__file__).resolve().parent)+'/'
G=json.load(open(p+'phase-graph.json'));C=G['contexts'];N=json.load(open(p+'names.json'))
A={v['address']:set() for v in C.values()}
for c in C.values():
 A[c['address']].update(C[e['target']]['address'] for e in c['edges'] if e['target'])
idx={};low={};stack=[];active=set();scc=[]
def visit(a):
 idx[a]=low[a]=len(idx);stack.append(a);active.add(a)
 for b in A[a]:
  if b not in idx:visit(b);low[a]=min(low[a],low[b])
  elif b in active:low[a]=min(low[a],idx[b])
 if low[a]==idx[a]:
  part=[]
  while True:
   b=stack.pop();active.remove(b);part.append(b)
   if b==a:break
  if len(part)>1 or a in A[a]:scc.append(part)
for a in A:
 if a not in idx:visit(a)
for part in scc:
 print('\nSCC',len(part))
 for a in sorted(part):print(hex(a),N[str(a)][:110], '->',','.join(hex(b) for b in A[a] if b in part))
json.dump(scc,open(p+'scc.json','w'))
