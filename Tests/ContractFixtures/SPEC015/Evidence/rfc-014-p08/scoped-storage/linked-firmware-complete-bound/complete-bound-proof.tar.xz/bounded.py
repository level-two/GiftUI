import json,sys,functools
sys.setrecursionlimit(10000)
p=str(__import__('pathlib').Path(__file__).resolve().parent)+'/';G=json.load(open(p+'phase-graph.json'));C=G['contexts'];scc=json.load(open(p+'scc.json'));ix={a:i for i,ss in enumerate(scc) for a in ss}
# Source non-descent helper edges. All remaining SCC edges must descend child/modifier ranks.
same={0x9ce4:{0xa904,0xb448,0x3d5ac},0x9e58:{0xa904,0xb448,0x3d5ac},0xa904:{0xbed4,0xc468,0xc9b4},0xb448:{0xbed4,0xc468,0xc9b4},0x3d5ac:{0xbed4},0xcf48:{0xa904,0xb448,0x9e58},0x84e0:{0x9640,0x8b48,0x3cb56},0x8858:{0x84e0},0x90fc:{0x9640,0x8b48,0x8858,0x3cb56},0x7ed0:{0x3da66}}
# placement90fc->9640 same identity;9640->3cb56 is child (source dispatch may same? verify).
loan={0xef20,0x4308e,0x430e4,0x4312c}
@functools.lru_cache(None)
def bound(k,b=28,l=14,o=2,startup=False):
 c=C[k];a=c['address'];
 if a==0x2cba4:
  if o==0:return 0,[]
  o-=1
 f=c['analysis']['local_upper'];
 if startup and a==0x2d430:return f,[]
 best=f;bp=[]
 if a in loan:
  if l==0:return 0,[]
  l-=1
 for e in c['edges']:
  t=e['target'];ta=C[t]['address'];bb=b
  if a in ix and ix.get(ta)==ix[a] and a not in loan and 0x2cba4 not in scc[ix[a]] and ix[a] not in [i for i,ss in enumerate(scc) if any(x in loan for x in ss)] and ta not in same.get(a,set()):
   if bb==0:continue
   bb-=1
  v,pp=bound(t,bb,l,o,startup);sp=e['sp'];cost=-sp[1] if sp and sp[0]=='s' else f;v+=cost
  if v>best:best=v;bp=[e]+pp
 return best,bp
v,pp=bound(G['root']);print('BOUND WITH RANK PREMISES',v,'states',bound.cache_info())
print([(hex(C[e['target']]['address']),e['site']) for e in pp[-35:]])
json.dump(dict(bound=v,path=pp,same={hex(a):[hex(b) for b in bs] for a,bs in same.items()}),open(p+'bounded.json','w'),indent=2)

for name,k in G.get('extra_roots',{}).items():print('EXTRA',name,bound(k)[0])

print('PRE SWITCH STARTUP',bound(G['extra_roots']['0x2d3a8'],startup=True)[0])
