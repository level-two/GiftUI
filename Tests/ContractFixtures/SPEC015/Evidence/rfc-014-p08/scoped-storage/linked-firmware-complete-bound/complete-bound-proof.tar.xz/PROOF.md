# Frozen e649c5d complete-bound proposal

This is a source-constrained conservative static account, submitted for independent
review. It is not a measured high-water, minimum, hardware result, firmware fit
receipt, authority amendment, or permission for source optimization. Reproduce
with `python3 reproduce.py` in this extracted directory on the pinned repository
host. It checks the ELF hash before regenerating disassembly/inventory, context
closure, SCCs and bounds. Scripts read the frozen ELF and write analysis files
only. `names.json` is the pinned Swift-demangled symbol inventory. Inputs are
also available in the earlier linked-firmware-current packet. All addresses below
are Thumb code addresses with bit 0 cleared.

## Method and closure

`inventory.py` inventories every sized executable function and uncovered $t code
range, parses pinned GNU objdump, and retains aliases. `local_sp.py` follows both
CFG arms, read-only table branches, push/pop/outgoing arguments, SP-relative
saved SPs and at most 15 bytes of dynamic alignment. Outlined machine helpers
are interpreted in their caller's SP context. A call is charged its live SP
interval lower endpoint plus the callee bound, or the function's own local
maximum, whichever is greater. Tail calls use the actual restored SP. It does
not assume the maximum prologue remains live after a restore. Ordinary callee
register effects are conservative; mutable data loads are unknown. Compiler
private saved-SP slots remain private (source has no unsafe access to compiler
spill slots). The only manual local epilogue is UART's saved-MSP restore; its
exact instructions are asserted, with maximum 7 alignment + 8 save = 15.

`phase_graph.py` propagates only finite function-code constants in ABI argument
registers. Lost constants use source-specific finite target supersets in
`manual-targets.tsv`; assigning every listed target at every unknown site in the
same physical caller intentionally over-approximates mutually exclusive cases.
The generated full call graph includes cold initialization, ordinary/current and
stale action dispatch, typed refusals, injected initialization/activation/candidate
failure, reuse and cleanup. Required bodies remain inside all fourteen original
loans. No required capacity, host payload, corpus check or observation is removed.
All source-dependent exclusions are below; a missing edge is never charged zero
without one of these premises. All immediate targets must be inventoried, every
indirect must resolve or have an exclusion, and all reachable local SPs must close.
The Nordic six-byte delay thunk at 0x61950 is code deliberately stored in rodata;
its bytes are checked and its stack cost is zero.

The uniform main result deliberately combines alternatives that cannot all occur
on one real path. This is safe for an upper bound, unlike the earlier lower-bound
rejection. It covers the frozen finite corpus, not arbitrary external callbacks
or arbitrary corrupt semantic graphs. No dynamic interrupt registration, user
thread, heap, or external producer exists in this linked counter realization.

## Recursion premises (all necessary for this bound)

1. CounterScopedStorage.withStorage has exactly fourteen nested original lenders
   (b0-b3, g0-g4, c0,h0,r0,r1,h1). Its Int-result callback family is finite and
   nonescaping. The only apparent loan cycles are merged generic implementations;
   count at most fourteen live entries into ef20/4308e/430e4/4312c. Source .twoHosts
   executes the two hosts sequentially; no nested second withStorage under the
   active consuming body exists. Other result specializations do not enter this
   Int-result SCC. CounterScopedStorage.swift:1238-1320 and 3775-3790 establish this.
2. All layout/render trees used here are generated from CounterScreen; the only
   expansion sites are CounterPipelineOwner and CounterSemanticProbe. Success,
   current/stale service and typed failure do not fabricate child links. A child
   descent consumes a semantic identity path component; the configured maximum
   is 24 (CounterProfileStorage.swift). Four modifier applications exist in the
   entire authored screen: background, two disabled buttons, canvas frame. The
   model changes payloads, never this structure. Thus an active descent path has
   at most 24 child transitions plus at most four modifier-index decrements.
3. Every cyclic layout/validation/render SCC edge in `bounded.py` spends this
   shared budget of 28, except the explicit `same` helper edges. The latter are
   same-identity dispatch/collection helpers and form an acyclic subgraph. Examples:
   measureContent->measureStack; measureStack->measureFlattenedChildren; flattened
   occurrence->measureModifier; modifier->content dispatch; content->placement
   helper; validateOccurrence->validateChildren. Every remaining cyclic edge
   descends child identity or reduces modifier index. Inlining can omit a spend,
   which only increases this bound. `scc.json`, the edge catalog in bounded.json
   and the complete linked disassembly make the physical edge classification
   auditable. Source: LayoutEngine measurement 69-820, placement 880-1600;
   LayoutSemanticValidation; SemanticRecordRenderView.firstScope and record render
   preflight/traversal. Sibling loops return before the next sibling, so width
   affects execution count, not simultaneous recursive stack.
4. Zephyr onoff.c documents and enforces at most two active process_event calls:
   the nested call records a deferred event and returns while PROCESSING is set.
   Its finite clock transition callbacks may otherwise create a graph SCC; the
   bound separately caps entry at two. This is not a semantic-depth spend.

## Callback/exclusion audit

`manual-targets.tsv` is the complete address/name set used by the analyzer.
Original loan final bodies retain their known withStorage body phase. Mutations
use the two linked ObservableModelScope wrappers or CounterHandler.operation.
The Stateful CounterScreen body has only beforeBody 0x3aef4 (literal R3 at 0x6dcc).
Static drawing has exactly begin/end/move/addLine/stroke from the one static
operations table. Merged semantic adapters conservatively include all three
literal source bodies (0x56382/563be/5641a), including the largest 10,688-byte body.
Raster visit includes fill, glyph and stroke rasterize/consume closures; all
pixel callbacks target 0x5c9b4. The only physical pixel-write C callback supplied
at counter_main.c:19 is spi_tft_write_rgb565. Layout each callbacks include every
linked partial apply of its finite three measurement closures. SHA callbacks
use its one update implementation. RasterFillCoverage's eight indirect calls
are the two immutable ABI witness slots at 0x6249c/0x62498 -> 0x404/0x31a7e.
The glyph codec PC-relative function value is 0x40d6d -> 0x40d6c.

The nine init entries at 0x5ef50..0x5ef98 contain three direct system init functions
and six device records; each device init is the immutable word at device+20.
GPIO APIs use the concrete two nrfx GPIO devices. SPI config irq callbacks are
0x5e272/0x5e50a, and their other unknown callback is GPIO pin configure 0x2dc58.
Clock driver start/stop table 0x61c80 gives exactly generic_hfclk/lfclk start/stop.
Both SPI and SPIM device/IRQ paths are retained, even though this application
uses SPI1. Generated ISR table has UART2 direct, clock0, SPI4, GPIOTE6, RTC17,
SPIM47, and spurious for the remaining entries. nrfx_isr uniformly dispatches
all four table arguments; the wrapper uniformly includes this thunk and spurious.
Clock registration is clock_event_handler; SPI/SPIM registration is its matching
single event_handler; GPIOTE global callback is nrfx_gpio_handler. RTC compare
callbacks have only sys_clock_timeout_handler in linked registrations.

Three callback sites are source-infeasible, not unknown zero-cost callbacks:
- nrfx_gpio_handler user callback list: counter transport configures output GPIO
  only, never gpio_add_callback; device callback lists start empty. The linked
  API-table manage_callback function is not itself a registration.
- sys_clock_announce timeout callback: no z_add_timeout or equivalent timeout
  producer is linked. The static timeout list remains empty; RTC's own compare
  handler above is retained and is not this kernel timeout-list callback.
- onoff notify_one: the only linked onoff_request client is
  z_nrf_clock_control_lf_on, initialized with sys_notify_init_spinwait. Its
  sys_notify_finalize cannot return a callback. No onoff monitor registration is
  linked; process_event's monitor callback site 0x2cc30 is excluded for that reason.
These premises are specific to this ELF/configuration and must be revisited if
any producer/driver configuration changes. The JSON retains every excluded site.

## Allocation and fatal paths

Both configured arenas are zero; no malloc/calloc/realloc/aligned_alloc or k_*
allocation entry is in this ELF. This symbol/config fact alone is insufficient.
Rooted Swift allocation paths are retained through swift_allocError and
swift_allocObject. posix_memalign at 0x5ddb2 unconditionally returns ENOMEM=12,
without writing the output pointer; swift_allocObject 0x31a3e initializes that
pointer nil, calls it, then traps at 0x31a70. Therefore no allocation succeeds,
no heap bytes exist, and continuations after that call are unreachable. This is
NOT a claim that an allocation failure would implement an expected typed result.
Required typed failure paths must continue to be confirmed by the corpus; fatal
invariant/boxed-error paths halt rather than fabricate success.

The sole direct caller of swift_releaseTm 0x31a80 is swift_allocError 0x414.
Its r0 is loaded from hidden compiler errorBoxDestroyImplRef's context word
0x2000000c, initially zero in .data (the pair begins at 0x20000008). The once-init
block clears that word before release, installs only code at the first word,
and marks its once byte; subsequent entries skip the block. No source publishes
this hidden cache address or installs a context. The release therefore exits at
its null test before its destructor indirect call. The later metadata destructor
call at 0x496 is dominated by nonreturning allocation and is unreachable. This
nil-cache/write premise is explicit; treating a mutable cache as immutable would
be wrong. The graph contains neither unbounded successful-allocation recursion
nor an assumed free-space allowance. Fatal exception entry/handlers are counted
below, not silently treated as returning normal typed failures.

## Stacks, exceptions and physical reconciliation

The complete main-root bound is 95,349. bg_thread_main retains 8 bytes around
main, so normal main PSP maximum is 95,357. Add 112 for first exception's basic
8 words, FP lazy area 18 words and conservatively 8 alignment bytes: **95,469**.
FPU single-thread mode explicitly enables ASPEN|LSPEN in prep_c.c, so lazy FP
space is reserved even when no ISR executes FP. This allowance is included once
on main PSP; all later handler execution uses MSP.

Reset initially uses main storage on MSP for SystemInit, then switches PSP to
interrupt-stack top for z_prep_c/z_cstart. z_cstart installs interrupt MSP; before
switch-to-main interrupts remain masked by BASEPRI=32. The pre-switch startup
bound is **312**. z_arm_switch_to_main resets PSP to main top; old startup frames
do not remain above bg_thread_main. The analysis deliberately adds startup to the
ISR bound too, covering temporary use of interrupt storage. Early fatal/NMI paths
are terminal; there is no claim that a fatal startup exception resumes init.

Uniform maskable IRQ software maximum is 444 (includes spurious path). The common
fault vector wrapper reserves 8 and z_arm_fault's maximum is 516: **524**. SVC
and NMI paths are smaller. Use 524 for *every* possible handler, including
configurable faults, rather than assuming all such handlers use the IRQ maximum.
The nRF52840 __NVIC_PRIO_BITS is 3: no more than eight simultaneously active
configurable priority levels. Add two fixed-priority levels (HardFault and NMI).
No software recursion invokes an exception handler. Another fault while already
in the highest applicable fault state locks up/halt; it cannot create unlimited
successful exception entry. Conservatively count **ten** full software+FP/basic
frames on MSP, even though the first hardware frame actually lives on PSP:

    ISR bound = 312 + (8 + 2) * (524 + 112) = 6,672

This overcounts actual driver priority nesting and first exception placement.
`CONFIG_ZERO_LATENCY_IRQS`/dynamic interrupts/multithreading are disabled. This is
hardware-free static evidence, not interrupt high-water measurement.

Propose counter-only MAIN_STACK_SIZE=106496 (104 KiB), ISR_STACK_SIZE=8192 (8 KiB).
Margins are 11,027 and 1,520 bytes respectively. Existing ELF RAM charge170620
includes main27648 + ISR2048 payloads and both64-byte guards. Other retained
charge after removing both replaceable payloads is140924. All four34720 donors,
metadata within donor, actual C globals/data/bss/noinit and guards stay charged:

    projected charge = 140924 + 106496 + 8192 = 255612
    physical SRAM = 262144; charge margin = 6532
    projected address extent = 255616; extent margin = 6528

The four-byte PT_LOAD gap accounts for charge-versus-extent difference. These are
projections, not a new linked fit receipt: the normal guarded final build must
verify actual sections, guard/alignment, ABI, flash, input freshness, complete
collection and rooted heap analysis. Keep normal analyzer's 192KiB budget and
baseline stacks unchanged; use counter-specific extra Kconfig and its explicit
262144-byte total-RAM check only after authority reconciliation and review.
