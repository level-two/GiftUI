"""Read-only analysis of the one frozen ELF; does not build or execute firmware."""
import hashlib, pathlib, subprocess, sys
p=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/Users/eugene/work/GiftUI')
elf=root/'.build/nrf52840/signal-analyzer-static/rfc014-counter-firmware/zephyr/zephyr.elf'
assert hashlib.sha256(elf.read_bytes()).hexdigest()=='e649c5d26a676140b473e8fa1de5b075a479d8282a7f6d69e0034fb215884c38', 'Different ELF: address-specific premises need a new audit'
objdump=root/'.toolchains/nrf52840/zephyr-sdk-0.17.4/arm-zephyr-eabi/bin/arm-zephyr-eabi-objdump'
with (p/'all-linked-disassembly.txt').open('w') as f:subprocess.run([str(objdump),'-d',str(elf)],stdout=f,check=True)
for script in ['inventory.py','phase_graph.py','cycles.py','bounded.py']:
 subprocess.run([sys.executable,str(p/script)],check=True)

import json
g=json.loads((p/'phase-graph.json').read_text()); contexts=g['contexts']; funcs=set(map(int,json.loads((p/'graph.json').read_text())['functions']))|{0x61950}
assert not g['remaining_queue']
assert all(not c['unresolved'] and c['analysis']['complete'] for c in contexts.values())
assert all(e['target'] for c in contexts.values() for e in c['edges'])
assert all(q['target'] in funcs for c in contexts.values() for q in c['analysis']['calls'].values() if not q['indirect'])
assert json.loads((p/'bounded.json').read_text())['bound']==95349
print('PASS: frozen graph closure and conservative rank calculation; source premises require independent review')
