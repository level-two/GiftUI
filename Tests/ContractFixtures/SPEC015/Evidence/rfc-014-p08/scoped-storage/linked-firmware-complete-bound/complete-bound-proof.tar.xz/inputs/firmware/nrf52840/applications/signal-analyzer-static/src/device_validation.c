#include "device_validation.h"

#include "ads7846.h"
#include "giftui_fault.h"
#include "spi_tft.h"
#include "static_input_bridge.h"
#include "static_host_clock.h"
#include "static_host_scheduler.h"
#include "static_host_storage.h"

#include <stdbool.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

#define GIFTUI_TOUCH_POLL_COUNT 1000U
#define GIFTUI_TOUCH_POLL_MILLISECONDS 10U

#if defined(CONFIG_WATCHDOG) && CONFIG_WATCHDOG
#error "An active watchdog requires a service hook in the Static host scheduler"
#endif

K_THREAD_STACK_DECLARE(z_main_stack, CONFIG_MAIN_STACK_SIZE);

extern uint32_t giftui_signal_analyzer_present_initial(
    void *profile, uint32_t profile_bytes,
    void *capture, uint32_t capture_bytes,
    void *raster, uint32_t raster_bytes,
    void *coverage, uint32_t coverage_bytes,
    int (*write)(uint16_t, uint16_t, uint16_t, uint16_t,
                 const uint8_t *, size_t));
extern void giftui_signal_analyzer_retire_initial(void);
extern uint32_t giftui_signal_analyzer_drain_initial_input(
    void *profile, uint32_t profile_bytes,
    void *capture, uint32_t capture_bytes);
extern uint32_t giftui_signal_analyzer_poll_scheduled_due(
    void *profile, uint32_t profile_bytes,
    void *capture, uint32_t capture_bytes);
extern uint32_t giftui_signal_analyzer_present_next(
    void *profile, uint32_t profile_bytes,
    void *capture, uint32_t capture_bytes,
    void *raster, uint32_t raster_bytes,
    void *coverage, uint32_t coverage_bytes,
    int (*write)(uint16_t, uint16_t, uint16_t, uint16_t,
                 const uint8_t *, size_t));

/* Read-only C getters remain available to connected stack measurements.
 * Debugger-driven pointer input still enters the production admission API. */
extern uint32_t giftui_signal_analyzer_action_point(uint16_t code);
extern uint32_t giftui_signal_analyzer_capture_count(void);
extern uint32_t giftui_signal_analyzer_acquisition_state(void);
extern uint32_t giftui_signal_analyzer_last_drawing_points(void);

__attribute__((used, retain))
static uint32_t (*const giftui_committed_action_point_entry)(uint16_t) =
    giftui_signal_analyzer_action_point;
__attribute__((used, retain))
static uint32_t (*const giftui_capture_count_entry)(void) =
    giftui_signal_analyzer_capture_count;
__attribute__((used, retain))
static uint32_t (*const giftui_acquisition_state_entry)(void) =
    giftui_signal_analyzer_acquisition_state;
__attribute__((used, retain))
static uint32_t (*const giftui_drawing_points_entry)(void) =
    giftui_signal_analyzer_last_drawing_points;

/* Keep the future committed-interaction handoff linkable without granting
 * input eligibility in this finite diagnostic path. */
__attribute__((used, retain))
static int32_t (*const giftui_committed_presentation_entry)(uint32_t) =
    giftui_signal_analyzer_input_install_presentation;

__attribute__((used, retain))
static uint32_t (*const giftui_normalized_input_drain_entry)(
    void *, uint32_t, void *, uint32_t) =
    giftui_signal_analyzer_drain_initial_input;

__attribute__((used, retain))
static uint32_t (*const giftui_scheduled_fact_entry)(
    void *, uint32_t, void *, uint32_t) =
    giftui_signal_analyzer_poll_scheduled_due;

__attribute__((used, retain))
static uint32_t (*const giftui_replacement_canvas_entry)(
    void *, uint32_t, void *, uint32_t,
    void *, uint32_t, void *, uint32_t,
    int (*)(uint16_t, uint16_t, uint16_t, uint16_t,
            const uint8_t *, size_t)) =
    giftui_signal_analyzer_present_next;

static void wait_microseconds(uint32_t duration)
{
    k_busy_wait(duration);
}

static const struct giftui_static_host_scheduler_hal wait_hal = {
    .now_microseconds = giftui_static_host_clock_now,
    .wait_microseconds = wait_microseconds,
    .service_watchdog = NULL,
};

static void increment_saturating(uint32_t *value)
{
    if (*value < UINT32_MAX) {
        (*value)++;
    }
}

static void report_stack_high_water(void)
{
    const size_t capacity = K_THREAD_STACK_SIZEOF(z_main_stack);
    const uint8_t *const stack =
        (const uint8_t *)K_THREAD_STACK_BUFFER(z_main_stack);
    size_t unused = 0U;
    while (unused < capacity && stack[unused] == 0xaaU) {
        ++unused;
    }
    printk("GiftUI main stack: used=%u unused=%u capacity=%u\n",
           (unsigned int)(capacity - unused),
           (unsigned int)unused,
           (unsigned int)capacity);
}

int giftui_device_validation_run(void)
{
    bool touch_initialized = false;
    bool display_initialized = false;
    printk("GiftUI target: nrf52840dk/nrf52840 + KMRTM24024-SPI geometry\n");
    printk("GiftUI transfer: 320x4 RGB565, segment<=%u bytes\n",
           (unsigned int)spi_tft_spi_segment_bytes());

    int result = giftui_signal_analyzer_input_initialize(1U);
    if (result != 0 || giftui_signal_analyzer_input_pending_count() != 0U) {
        if (result == 0) {
            result = -EINVAL;
        }
        giftui_fault_record(GIFTUI_FAULT_CAPACITY, result);
        goto cleanup;
    }

    result = ads7846_initialize();
    if (result != 0) {
        giftui_fault_record(GIFTUI_FAULT_TOUCH_CONTROLLER, result);
        goto cleanup;
    }
    touch_initialized = true;
    result = spi_tft_initialize();
    if (result != 0) {
        giftui_fault_record(GIFTUI_FAULT_DISPLAY_CONTROLLER, result);
        goto cleanup;
    }
    display_initialized = true;

    uint64_t display_started = 0U;
    result = giftui_static_host_clock_now(&display_started);
    if (result != 0) {
        goto cleanup;
    }
    struct giftui_static_host_storage regions;
    result = giftui_signal_analyzer_storage_regions(&regions);
    if (result == 0 && giftui_signal_analyzer_present_initial(
            regions.profile, (uint32_t)regions.profile_bytes,
            regions.capture, (uint32_t)regions.capture_bytes,
            regions.raster, (uint32_t)regions.raster_bytes,
            regions.coverage, (uint32_t)regions.coverage_bytes,
            spi_tft_write_rgb565) != 1U) {
        result = -EIO;
    }
    if (result != 0) {
        giftui_fault_record(GIFTUI_FAULT_DISPLAY_CONTROLLER, result);
        goto cleanup;
    }
    uint64_t display_finished = 0U;
    result = giftui_static_host_clock_now(&display_finished);
    if (result != 0) {
        goto cleanup;
    }
    if (display_finished < display_started ||
        (display_finished - display_started) / 1000U > UINT32_MAX) {
        result = -ERANGE;
        goto cleanup;
    }
    printk("GiftUI display transfer: status=completed elapsed-ms=%u\n",
           (unsigned int)((display_finished - display_started) / 1000U));

    uint32_t contacts = 0U;
    uint32_t samples = 0U;
    for (uint32_t poll = 0U; poll < GIFTUI_TOUCH_POLL_COUNT; ++poll) {
        const int pen_state = ads7846_pen_is_down();
        if (pen_state < 0) {
            result = pen_state;
            goto cleanup;
        }
        if (pen_state != 0) {
            struct ads7846_raw_sample sample;
            increment_saturating(&contacts);
            result = ads7846_read_raw(&sample);
            if (result != 0) {
                goto cleanup;
            }
            increment_saturating(&samples);
        }
        uint64_t now = 0U;
        result = giftui_static_host_clock_now(&now);
        if (result != 0 ||
            now > UINT64_MAX - GIFTUI_TOUCH_POLL_MILLISECONDS * 1000U) {
            result = result != 0 ? result : -ERANGE;
            goto cleanup;
        }
        result = giftui_static_host_wait_until(
            now + GIFTUI_TOUCH_POLL_MILLISECONDS * 1000U, &wait_hal);
        if (result != 0) {
            goto cleanup;
        }
    }

    printk("GiftUI touch poll: status=completed contacts=%u samples=%u\n",
           contacts, samples);
    printk("GiftUI faults: capacity=%u display-controller=%u display-spi=%u "
           "touch-controller=%u touch-spi=%u\n",
           giftui_fault_count(GIFTUI_FAULT_CAPACITY),
           giftui_fault_count(GIFTUI_FAULT_DISPLAY_CONTROLLER),
           giftui_fault_count(GIFTUI_FAULT_DISPLAY_SPI),
           giftui_fault_count(GIFTUI_FAULT_TOUCH_CONTROLLER),
           giftui_fault_count(GIFTUI_FAULT_TOUCH_SPI));
    report_stack_high_water();

cleanup:
    giftui_signal_analyzer_input_quiesce();
    giftui_signal_analyzer_retire_initial();
    if (display_initialized) {
        const int shutdown_result = spi_tft_shutdown();
        if (shutdown_result != 0) {
            giftui_fault_record(
                GIFTUI_FAULT_DISPLAY_CONTROLLER,
                shutdown_result);
        }
        if (result == 0 && shutdown_result != 0) {
            result = shutdown_result;
        }
    }
    if (touch_initialized) {
        const int shutdown_result = ads7846_shutdown();
        if (shutdown_result != 0) {
            giftui_fault_record(
                GIFTUI_FAULT_TOUCH_CONTROLLER,
                shutdown_result);
        }
        if (result == 0 && shutdown_result != 0) {
            result = shutdown_result;
        }
    }
    return result;
}
