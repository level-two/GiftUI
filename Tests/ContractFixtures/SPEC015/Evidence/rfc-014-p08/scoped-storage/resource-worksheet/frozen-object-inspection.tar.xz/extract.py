import sys
sys.dont_write_bytecode = True
import hashlib, importlib.util, json, lzma, pathlib, re, subprocess

root = pathlib.Path('/Users/eugene/work/GiftUI')
out = pathlib.Path('/private/tmp/giftui-p08-worksheet')
spec = importlib.util.spec_from_file_location('facts', root / 'scripts/contracts/p08_layout_facts.py')
facts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(facts)
obj = root / '.build/nrf52840/contracts/p08-counter-9sc79u_m/P08CounterRuntime.o'
elf = facts.ELF(obj.read_bytes())
symbols = [s for s in elf.symbols if s['type'] == 2 and s['size'] and 0 < s['owner'] < len(elf.sections)]
demangler = root / '.toolchains/host/swift-6.4.0-RELEASE-osx/usr/bin/swift-demangle'
names = subprocess.check_output([str(demangler), '--compact'], input=('\n'.join(s['name'] for s in symbols) + '\n').encode()).decode().splitlines()
bysection = {s['owner']: (s, n) for s, n in zip(symbols, names)}
seeds = [9972,9976,9980,4340,4332,4336,4246,4250,4269,4281,4029,210,12084,12088,4037,10411,12375,4044,12379,4048,3433,3176,3437,3441,3445,3449,3453,3457,3461,3465,3469,3473,11852,11856,11860,11864,3421,3994,3983,3990,3967,3716,3728,3740,3823,3863,3882,4316,4301,3477]
selected = set(seeds)
for sec in [3823,3863,3967]:
    for r in elf.relocations(bysection[sec][0]):
        target = elf.symbol_tables[r['symbol_table']][r['symbol_index']]
        if target['owner'] in bysection and not bysection[target['owner']][1].startswith(('OUTLINED', 'outlined', 'partial apply')):
            selected.add(target['owner'])
selected.update([4216,4184,4157,4224,4273,4277,4257,4261,4265,12008,12014,12002])
# Generic REL32 expansion found 274 sections before disassembly and stopped.
# Inspect only the 50 named source-feasible Embedded spine/phase seeds.
assert len(selected) <= 100, len(selected)
tool = root / '.toolchains/nrf52840/zephyr-sdk-0.17.4/arm-zephyr-eabi/bin/arm-zephyr-eabi-objdump'
rows = []
for sec in sorted(selected):
    symbol, name = bysection[sec]
    argv = [str(tool), '-dr', '-j', elf.sections[sec]['name'], str(obj)]
    body = subprocess.check_output(argv, text=True)
    (out / f'body-{sec}.txt.xz').write_bytes(lzma.compress(body.encode()))
    instructions = []
    for line in body.splitlines():
        match = re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{4}\s+)+(.+)', line)
        if match:
            instructions.append((int(match[1], 16), match[2].strip()))
    frame, terms = 0, []
    for addr, ins in instructions:
        op = ins.split()[0]
        operands = ins[len(op):].strip()
        if op.startswith(('bl', 'b.')) or op in ('b', 'bx', 'cbz', 'cbnz'):
            break
        amount = None
        if op in ('push','push.w','vpush') or op in ('stmdb','stmdb.w','vstmdb') and operands.startswith('sp!'):
            count = 0
            for reg in re.search(r'\{([^}]+)\}', operands).group(1).split(','):
                reg = reg.strip()
                if '-' in reg:
                    a,b = reg.split('-')
                    count += int(re.search(r'\d+', b).group()) - int(re.search(r'\d+', a).group()) + 1
                else:
                    count += 1
            amount = count * (8 if op.startswith('v') else 4)
        elif re.match(r'sub(?:\.w|w)?$', op) and re.match(r'sp,\s*(?:sp,\s*)?#', operands):
            amount = int(re.search(r'#(0x[0-9a-f]+|[0-9]+)', operands).group(1), 0)
        elif re.match(r'str(?:\.w)?$',op) and re.search(r'\[sp,\s*#-(0x[0-9a-f]+|[0-9]+)\]!', operands):
            amount = int(re.search(r'#-(0x[0-9a-f]+|[0-9]+)', operands).group(1), 0)
        if amount is not None:
            frame += amount
            terms.append([addr, ins, amount])
    rels = []
    for r in elf.relocations(symbol):
        if r['type'] not in (3, 10, 30):
            continue
        target = elf.symbol_tables[r['symbol_table']][r['symbol_index']]
        r.update(target_section=target['owner'], target_type=target['type'], target_name=bysection[target['owner']][1] if target['owner'] in bysection else target['name'])
        rels.append(r)
    sp_writes = [[a,i] for a,i in instructions if re.match(r'(push|pop|vpush|vpop|stmdb|ldmia)',i) and ('sp!' in i or i.startswith(('push','pop','vpush','vpop'))) or re.match(r'\S+\s+sp[,!]', i) or re.search(r'\[sp,.*\]!',i)]
    indirect = [[a,i] for a,i in instructions if re.match(r'(blx|bx)\s+(?!lr\b)', i) or re.match(r'(ldr|mov)(?:\.w)?\s+pc\b', i)]
    rows.append(dict(section=sec, symbol=symbol, demangled=name, argv=argv, entry_reservation=frame, entry_terms=terms, sp_writes=sp_writes, indirect=indirect, relocs=rels, instructions=instructions))
result = dict(object=str(obj.relative_to(root)), sha256=hashlib.sha256(obj.read_bytes()).hexdigest(), limit=100, selected_count=len(rows), scope='bounded complete bodies; entry reservation is not an upper bound; all SP writes and indirect instructions retained for manual disposition', rows=rows)
(out / 'selected.json').write_text(json.dumps(result,indent=2)+'\n')
print('selected',len(rows),'functions; object',result['sha256'])
for row in rows:
    print(row['section'], row['entry_reservation'], 'indirect',len(row['indirect']), 'SPwrites',len(row['sp_writes']), row['demangled'][:95])
