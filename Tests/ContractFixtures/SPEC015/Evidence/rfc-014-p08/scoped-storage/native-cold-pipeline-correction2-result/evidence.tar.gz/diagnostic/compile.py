from pathlib import Path
import argparse,json,subprocess,shutil
ROOT=Path.cwd(); OUT=ROOT/'.build/contracts/p08-native-cold-correction2-codegen'; ORIGINAL=ROOT/'.build/contracts/p08-counter-w700p_zi'; BASE=ROOT/'.build/contracts/p08-native-cold-static-screen-candidate1-current/candidate'
a=argparse.ArgumentParser();a.add_argument('module');args=a.parse_args()
OUT.mkdir(exist_ok=True)
checks=json.loads((ORIGINAL/'checks.json').read_text())['checks']
key='GiftUIExecution' if args.module=='GiftUI' else args.module
row=next((c for c in checks if c['name']==key),None)
if row is None:
 receipt=json.loads((ORIGINAL/'result.json').read_text())
 for field in ('host_build','core_build'):
  owner=ROOT/receipt[field]; cp=owner/'checks.json'
  if cp.exists():
   rows=json.loads(cp.read_text())['checks']
   row=next((c for c in rows if c['name']==key),None)
   if row is not None:break
assert row is not None,key
cmd=[s.replace('${OUT}',str(OUT)).replace(str(ORIGINAL),str(OUT)) for s in row['identity']['command']]
if args.module=='GiftUI':
 cmd=[x.replace('GiftUIExecution','GiftUI') for x in cmd if not x.endswith('.swift')]
 pos=cmd.index('-emit-module-path');cmd[pos:pos]=[str(p) for p in sorted((ROOT/'Sources/GiftUI').glob('*.swift'))]
cmd = [str(OUT/'macro/GiftUIMacros-tool')+'#GiftUIMacros' if field.endswith('GiftUIMacros-tool#GiftUIMacros') else field for field in cmd]
cmd += ['-diagnostic-style', 'llvm']
(OUT/(args.module+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
log_path=OUT/(args.module+'.log')
if log_path.exists():
 n=1
 while (OUT/(args.module+f'-feedback{n}.log')).exists():n+=1
 shutil.copyfile(log_path,OUT/(args.module+f'-feedback{n}.log'))
with log_path.open('wb') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
print(args.module,'compiler exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
