from pathlib import Path
import re,json
rules={
'Sources/GiftUITextResources/GiftUITextResources.swift': {'validate'},
'Sources/GiftUIReferenceTextResources/GiftUIReferenceTextResources.swift': {'withPayload'},
'Sources/GiftUISemanticCore/SemanticRecordExpansion.swift': {'expand','enterDeclarationRole','stageSemanticOccurrence','stageModifierApplication','stageActionOccurrence'},
'Sources/GiftUISemanticCore/SemanticRecordStore.swift': {'withSemanticRecordStore','beginCandidate','withCandidateView','withPublishedView','withView'},
'Sources/GiftUIObservableState/ObservableSemanticBodyBinding.swift': {'evaluate','evaluateStateful'},
'Sources/GiftUIObservableState/ObservableModelScope.swift': {'withRead','withDiscovery','materialize'},
'Sources/GiftUIObservableState/ObservableStateRootScope.swift': {'withBoundDeclaration','withEvaluatedBody','encounter','visit'},
'Sources/GiftUIObservableState/ObservableStateRootTargetAccess.swift': {'currentGeneration','mutate'},
'Sources/GiftUIInteraction/ExecutionGestureAdapter.swift': {'down','move','up'},
'Sources/GiftUIInteraction/InteractionState.swift': {'resolveDown','resolveMove','resolveUp','topmostRecord','containsCandidate','matchingCommittedGeneration','append'},
'Sources/GiftUIInteraction/InteractionOwnedKeyState.swift': {'resolveDown','resolveMove','resolveUp','append'},
'Sources/GiftUIRuntimeCore/RuntimeRecordInteractionBridge.swift': {'dispatch','appendProjected'},
'Sources/GiftUIRuntimeCore/ObservableCanvasInvocationSource.swift': {'invokeCanvas'},
'Sources/GiftUIRuntimeCore/RuntimeCompletePipeline.swift': {'run'},
'Sources/GiftUIHostConfiguration/HostActivationController.swift': {'activate','teardown','contain'},
'Sources/GiftUIHostConfiguration/SignalAnalyzerPresetHostInstance.swift': {'activate','runOpportunity','teardown'},
'Sources/GiftUIHostConfiguration/HostScheduledOpportunityController.swift': {'service','complete'},
'Sources/GiftUILayout/LayoutSemanticValidation.swift': {'validateOccurrence'},
'Sources/GiftUILayout/LayoutEngine.swift': {'measureText','finalizeTextLine','placeTextGeometry'},
'Sources/GiftUILayout/LayoutPublication.swift': {'publishLayout'},
'Sources/GiftUIDrawing/CanvasStagedValues.swift': {'withCanvasStagedValues','stage'},
'Sources/GiftUIDrawing/CanvasRenderProducer.swift': {'preflight','produce','visit'},
'Sources/GiftUIRenderLowering/RenderProducer.swift': {'produce','stream'},
'Sources/GiftUIRasterCore/RasterGlyphCoverage.swift': {'withValidatedPayload','rasterize'},
'Sources/GiftUIRasterCore/FullSurfaceRGBA8888Buffer.swift': {'withBytes'},
'Tests/ContractFixtures/SPEC015/RuntimeDerived/CounterSemantic.swift': {'role','matches'},
'Tests/ContractFixtures/SPEC015/RuntimeDerived/CounterNativeRaster.swift': {'withBytes'},
}
# Internal visitor/attempt operations form the existing recursively specialized
# algorithm, rather than a replacement traversal. Only concrete definitions here.
p=Path('Sources/GiftUISemanticCore/GiftUISemanticCore.swift');t=p.read_text();start=t.index('struct SemanticExpansionAttempt')
lines=t.splitlines(keepends=True);offset=0;out=[]
for line in lines:
 if offset>=start and re.match(r'\s*(?:private )?(?:package )?(?:static )?(?:borrowing |mutating )?func ',line):
  recent=''.join(out[-5:])
  if '@inlinable' not in recent: out.append(re.match(r'\s*',line)[0]+'@inlinable\n')
  if '@inline(__always)' not in recent: out.append(re.match(r'\s*',line)[0]+'@inline(__always)\n')
 out.append(line);offset+=len(line)
p.write_text(''.join(out))
changes={str(p):'existing attempt/traversal bodies and finite entry'}
for path,names in rules.items():
 p=Path(path);lines=p.read_text().splitlines(keepends=True);out=[];matched=[]
 for line in lines:
  m=re.match(r'^(\s*)(?:(?:package|public|private|fileprivate) )?(?:static )?(?:borrowing |mutating )?func (\w+)',line)
  if m and m[2] in names:
   recent=''.join(out[-5:]); indent=m[1]
   if '@inlinable' not in recent:out.append(indent+'@inlinable\n')
   if '@inline(__always)' not in recent:out.append(indent+'@inline(__always)\n')
   matched.append(m[2])
  out.append(line)
 assert matched,path
 p.write_text(''.join(out));changes[path]=matched
Path('.build/contracts/p08-native-cold-correction1-codegen/annotation-selection.json').write_text(json.dumps(changes,indent=2)+'\n')
print('selected',len(changes),'files with exact function names; no algorithm-body edits')
