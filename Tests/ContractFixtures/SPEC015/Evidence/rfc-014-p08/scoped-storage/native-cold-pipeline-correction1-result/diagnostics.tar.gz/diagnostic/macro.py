from pathlib import Path
import json,subprocess,hashlib
root=Path.cwd();out=root/'.build/contracts/p08-native-cold-correction1-codegen/macro';out.mkdir(exist_ok=True)
old=root/'.build/rfc014-p02-swift64/tool';cmds=[]
for line in (old/'debug.yaml').read_text().splitlines():
 if line.startswith('    args: ['):
  a=json.loads(line.split('args: ',1)[1])
  if '-module-name' in a and a[a.index('-module-name')+1]=='GiftUIMacros':cmds.append(a)
compile=next(a for a in cmds if '-c' in a);link=next(a for a in cmds if '-c' not in a)
compiler=root/'.toolchains/host/swift-6.4.0-RELEASE-osx/usr/bin/swiftc'
assert hashlib.sha256(compiler.read_bytes()).digest()==hashlib.sha256(Path(compile[0]).read_bytes()).digest()
oldmap=Path(compile[compile.index('-output-file-map')+1]);mapping=json.loads(oldmap.read_text());newmap={}
for k,values in mapping.items():
 newmap[k]={name:str(out/Path(value).name) for name,value in values.items()}
(out/'outputs.json').write_text(json.dumps(newmap,indent=2)+'\n')
compile[0]=str(compiler)
for flag,value in [('-emit-module-path',str(out/'GiftUIMacros.swiftmodule')),('-output-file-map',str(out/'outputs.json')),('-module-cache-path',str(out/'cache')),('-index-store-path',str(out/'index'))]:compile[compile.index(flag)+1]=value
(out/'compile-command.json').write_text(json.dumps(compile,indent=2)+'\n')
with (out/'compile.log').open('wb') as log:subprocess.run(compile,stdout=log,stderr=subprocess.STDOUT,check=True)
oldlist=Path(next(x[1:] for x in link if x.startswith('@/')));newlist=out/'Objects.LinkFileList';newlist.write_text('\n'.join(str(out/Path(x).name) for x in oldlist.read_text().splitlines())+'\n')
link[0]=str(compiler);link[link.index('-o')+1]=str(out/'GiftUIMacros-tool');link=[('@'+str(newlist)) if x=='@'+str(oldlist) else str(out/'GiftUIMacros.swiftmodule') if x.endswith('/Modules-tool/GiftUIMacros.swiftmodule') else x for x in link]
(out/'link-command.json').write_text(json.dumps(link,indent=2)+'\n')
with (out/'link.log').open('wb') as log:subprocess.run(link,stdout=log,stderr=subprocess.STDOUT,check=True)
print('PASS: changed macro tool compiled/linked separately; original frozen plugin untouched')
