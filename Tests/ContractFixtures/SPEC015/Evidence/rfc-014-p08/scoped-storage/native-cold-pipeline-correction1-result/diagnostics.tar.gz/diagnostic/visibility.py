from pathlib import Path
import re,json,sys
root=Path.cwd();base=root/'.build/contracts/p08-native-cold-correction1-codegen'
log=Path(sys.argv[1]);text=log.read_text();notes={}
for file,line,msg in re.findall(r'^(/[^:\n]+):(\d+):\d+: note: (.+)$',text,re.M):
 if "not '@usableFromInline' or public" in msg or msg=='type declared here':notes.setdefault(Path(file),set()).add(int(line))
selected={}
for p,nums in notes.items():
 assert p.is_relative_to(root/'Sources'),p
 lines=p.read_text().splitlines(keepends=True);out=[];record=[]
 for number,line in enumerate(lines,1):
  target=number in nums
  if target and re.match(r'\s*(?:case |associatedtype )',line):target=False
  # Inlinable declarations must have module visibility; never source-public.
  if 'private ' in line and re.search(r'\bfunc ',line) and '@inlinable' in ''.join(out[-5:]):target=True
  if target:
   assert re.search(r'\b(struct|enum|protocol|class|func|var|let|init|typealias)\b',line),(p,number,line)
   line=line.replace('fileprivate ','').replace('private(set) ','').replace('private ','')
   prefix=[]
   for previous in reversed(out):
    if previous.lstrip().startswith('@') and not re.search(r'\b(?:let|var|func|struct|enum|protocol|typealias|init)\b',previous): prefix.append(previous)
    else: break
   recent=''.join(prefix);indent=re.match(r'\s*',line)[0]
   if '@inlinable' not in recent and '@usableFromInline' not in recent:
    out.append(indent+'@usableFromInline\n')
   record.append({'line_before':number,'declaration':line.strip()})
  out.append(line)
 p.write_text(''.join(out));selected[str(p.relative_to(root))]=record
# Errors pointing at the @inlinable attribute before private functions have no
# separate declaration note. Process only those already-selected function bodies.
for p in (root/'Sources').rglob('*.swift'):
 # Restrict mutation to files already participating in the overlay.
 if p.name not in {'GiftUISemanticCore.swift','SemanticRecordStore.swift','SemanticRecordExpansion.swift'}:continue
 s=p.read_text();s=re.sub(r'(@inlinable\n\s*@inline\(__always\)\n\s*)(?:fileprivate|private) (mutating |borrowing )?func ',r'\1\2func ',s)
 p.write_text(s)
(base/(log.stem+'-visibility.json')).write_text(json.dumps(selected,indent=2)+'\n')
print('compiler-required visibility declarations',sum(map(len,selected.values())), 'in',len(selected),'files')
