import P08CounterNativeExclusivity
@main struct Main { @MainActor static func main() { let count = p08CounterScopedExclusivity(negative: false); precondition(count == 1) } }
