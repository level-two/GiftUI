import P08CounterNativeExclusivity
@main struct Main { @MainActor static func main() { let count = p08CounterScopedExclusivity(negative: true); precondition(count == 1) } }
