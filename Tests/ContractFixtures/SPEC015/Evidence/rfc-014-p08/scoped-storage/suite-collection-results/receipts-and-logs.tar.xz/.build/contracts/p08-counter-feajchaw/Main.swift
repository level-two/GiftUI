import P08CounterRuntime
import Darwin
@main struct Main { static func main() { setbuf(stdout, nil); print("P08 counter components assertions=\(p08CounterRoute() + p08CounterModel() + p08CounterSemantic() + p08CounterFixedStorage() + p08CounterCoordinator()) failures=0") } }
