from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / '.build/contracts/p08-witness-annotation-compatibility'
for path, expected in json.loads((OUT / 'freeze.json').read_text()).items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, path
assert not (OUT / 'checks.json').exists(), 'No automatic retry'
checks = []
for stage in json.loads((OUT / 'stages.json').read_text()):
    name = stage['name']
    log = OUT / (name + '.log')
    assert not log.exists(), 'No receipt overwrite'
    environment = None
    if stage.get('runner_environment'):
        environment = dict(os.environ)
        environment.update(json.loads((OUT / 'runner-environment.json').read_text()))
    with log.open('wb') as output:
        result = subprocess.run(stage['command'], cwd=ROOT, stdout=output,
                                stderr=subprocess.STDOUT, env=environment)
    errors = re.findall(r'^.*:\d+:\d+: error: (.*)$', log.read_text(), re.M)
    expected = stage.get('expected_errors', [])
    passed = result.returncode == 0 if not expected else (
        result.returncode != 0 and len(errors) == len(expected)
        and all(any(message == pattern for message in errors) for pattern in expected))
    row = dict(stage, exit=result.returncode, errors=errors, passed=passed)
    checks.append(row)
    (OUT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    print(name, result.returncode, 'PASS' if passed else 'FAIL', flush=True)
    if not passed:
        sys.exit(1)
print('FOCUSED MACRO/PROVIDER/COMPATIBILITY/PRIVACY PASS; physical/actual-host/cold pending', flush=True)
