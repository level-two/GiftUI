import hashlib,importlib.util,json,lzma,pathlib,re,subprocess,tarfile
root=pathlib.Path.cwd();obj=root/'.build/nrf52840/contracts/p08-counter-ji2g9krm/P08CounterRuntime.o';sp=importlib.util.spec_from_file_location('facts',root/'scripts/contracts/p08_layout_facts.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);elf=m.ELF(obj.read_bytes());byname={s['name']:s for s in elf.symbols if s['type']==2 and s['size']}
old={};a=root/'Tests/ContractFixtures/SPEC015/Evidence/rfc-014-p08/scoped-storage/structured-operations-cycle1-analysis.tar.xz'
with tarfile.open(a) as t:
 for f in t.getmembers():
  if f.name.endswith('bounded-frames-and-calls.json'):
   for r in json.load(t.extractfile(f))['rows']:old[r['section']]=r
wanted=[4273,4304,210,4041,4048,4052,3441,4002,3979,3875,3835,3752,3740,3704,3708,7461,6781,3987,3998,4308,3918,3894,3501,3226,3238,3234,3728,3732,3736,3744,4172]+list(range(3445,3486,4))
selected={};missing=[]
for n in wanted:
 v=byname.get(old[n]['symbol']['name'])
 if v:selected[v['owner']]=v
 else:missing.append(n)
for n,v in byname.items():
 if any(x in n for x in ['ConstructStaticStorage','ConstructDynamicStorage','FinishMetadataTwo','matchesBackend','matchesRoot','matchesAction','matchesCandidate']):selected[v['owner']]=v
# The same semantic lender reached by the exact original source body relocation.
for rel in elf.relocations(byname[old[4041]['symbol']['name']]):
 if 'withSemanticRecordStore' in rel['symbol']:
  v=elf.symbol_tables[rel['symbol_table']][rel['symbol_index']];selected[v['owner']]=v
packet=root/'Tests/ContractFixtures/SPEC015/Evidence/rfc-014-p08/scoped-storage/structured-operations-cycle2-screen';packet.mkdir(exist_ok=True)
sections=sorted(selected);symbols=[selected[n] for n in sections];tool=root/'.toolchains/nrf52840/zephyr-sdk-0.17.4/arm-zephyr-eabi/bin/arm-zephyr-eabi-objdump';demangler=root/'.toolchains/host/swift-6.4.0-RELEASE-osx/usr/bin/swift-demangle';names=subprocess.run([str(demangler),'--compact'],input='\n'.join(s['name'] for s in symbols)+'\n',text=True,capture_output=True,check=True).stdout.splitlines();rows=[]
for n,sym,name in zip(sections,symbols,names):
 argv=[str(tool),'-dr','--start-address=0','--stop-address=128','-j',elf.sections[n]['name'],str(obj)];text=subprocess.run(argv,text=True,capture_output=True,check=True).stdout;(packet/f'prologue-{n}.txt.xz').write_bytes(lzma.compress(text.encode()));instructions=[]
 for line in text.splitlines():
  match=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{4}\s+)+(.+)',line)
  if match:instructions.append((int(match[1],16),match[2].strip()))
 frame=0;terms=[];unknown=[]
 for addr,ins in instructions:
  op=ins.split()[0];operands=ins[len(op):].strip()
  if op.startswith(('bl','b.')) or op in ('b','bx','cbz','cbnz'):break
  if op in ('push','push.w','vpush') or op in ('stmdb','stmdb.w','vstmdb') and operands.startswith('sp!'):
   regs=re.search(r'\{([^}]+)\}',operands).group(1);count=0
   for reg in regs.split(','):
    reg=reg.strip()
    if '-' in reg:
     x,y=reg.split('-');count+=int(re.search(r'\d+',y).group())-int(re.search(r'\d+',x).group())+1
    else:count+=1
   amount=count*(8 if op.startswith('v') else 4);frame+=amount;terms.append([addr,ins,amount])
  elif re.match(r'sub(?:\.w|w)?$',op) and re.match(r'sp,\s*(?:sp,\s*)?#',operands):
   amount=int(re.search(r'#(0x[0-9a-f]+|[0-9]+)',operands).group(1),0);frame+=amount;terms.append([addr,ins,amount])
  elif re.match(r'str(?:\.w)?$',op) and re.search(r'\[sp,\s*#-(0x[0-9a-f]+|[0-9]+)\]!',operands):
   amount=int(re.search(r'#-(0x[0-9a-f]+|[0-9]+)',operands).group(1),0);frame+=amount;terms.append([addr,ins,amount])
  elif operands.startswith('sp,') and op.startswith(('sub','bic','bfc','and')):unknown.append([addr,ins])
 relocs=elf.relocations(sym)
 for rel in relocs:
  target=elf.symbol_tables[rel['symbol_table']][rel['symbol_index']];rel.update(target_section=target['owner'],target_type=target['type'],target_size=target['size'])
 rows.append(dict(section=n,symbol=sym,demangled=name,entry_fixed_stack_lower_bound=frame,prologue_terms=terms,unknown_stack_adjustments=unknown,first_instructions=instructions,relocations=relocs,command=argv))
(packet/'bounded-frames-and-calls.json').write_text(json.dumps(dict(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),parser_scope='fixed prologue before first branch/call; lower bound only; sub/sub.w/subw included',missing_prior_symbols=missing,rows=rows),indent=2)+'\n')
for r in rows:print(r['section'],r['entry_fixed_stack_lower_bound'],r['demangled'][:115])
