# Independently qualified Native coverage union

The frozen combined ledger has SHA28515273775d1b8afc86d3a0dd0a119839d89b7e796b9b922c42af92f6862900.
Each profile covers426labels by384fresh selected controls,19matching preparation
and23retained runtime/projection/exclusivity checks. Raw focused receipts remain
incomplete/aggregate-false. This is not a new full driver receipt or P08 exit.

After extraction, `python3 verify-live-coverage.py` independently rechecks all
source/dependency/compiler/flag/check identities, current201inputs, per-label
classifiers/observations/twins and raw artifacts in the four original local build
directories. Those binaries are intentionally not committed. Archive textual
receipts, generated variants, commands/logs and sources remain available even if
local binaries are later removed; revalidation then requires the frozen local
artifacts, not silently reconstructed substitutes. No build or runtime is run.
