import GiftUI
func reject<D: _GiftUIReadDomain>(_ slots: Span<D.Slot>) { _ = _GiftUIFrameRead<D>(slots: slots) }
