@inlinable
@inline(__always)
fileprivate mutating func _giftUIVisitObservableStateDeclarations<
    Visitor: _GiftUIObservableStateDeclarationVisitor & ~Copyable & ~Escapable
>(_ visitor: inout Visitor) {
    visitor.visit(&_model, declarationOrdinal: 0)
}

@inlinable
@inline(__always)
fileprivate func _giftUITraverse<Visitor: _GiftUISemanticTraversalVisitor & ~Copyable & ~Escapable>(
    _ visitor: inout Visitor
) where Visitor.Domain == Domain {
    visitor.visitStatefulCustomView(self) {
        (declaration: borrowing Self, read: borrowing _GiftUIFrameRead<Domain>)
            throws(_GiftUIAccessFailure) in
        try declaration._giftUIEvaluate(read: read)
    }
}

// original-source-range: /Users/eugene/work/GiftUI/.build/contracts/p08-checked-state-correction2/privacy/ordinary-unlowered-private-positive.swift:8:1-8:1
