import Foundation
import XCTest
@main struct CheckedStateTests {
    static func main() {
        XCTMain([testCase([
            ("testActualLoweredStateOutputHasSeparatedHelperDeclarations", ObservableStateHostMacroTests.testActualLoweredStateOutputHasSeparatedHelperDeclarations)
        ])])
    }
}
