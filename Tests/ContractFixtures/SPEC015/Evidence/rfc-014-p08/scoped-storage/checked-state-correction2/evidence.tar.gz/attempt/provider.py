from pathlib import Path
import hashlib,json,subprocess,sys,os
ROOT=Path.cwd(); OUT=ROOT/'.build/contracts/p08-checked-state-correction2'; OLD=ROOT/'.build/contracts/p08-native-cold-correction2-codegen'
commands=[];checks=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,cmd,env=None):
    assert not (OUT/(name+'.log')).exists(), 'No hidden retry'
    (OUT/(name+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
    with (OUT/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=env)
    checks.append({'name':name,'exit':r.returncode,'command':cmd})
    (OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(name,r.returncode,flush=True)
    if r.returncode: sys.exit(r.returncode)
# Reuse the pinned archived tool recipe, write every output to this fresh attempt.
macro=OUT/'macro';macro.mkdir()
command=json.loads((OLD/'macro/compile-command.json').read_text())
command=[s.replace(str(OLD),str(OUT)) for s in command]
mapping=json.loads((OLD/'macro/outputs.json').read_text())
mapping={k:{n:v.replace(str(OLD),str(OUT)) for n,v in values.items()} for k,values in mapping.items()}
(macro/'outputs.json').write_text(json.dumps(mapping,indent=2)+'\n')
link=[s.replace(str(OLD),str(OUT)) for s in json.loads((OLD/'macro/link-command.json').read_text())]
(macro/'Objects.LinkFileList').write_text((OLD/'macro/Objects.LinkFileList').read_text().replace(str(OLD),str(OUT)))
sources=list((ROOT/'Sources/GiftUI').glob('*.swift'))+list((ROOT/'Sources/GiftUIMacros').glob('*.swift'))
(OUT/'source-hashes.json').write_text(json.dumps({str(p.relative_to(ROOT)):sha(p) for p in sorted(sources)},indent=2)+'\n')
(OUT/'compiler-hash.txt').write_text(sha(command[0])+'\n')
run('macro-compile',command)
run('macro-link',link)
# Execute the maintained actual-output regression itself, not a reimplementation.
imports=[]
for i,flag in enumerate(command[:-1]):
    if flag in ('-I','-F'):imports.extend([flag,command[i+1]])
syntax=next(Path(command[i+1]) for i,flag in enumerate(command[:-1]) if flag=='-I' and '/prebuilts/swift-syntax/' in command[i+1])
framework=Path('/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/Library/Frameworks')
regression=[command[0],'-swift-version','6','-target','arm64-apple-macosx15.0','-sdk',command[command.index('-sdk')+1],'-module-cache-path',str(OUT/'test-cache'),'-disable-sandbox','-I',str(macro),*imports,'-parse-as-library',str(OUT/'TestMain.swift'),str(ROOT/'Tests/GiftUIMacrosTests/ObservableStateHostMacroTests.swift'),*[line for line in (macro/'Objects.LinkFileList').read_text().splitlines()],'-L',str(syntax.parent/'lib'),'-lMacroSupport','-F',str(framework),'-Xlinker','-rpath','-Xlinker',str(framework),'-Xlinker','-rpath','-Xlinker',str(ROOT/'.toolchains/host/swift-6.4.0-RELEASE-osx/usr/lib/swift/macosx'),'-o',str(OUT/'actual-output-regression')]
run('regression-compile',regression)
env=dict(os.environ,GIFTUI_P08_REGRESSION_ROOT=str(ROOT),GIFTUI_P08_REGRESSION_OUTPUT=str(OUT/'regression-output'))
(OUT/'regression-environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith('GIFTUI_P08_')},indent=2)+'\n')
run('actual-output-regression',[str(OUT/'actual-output-regression')],env)

lower=[s.replace(str(OLD),str(OUT)) for s in json.loads((OLD/'lower-command.json').read_text())]
run('lower',lower)
original=ROOT/'.build/contracts/p08-counter-w700p_zi'
rows=json.loads((original/'checks.json').read_text())['checks']
row=next(r for r in rows if r['name']=='GiftUIExecution')
cmd=[s.replace('${OUT}',str(OUT)).replace(str(original),str(OUT)) for s in row['identity']['command']]
cmd=[x.replace('GiftUIExecution','GiftUI') for x in cmd if not x.endswith('.swift')]
pos=cmd.index('-emit-module-path');cmd[pos:pos]=[str(p) for p in sorted((ROOT/'Sources/GiftUI').glob('*.swift'))]
cmd=[str(macro/'GiftUIMacros-tool')+'#GiftUIMacros' if x.endswith('GiftUIMacros-tool#GiftUIMacros') else x for x in cmd]
cmd+=['-diagnostic-style','llvm']
run('GiftUI',cmd)
for name in ['P08CounterSchema','P08CounterPresentation']:
    cmd=[s.replace(str(OLD),str(OUT)) for s in json.loads((OLD/(name+'-command.json')).read_text())]
    run(name,cmd)
print('PROVIDER COMPILE PASS; privacy/codegen remain',flush=True)
