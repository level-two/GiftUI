from pathlib import Path
import json
import os
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / '.build/contracts/p08-checked-state-correction2'
OLD = ROOT / '.build/contracts/p08-native-cold-correction2-codegen'
checks = json.loads((OUT / 'checks.json').read_text())


def run(name, command, environment=None):
    assert not (OUT / (name + '.log')).exists(), 'No hidden retry'
    (OUT / (name + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log,
                                stderr=subprocess.STDOUT, env=environment)
    checks.append({'name': name, 'exit': result.returncode, 'command': command})
    (OUT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        sys.exit(result.returncode)


# One confirmed macOS runner-only setup repair; preserve the original failure.
macro = OUT / 'macro'
command = json.loads((OUT / 'regression-compile-command.json').read_text())
command = [argument.replace(str(OUT / 'TestMain.swift'),
                           str(OUT / 'TestMain-macos.swift')) for argument in command]
run('regression-compile-macos-setup1', command)
environment = dict(os.environ,
                   GIFTUI_P08_REGRESSION_ROOT=str(ROOT),
                   GIFTUI_P08_REGRESSION_OUTPUT=str(OUT / 'regression-output'))
(OUT / 'regression-environment.json').write_text(json.dumps(
    {key: value for key, value in environment.items() if key.startswith('GIFTUI_P08_')},
    indent=2) + '\n')
run('actual-output-regression', [str(OUT / 'actual-output-regression')], environment)

# Only a real maintained-test PASS permits the unchanged fresh provider recipes.
lower = [argument.replace(str(OLD), str(OUT))
         for argument in json.loads((OLD / 'lower-command.json').read_text())]
run('lower', lower)
original = ROOT / '.build/contracts/p08-counter-w700p_zi'
rows = json.loads((original / 'checks.json').read_text())['checks']
row = next(item for item in rows if item['name'] == 'GiftUIExecution')
command = [argument.replace('${OUT}', str(OUT)).replace(str(original), str(OUT))
           for argument in row['identity']['command']]
command = [argument.replace('GiftUIExecution', 'GiftUI')
           for argument in command if not argument.endswith('.swift')]
position = command.index('-emit-module-path')
command[position:position] = [str(path) for path in sorted((ROOT / 'Sources/GiftUI').glob('*.swift'))]
command = [str(macro / 'GiftUIMacros-tool') + '#GiftUIMacros'
           if argument.endswith('GiftUIMacros-tool#GiftUIMacros') else argument
           for argument in command]
command += ['-diagnostic-style', 'llvm']
run('GiftUI', command)
for name in ['P08CounterSchema', 'P08CounterPresentation']:
    command = [argument.replace(str(OLD), str(OUT)) for argument in
               json.loads((OLD / (name + '-command.json')).read_text())]
    run(name, command)
print('PROVIDER COMPILE PASS; privacy/codegen remain', flush=True)
