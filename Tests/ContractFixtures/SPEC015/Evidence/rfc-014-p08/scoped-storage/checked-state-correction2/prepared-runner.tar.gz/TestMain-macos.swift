import Foundation
import XCTest

@main struct CheckedStateTests {
    static func main() {
        let suite = XCTestSuite(name: "P08 actual lowerer output")
        let test = ObservableStateHostMacroTests(selector:
            #selector(ObservableStateHostMacroTests.testActualLoweredStateOutputHasSeparatedHelperDeclarations))
        suite.addTest(test)
        suite.run()
        guard let run = suite.testRun else { fatalError("XCTest did not produce a test run") }
        print("executions=\(run.executionCount) failures=\(run.totalFailureCount) skips=\(run.skipCount)")
        guard run.executionCount == 1, run.totalFailureCount == 0, run.skipCount == 0 else { exit(1) }
    }
}
