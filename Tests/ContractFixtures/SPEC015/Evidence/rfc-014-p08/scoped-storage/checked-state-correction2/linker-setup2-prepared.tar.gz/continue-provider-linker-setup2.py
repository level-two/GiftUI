from pathlib import Path
import json
import hashlib
import os
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / '.build/contracts/p08-checked-state-correction2'
OLD = ROOT / '.build/contracts/p08-native-cold-correction2-codegen'
checks = json.loads((OUT / 'checks.json').read_text())
assert [(row['name'], row['exit']) for row in checks] == [
    ('macro-compile', 0), ('macro-link', 0), ('regression-compile', 1),
    ('regression-compile-macos-setup1', 1)], 'Unexpected prior-stage state'
receipt = json.loads((ROOT / 'Tests/ContractFixtures/SPEC015/Evidence/rfc-014-p08/scoped-storage/checked-state-correction2/result.json').read_text())
for relative, expected in receipt['source_after_hashes'].items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative
for path, expected in receipt['preserved_macro_binary_hashes'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
assert not (OUT / 'actual-output-regression').exists(), 'Prior executable must not be overwritten'
for path, expected in {'/Users/eugene/work/GiftUI/.build/contracts/p08-checked-state-correction2/TestMain-macos.swift': 'f6aaa24985e00a4ec4523d76a854e9138e994e82a6f3d3236586a09556be779a', '/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/usr/lib/libXCTestSwiftSupport.dylib': '4b7026c2345b6e3cae23b8caefa52784a98bf96e3b895f9a42fe518aeb420c5b', '/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/usr/lib/lib_TestingInterop.dylib': 'b6f6b71fae903978fa7a51381d429c536844a59b87935478c2617fc4dc1901b0', '/Users/eugene/work/GiftUI/.toolchains/p08-comparison/expanded/swift-6.4.0-RELEASE-osx/swift-6.4.0-RELEASE-osx-package.pkg/Payload/usr/lib/swift/macosx/testing/libTesting.dylib': 'f5fbcbe04833975c2cef402e03e7ea8dc84a2af800af2219bb498c9956760cf5', '/Users/eugene/work/GiftUI/.toolchains/p08-comparison/expanded/swift-6.4.0-RELEASE-osx/swift-6.4.0-RELEASE-osx-package.pkg/Payload/usr/lib/swift/macosx/testing/lib_TestingInterop.dylib': '4e8cae2031aec8569c046e53c61bbdd9f86ebd8aa671cf73e2c1d8f6ed04ec50'}.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path




def run(name, command, environment=None):
    assert not (OUT / (name + '.log')).exists(), 'No hidden retry'
    assert not (OUT / (name + '-command.json')).exists(), 'No command overwrite'
    (OUT / (name + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log,
                                stderr=subprocess.STDOUT, env=environment)
    checks.append({'name': name, 'exit': result.returncode, 'command': command})
    (OUT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        sys.exit(result.returncode)


# Explicit second mechanical linker setup only; no source/runner-policy change.
argv_path = OUT / 'regression-compile-macos-setup1-command.json'
assert hashlib.sha256(argv_path.read_bytes()).hexdigest() == 'b51b3f676f7823de998f62a50854466ffbbd46ab5721cc3a47d01a5f624e228f'
original_argv = json.loads(argv_path.read_text())
malformed = [index for index in range(len(original_argv) - 1)
             if original_argv[index:index + 2] == ['-F', '-Xcc']]
assert len(malformed) == 1, 'Expected exactly the confirmed malformed framework pair'
command = list(original_argv)
del command[malformed[0]:malformed[0] + 2]
library_paths = ['/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/usr/lib', '/Users/eugene/work/GiftUI/.toolchains/p08-comparison/expanded/swift-6.4.0-RELEASE-osx/swift-6.4.0-RELEASE-osx-package.pkg/Payload/usr/lib/swift/macosx/testing']
for directory in library_paths:
    assert Path(directory).is_dir(), directory
# Xcode interop v1 precedes toolchain interop v0 and satisfies both required versions.
link_delta = [part for directory in library_paths for part in ['-L', directory]]
link_delta += [part for directory in library_paths
               for part in ['-Xlinker', '-rpath', '-Xlinker', directory]]
command += link_delta
expected = [argument for index, argument in enumerate(original_argv)
            if index not in (malformed[0], malformed[0] + 1)] + link_delta
assert command == expected, 'Only the reviewed pair removal and two -L/rpaths may change'
macro = OUT / 'macro'
run('regression-compile-macos-linker-setup2', command)
environment = dict(os.environ,
                   GIFTUI_P08_REGRESSION_ROOT=str(ROOT),
                   GIFTUI_P08_REGRESSION_OUTPUT=str(OUT / 'regression-output'))
(OUT / 'regression-environment.json').write_text(json.dumps(
    {key: value for key, value in environment.items() if key.startswith('GIFTUI_P08_')},
    indent=2) + '\n')
run('actual-output-regression', [str(OUT / 'actual-output-regression')], environment)

# Only a real maintained-test PASS permits the unchanged fresh provider recipes.
lower = [argument.replace(str(OLD), str(OUT))
         for argument in json.loads((OLD / 'lower-command.json').read_text())]
run('lower', lower)
original = ROOT / '.build/contracts/p08-counter-w700p_zi'
rows = json.loads((original / 'checks.json').read_text())['checks']
row = next(item for item in rows if item['name'] == 'GiftUIExecution')
command = [argument.replace('${OUT}', str(OUT)).replace(str(original), str(OUT))
           for argument in row['identity']['command']]
command = [argument.replace('GiftUIExecution', 'GiftUI')
           for argument in command if not argument.endswith('.swift')]
position = command.index('-emit-module-path')
command[position:position] = [str(path) for path in sorted((ROOT / 'Sources/GiftUI').glob('*.swift'))]
command = [str(macro / 'GiftUIMacros-tool') + '#GiftUIMacros'
           if argument.endswith('GiftUIMacros-tool#GiftUIMacros') else argument
           for argument in command]
command += ['-diagnostic-style', 'llvm']
run('GiftUI', command)
for name in ['P08CounterSchema', 'P08CounterPresentation']:
    command = [argument.replace(str(OLD), str(OUT)) for argument in
               json.loads((OLD / (name + '-command.json')).read_text())]
    run(name, command)
print('PROVIDER COMPILE PASS; privacy/codegen remain', flush=True)
