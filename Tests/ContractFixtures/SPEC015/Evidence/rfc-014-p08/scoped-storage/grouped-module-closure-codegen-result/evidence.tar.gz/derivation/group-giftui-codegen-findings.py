from pathlib import Path
import json,re,gzip,hashlib,collections
R=Path.cwd();O=R/'.build/contracts/p08-grouped-module-closure-codegen';B=R/'Tests/ContractFixtures/SPEC015/Evidence/rfc-014-p08/scoped-storage';M=json.loads((B/'grouped-module-closure-design/candidate-map.json').read_text());I=json.loads((O/'boundary-physical-index.json').read_text());F=json.loads((O/'host-functions.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for e in M['source_edits']:
 module=Path(e['file']).parts[1];decl=e['declaration'];parts=decl.split('.');method=parts[-1];nominal=parts[0] if len(parts)>1 else None
 matches=[x for x in I[module]['functions'] if method in x['demangled'] and (nominal is None or nominal in x['demangled']) and 'protocol witness' not in x['demangled']]
 rows.append({'source':e['file'],'declaration':decl,'bodyless_requirement':'bodyless' in e['edit'],'physical_matches':[{k:x[k] for k in ('name','demangled','function_id','offset_bits','serialized_kind','basic_blocks','linkage','raw_prefix')} for x in matches],'status':'bodyless requirement, no implementation expected' if 'bodyless' in e['edit'] else 'serialized body present' if any(x['basic_blocks'] and x['serialized_kind'] for x in matches) else 'no serialized implementation matched'})
(O/'reviewed33-body-map.json').write_text(json.dumps(rows,indent=2)+'\n')
# Preserve the exact structural and observer boundaries; do not call symbols allocations.
P=R/'.build/contracts/p08-native-cold-static-screen-candidate1-prepared';prior=json.loads((P/'manifest.json').read_text());comparison=[]
for copy,entry in prior['silent_copies'].items():
 source=Path(entry['source']);text=source.read_text();silent=Path(copy);assert sha(silent)==entry['sha256'];expected=text.replace('print(label, value)','// diagnostic trace-free control').replace('print("so06-reuse-\\(route)-\\(suffix)")','// diagnostic trace-free reuse label')
 comparison.append({'source':str(source),'current_sha256':sha(source),'original_manifest_source_sha256':prior['source_hashes'].get(str(source.relative_to(R))),'accepted_silent_source':copy,'accepted_silent_sha256':entry['sha256'],'exact_current_two_print_only_derivation_matches_accepted':expected==silent.read_text(),'derivation':'only counterTrace print(label,value) and p08ReuseLabel print string replaced by preserved comments; no algorithm/observer-window change'})
(O/'observer-comparison.json').write_text(json.dumps({'accepted_manifest_sha256':sha(P/'manifest.json'),'accepted_commands_sha256':sha(P/'commands.json'),'sources':comparison,'conclusion':'Ordinary traced object includes observer allocations. Metadata call is in the actual static session factory/defer path, but attribution to necessary framework operation versus compiler materialization induced by observation remains unresolved without the exact current silent shape. No strict allocation failure inferred. Independent physical missing-body/callee gate fails regardless of that attribution.'},indent=2)+'\n')
# All42 origins accounted for as scope/status, not invented PASS rows.
origins=json.loads(gzip.decompress((B/'native-cold-pipeline-design/emitted-map.json.gz').read_bytes()));countersha={};compiled=json.loads((R/'.build/contracts/p08-grouped-module-closure-initial1-registered/result.json').read_text());allsource={}
for st in compiled['stages']:allsource.update(st.get('source_sha256',{}))
first=json.loads((R/'.build/contracts/p08-grouped-module-closure-initial1/result.json').read_text())
for st in first['checks']:
 if st['status']=='passed':allsource.update(st.get('source_sha256',{}))
originrows=[]
for source in origins['source_hashes']:
 p=R/source;h=sha(p);assert allsource.get(str(p))==h or source.endswith('RuntimeDerived/Counter.swift'),source
 matches=[r for r in rows if r['source']==source]
 originrows.append({'source':source,'current_sha256':h,'compile_qualification':'registered fresh closure input; authored Counter is lowerer input','reviewed_attribute_sites':len(matches),'physical_note':'see reviewed33-body-map' if matches else 'not independently fully qualified after early callee gate failure','codegen_status':'BLOCKED by required missing body/callee closure; not a PASS claim'})
assert len(originrows)==42;(O/'origin42-status.json').write_text(json.dumps(originrows,indent=2)+'\n')
summary={'status':'physical body/callee gate FAIL; metadata/observer attribution unresolved; runtime STOP','source':'b89c4fac unchanged; initial1/1 frozen; corrections0/2','physical_modules':{m:d['entry_count'] for m,d in I.items()},'verified_function_records':sum(d['entry_count'] for d in I.values()),'current_host_object_sha256':sha(R/'.build/contracts/p08-grouped-module-closure-initial1-registered/owners/P08CounterRuntime/P08CounterRuntime.o'),'body_map_sites':len(rows),'origin_count':42,'stopped_before':['fresh privacy/lifetime compiler controls','actualhost optimized SIL','complete private callee closure','safety/runtime','strict host-first cold/reuse','broader profiles/images'],'no_allocation_conformance_claim':True}
(O/'grouped-result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print('observer-copy exact current matches',[(r['source'].split('/')[-1],r['exact_current_two_print_only_derivation_matches_accepted']) for r in comparison]);print('33site matches',collections.Counter(r['status'] for r in rows))
