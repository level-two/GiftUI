from pathlib import Path
import codecs,json,re,struct,subprocess
R=Path.cwd();O=R/'.build/contracts/p08-grouped-module-closure-codegen';prepared=json.loads((O/'boundaries-decode-prepared.json').read_text());demangler=R/'.toolchains/host/swift-6.4.0-RELEASE-osx/usr/bin/swift-demangle';results={}
for module,argv in prepared['commands'].items():
 lines=(O/(module+'-decode.stdout')).read_text().splitlines();data=Path(argv[-1]).read_bytes()
 def rec(n):return next(x for x in lines if x.strip().startswith('<'+n+' '))
 def ops(n):return list(map(int,re.findall(r'op\d+=(\d+)',rec(n))))
 def blob(n):return codecs.decode(rec(n).split("blob data = '",1)[1][:-1],'unicode_escape').encode('latin1')
 strings=blob('IDENTIFIER_DATA');names={i+6:strings[o:strings.index(0,o)].decode() for i,o in enumerate(ops('IDENTIFIER_OFFSETS'))};table=blob('SIL_FUNC_NAMES');off=ops('SIL_FUNC_NAMES')[0];bcount,ecount=struct.unpack_from('<II',table,off);buckets=struct.unpack_from('<'+'I'*bcount,table,off+8);entries=[]
 for o in buckets:
  if not o:continue
  count=struct.unpack_from('<H',table,o)[0];o+=2
  for _ in range(count):
   h,k,v=struct.unpack_from('<III',table,o);o+=12;expected=5381
   for b in names[k].encode():expected=(expected*33+b)&0xffffffff
   assert h==expected;entries.append({'name':names[k],'identifier_id':k,'function_id':v,'hash':h})
 assert len(entries)==ecount;assert sorted(e['function_id'] for e in entries)==list(range(1,ecount+1));offsets=ops('SIL_FUNC_OFFSETS');records=[(i,x) for i,x in enumerate(lines) if x.strip().startswith('<SIL_FUNCTION ')];assert len(records)==len(offsets)==ecount
 demangled=subprocess.check_output([str(demangler),'--compact'],input=('\n'.join(e['name'] for e in entries)+'\n').encode()).decode().splitlines();assert len(demangled)==len(entries)
 for row,demangle in zip(entries,demangled):
  fid=row['function_id'];start,header=records[fid-1];stop=records[fid][0] if fid<ecount else next(i for i in range(start+1,len(lines)) if '</SIL_BLOCK>' in lines[i]);values=list(map(int,re.findall(r'op\d+=(\d+)',header)));offset=offsets[fid-1];prefix=[];pos=offset
  for width in (6,4,1,2,3,1,3,2):prefix.append(sum(((data[(pos+i)//8]>>((pos+i)%8))&1)<<i for i in range(width)));pos+=width
  assert prefix==[4]+values[:7],(module,row['name'],prefix,values[:7])
  row.update(demangled=demangle,offset_bits=offset,linkage=values[0],serialized_kind=values[2],inline_strategy=values[6],basic_blocks=sum('<SIL_BASIC_BLOCK ' in x for x in lines[start+1:stop]),raw_prefix=prefix,record=header.strip())
 results[module]={'metadata_version':ops('METADATA')[:2],'entry_count':ecount,'functions':sorted(entries,key=lambda e:e['function_id'])};assert results[module]['metadata_version']==[0,1003]
 print(module,ecount,'all-index/hash/offset/rawprefixPASS')
(O/'boundary-physical-index.json').write_text(json.dumps(results,indent=2)+'\n')
for module,d in results.items():
 for e in d['functions']:
  if any(m in e['demangled'] for m in ('SignalAnalyzerPresetHostInstance<','withCanvasStagedValues','RuntimeRecordInteractionBridge.dispatch','ObservableCanvasInvocationSource','publishLayout')) and not any(m in e['demangled'] for m in ('getter','setter','allocator','initializer','deallocator','destroyer')):
   print(module,e['function_id'],e['serialized_kind'],e['basic_blocks'],e['demangled'][:210])
