import sys
sys.dont_write_bytecode=True
import pathlib,importlib.util,json,re,bisect,collections,subprocess
root=pathlib.Path('/Users/eugene/work/GiftUI');out=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('facts',root/'scripts/contracts/p08_layout_facts.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=out.parent/'firmware/zephyr/zephyr.elf';e=m.ELF(p.read_bytes())
functions={}
for s in e.symbols:
    if s['type']==2 and s['size'] and 0<s['owner']<len(e.sections) and e.sections[s['owner']]['flags']&4:
        a=s['value']&~1
        if a in functions:
            assert functions[a]['size']==s['size'],(a,functions[a]['size'],s['size'])
            functions[a]['aliases'].append(s)
        else:functions[a]=dict(address=a,size=s['size'],aliases=[s],instructions=[],direct=[],indirect=[],sp_writes=[])
starts=sorted(functions)
mapping=sorted(set((s['value']&~1,s['name']) for s in e.symbols if s['name'] in ('$t','$d') and 0<s['owner']<len(e.sections) and e.sections[s['owner']]['flags']&4))
for j,(a,kind) in enumerate(mapping):
    prev=bisect.bisect_right(starts,a)-1
    if kind!='$t' or prev>=0 and a<starts[prev]+functions[starts[prev]]['size']:continue
    end=mapping[j+1][0] if j+1<len(mapping) else a
    if end>a:functions[a]=dict(address=a,size=end-a,aliases=[dict(name='$t unnamed code block',index=None)],instructions=[],direct=[],indirect=[],sp_writes=[])
starts=sorted(functions)
for line in (out/'all-linked-disassembly.txt').read_text().splitlines():
    q=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{4}\s+)+(.+)',line)
    if not q:continue
    a=int(q[1],16);i=bisect.bisect_right(starts,a)-1
    if i<0:continue
    f=functions[starts[i]]
    if a>=f['address']+f['size']:continue
    ins=q[2].strip();f['instructions'].append([a,ins])
    d=re.match(r'(bl(?:\.w)?|b(?:eq|ne|cs|cc|hs|lo|mi|pl|vs|vc|hi|ls|ge|lt|gt|le)?(?:\.[nw])?)\s+([0-9a-f]+)\s',ins)
    if d:
        target=int(d[2],16)
        if d[1] in ('bl','bl.w') or not f['address']<=target<f['address']+f['size']:
            f['direct'].append(dict(site=a,instruction=ins,target=target,defined=target in functions))
    elif re.match(r'(blx|bx)\s+(?!lr\b)',ins) or re.match(r'(ldr|mov)(?:\.w)?\s+pc\b',ins):
        f['indirect'].append([a,ins])
    if re.match(r'(push|pop|vpush|vpop)\b',ins) or re.match(r'(stmdb|ldmia)(?:\.w)?\s+sp!',ins) or re.match(r'(?:subw?|addw?|mov|ldr|bic|bfc|and)(?:\w*\.w)?\s+sp,',ins) or re.search(r'\[sp,.*\]!',ins):
        f['sp_writes'].append([a,ins])
roots={}
for a,f in functions.items():
    for s in f['aliases']:
        if s['name'] in ['main','giftui_rfc014_counter_entry','z_cstart','z_arm_prep_c','_isr_wrapper','_isr_wrapper_with_main_stack','z_arm_reset']:
            roots[s['name']]=a
def reachable(start):
    seen={start};todo=[start];parents={start:None}
    while todo:
        a=todo.pop()
        for edge in functions[a]['direct']:
            b=edge['target']
            if b in functions and b not in seen:seen.add(b);todo.append(b);parents[b]=a
    return seen,parents
summaries={}
for name,a in roots.items():
    reachable_set,parents=reachable(a)
    summaries[name]=dict(address=a,direct_reachable_count=len(reachable_set),indirect_sites=sum(len(functions[b]['indirect']) for b in reachable_set),register_sp_functions=[b for b in reachable_set if any(re.match(r'(mov|ldr)\s+sp,',ins) for _,ins in functions[b]['sp_writes'])],undefined_direct=[dict(caller=b,**v) for b in reachable_set for v in functions[b]['direct'] if not v['defined']])
    if name=='main':
        (out/'main-direct-parents.json').write_text(json.dumps({str(k):v for k,v in parents.items()},indent=2)+'\n')
(out/'graph.json').write_text(json.dumps(dict(functions={str(k):v for k,v in functions.items()},roots=roots,summaries=summaries),indent=2)+'\n')
print('physical functions',len(functions),'instructions',sum(len(f['instructions']) for f in functions.values()),'indirect sites',sum(len(f['indirect']) for f in functions.values()))
for name,s in summaries.items():print(name,hex(s['address']),'direct reachable',s['direct_reachable_count'],'indirect',s['indirect_sites'],'registerSPfuncs',len(s['register_sp_functions']),'undefineddirect',len(s['undefined_direct']))
