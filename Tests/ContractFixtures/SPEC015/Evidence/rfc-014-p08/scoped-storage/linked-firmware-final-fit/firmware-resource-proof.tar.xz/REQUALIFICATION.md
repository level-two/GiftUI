# New image proof and address audit

This packet certifies only ELF0e54fe25ce637f5dd116b1094f64d7a46829a43351465abae265d4ebe61f02f5
under the frozen finite source, not arbitrary external callbacks or corrupted
records. Run python3 reproduce.py after extraction on the pinned repository host.
It verifies packet/tool/source hashes, regenerates disassembly/names/CFG/context/
SCC bounds, then reruns the executable address, writeback, source and RAM audit.
No compilation, application/firmware execution or hardware is involved. The old
committed e649 image/complete-proof/corrected-review packets are explicit inputs;
none is overwritten and the older 66ca image is not used.

All2,600 executable ranges (including uncovered $t blocks), alias sets, sizes,
addresses and regenerated names map identically. Every address integer and decimal
site string in the phase/rank/SP scripts is inventoried or covered by exact graph
site identity; the address-map is explicit, not a uniform-offset assumption.
The complete initialized allocated-byte comparison permits exactly nine aligned
word changes: vector initial MSP; two reset MOV encodings for ISR2112→8256; reset
MSP literal; main guard-start/usable-start pointers; new main PSP top; z_cstart
interrupt MSP top; static_regions MPU pointer. No other initialized allocated byte
changes. RAM object comparison changes only z_interrupt_stacks and z_main_stack.
Only two canonical instructions change, at0x2d2a6/0x2d2b0; stack effects do not.
Disassembly annotation differences caused by absolute size symbols are ignored
only after numeric instruction operands/bytes are checked.

Fresh bindings cover manual callback/phase target sets, decimal274756/274774 and
183344 sites, composite outlined sites, all roots, all rank/same-helper and loan
entries, code-as-data delay bytes, witness slots6249c/62498, init/device/ISR tables,
UART epilogue, nonreturn allocators and hidden mutable error-cache words. Cache
context2000000c and its once byte20000380 remain initially zero; the release's
only direct caller is allocError. Runtime code and all .data bytes are unchanged;
the reviewed clear-before-release/no-context-install source premise still holds.
posix_memalign remains ENOMEM without writing output; allocObject initializes nil
and reaches UDF before returning. No successful heap bytes or hidden returning
allocation/destructor continuation is assumed. Fatal boxed errors are terminal,
not credited as successful typed refusals.

All227 Swift hashes,24 owners/imports, compiler/macro identities and341 compile
commands exactly equal the prior qualified image. All291 current proof source
hashes match their new packet snapshots;339 distinct actual compiler input files
are preserved. The only Kconfig differences are main27648→106496 and ISR2048→8192.
Source predicates excluding empty GPIO callbacks, unproduced kernel timeouts,
spinwait-only onoff notification, absent onoff monitors and nil error-cache
release are unchanged. The new graph's every edge, retained call-site SP, local
maximum and source-pruned site matches the independently corrected old graph.

The14 original loans and nonnested second owner, semantic depth24 plus the whole
screen's4 modifiers, acyclic same-identity helper edges and two-active onoff rule
are retained source constraints. All feasible cold/live/current/stale/refusal/
injected failure/cleanup branches remain conservatively covered, with all required
capacities/observations. Parentheses in indirect target families are not used to
choose smaller variants. Main software95349 plus persistent caller8 plus first
basic/lazy-FP/alignment112 =95469. Eight configurable priority levels plus HardFault
and NMI each use conservative software524 + hardware/FPU112; startup312 gives
ISR6672. UART's15-byte epilogue assertion and corrected division-helper retained
SP16 are freshly checked. No reachable unknown SP/edge remains.

Startup MSP initially lies in main storage, then PSP uses temporary interrupt
storage; z_cstart installs interrupt MSP and switch-to-main resets main PSP. The
312-byte pre-switch bound does not enclose main after that reset. Early main-MSP
startup/fatal nesting, even conservatively charging startup+ten frames and the
64 bytes below the initial top, needs at most6736, below95469. Interrupt masking
and terminal early-fatal behavior are unchanged; no resuming corruption is
assumed. The new reset clears8256 bytes and selects0x20024640, exactly the enlarged
ISR object's top. Main PSP0x2003e680 matches main payload end; guard64 is retained.

The fresh inventory has1752 writeback sites, all canonically identical to the old
image and covered by the corrected decoder. Exact memory-base classification
finds403 non-SP, not the old review's418 label; this narrow count erratum has zero
instruction, closure, frame or numerical-bound effect. The per-site/base inventory
is authoritative here; the immutable old review is preserved. No LDM writeback
base is in its loaded-register list.

Actual RAM LOADs charge255612 with extent255616, ending0x2003e680; both fit262144
physical. Main106560 and ISR8256 include their64-byte guards, are contiguous and
end inside that range. Remove only payloads106496/8192: other RAM140924. Main/ISR
margins11027/1520; physical charge/address margins6532/6528. All four34720 donors
remain138880; metadata16584 stays within its donor. Flash403400 remains under
1048576; ARMv7E-M hard-float,160 strict layout roots and configured zero arenas
remain actual-image checks, with rooted allocation additionally audited above.

The pristine build/doctor wrappers and755-file preservation manifest are archived
as provenance. Counter collectionyq7m79g3 stays227/227 complete, without a rerun;
its reused runtime/host compiled=false/original_manifest_current=false
qualifications remain explicit. Four external working-tree changes (two analyzer
Swift files, post-counter-return CMake edits, empty-array shell expansion) are
preserved and excluded from agent source edits. Build status records identify
them; no normal analyzer build or fit is claimed. P08 overall remains open for
remaining matrix/SO and independent exit review; later/connected gates stay separate.
