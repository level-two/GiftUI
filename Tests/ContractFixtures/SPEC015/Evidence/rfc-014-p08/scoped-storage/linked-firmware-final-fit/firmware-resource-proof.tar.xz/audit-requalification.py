"""Source/address/stack/RAM proof for one frozen rebuilt image; never builds/runs firmware."""
import ast,collections,hashlib,importlib.util,json,lzma,pathlib,re,struct,sys,tarfile
sys.dont_write_bytecode=True
p=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/Users/eugene/work/GiftUI');evidence=root/'Tests/ContractFixtures/SPEC015/Evidence/rfc-014-p08/scoped-storage'
hashof=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert hashof(p/'firmware/zephyr/zephyr.elf')=='0e54fe25ce637f5dd116b1094f64d7a46829a43351465abae265d4ebe61f02f5'
spec=importlib.util.spec_from_file_location('facts',root/'scripts/contracts/p08_layout_facts.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
oldarchive=evidence/'linked-firmware-current/resource-proof.tar.xz';assert hashof(oldarchive)=='8db18ea94b5c9b1ad41b64759617cd7cb75c4bd5e57e9c7014a36cb56d7f1fdc'
with tarfile.open(oldarchive) as t:
 oldelfbytes=t.extractfile('firmware/zephyr/zephyr.elf').read();oldconfig=t.extractfile('firmware/zephyr/.config').read().decode();oldcommands=json.load(t.extractfile('firmware/compile_commands.json'));oldhandoff=json.load(t.extractfile('receipts/current-source-handoff.json'))
assert hashlib.sha256(oldelfbytes).hexdigest()=='e649c5d26a676140b473e8fa1de5b075a479d8282a7f6d69e0034fb215884c38'
old,new=M.ELF(oldelfbytes),M.ELF((p/'firmware/zephyr/zephyr.elf').read_bytes())
def mem(e,a,n):
 for sec in e.sections:
  if sec['flags']&2 and sec['address']<=a and a+n<=sec['address']+sec['size']:
   return bytes(n) if sec['type']==8 else e.section_data(sec)[a-sec['address']:a-sec['address']+n]
 raise AssertionError(('address not allocated',hex(a),n))
word=lambda e,a:struct.unpack('<I',mem(e,a,4))[0]
# Complete initialized allocated-byte differences; no changed code/data is ignored.
expected={0:(0x20029a40,0x2003e640),0x2d2a8:(0xf0306204,0xf0305201),0x2d2b0:(0x6104f44f,0x5101f44f),0x2d2d0:(0x20029a40,0x2003e640),0x2d428:(0x20022e40,0x20024640),0x2d42c:(0x20022e80,0x20024680),0x2d460:(0x20029a80,0x2003e680),0x3068c:(0x20022e40,0x20024640),0x61c48:(0x20022e40,0x20024640)}
deltas={};section_deltas=[]
assert len(old.sections)==len(new.sections)
for a,b in zip(old.sections,new.sections):
 assert (a['name'],a['type'],a['flags'],a['address'])==(b['name'],b['type'],b['flags'],b['address']),a['name']
 if a['flags']&2:
  if a['type']==8:
   if a['size']!=b['size']:section_deltas.append((a['name'],a['size'],b['size']))
  else:
   assert a['size']==b['size'],a['name'];x,y=old.section_data(a),new.section_data(b)
   for off in {i//4*4 for i,(u,v) in enumerate(zip(x,y)) if u!=v}:
    addr=a['address']+off;deltas[addr]=(word(old,addr),word(new,addr))
assert deltas==expected,deltas
assert section_deltas==[('noinit',29824,114816)]
# No hidden object relocation: only the two stack objects change.
def objects(e):return {s['name']:s for s in e.symbols if s['type']==1 and s['size'] and 0x20000000<=s['value']<0x20040000}
a,b=objects(old),objects(new);assert set(a)==set(b)
assert {n for n in a if (a[n]['value'],a[n]['size'])!=(b[n]['value'],b[n]['size'])}=={'z_main_stack','z_interrupt_stacks'}
assert (b['z_main_stack']['value'],b['z_main_stack']['size'])==(0x20024640,106560)
assert (b['z_interrupt_stacks']['value'],b['z_interrupt_stacks']['size'])==(0x20022600,8256)
# Identity rebasing is proved for every sized function AND uncovered executable $t block.
base=evidence/'linked-firmware-complete-bound/complete-bound-proof.tar.xz';assert hashof(base)=='44aff7957b6be3fdef318520c2531b0c63342a113472ffa0ff9815df18363e94'
with tarfile.open(base) as t:og=json.load(t.extractfile('graph.json'));on=json.load(t.extractfile('names.json'))
with tarfile.open(base) as t:
 for name in ['phase_graph.py','cycles.py','bounded.py']:assert (p/'analysis'/name).read_bytes()==t.extractfile(name).read(),name
ng=json.loads((p/'analysis/graph.json').read_text());nn=json.loads((p/'analysis/names.json').read_text());assert ng['roots']==og['roots'] and set(ng['functions'])==set(og['functions']) and nn==on
norm=lambda x:x.split(';')[0].split('<')[0].strip()
instructions=[];address_map=[]
for key,nf in ng['functions'].items():
 of=og['functions'][key];assert nf['size']==of['size'] and [s['name'] for s in nf['aliases']]==[s['name'] for s in of['aliases']]
 assert len(nf['instructions'])==len(of['instructions'])
 for x,y in zip(of['instructions'],nf['instructions']):
  assert x[0]==y[0]
  if norm(x[1])!=norm(y[1]):instructions.append((x[0],norm(x[1]),norm(y[1])))
 address_map.append(dict(old=int(key),new=int(key),size=nf['size'],aliases=[s['name'] for s in nf['aliases']]))
assert instructions==[(0x2d2a6,'mov.w\tr2, #2112','mov.w\tr2, #8256'),(0x2d2b0,'mov.w\tr1, #2112','mov.w\tr1, #8256')]
# Decoder is the independently corrected implementation, changed only to read packet ELF.
corrected=(evidence/'linked-firmware-complete-bound-review/local_sp.py').read_text()
assert (p/'analysis/local_sp.py').read_text().replace("(out.parent/'firmware/zephyr/zephyr.elf')","(root/'.build/nrf52840/signal-analyzer-static/rfc014-counter-firmware/zephyr/zephyr.elf')")==corrected
G=json.loads((p/'analysis/phase-graph.json').read_text());C=G['contexts'];oldG=json.loads(lzma.decompress((evidence/'linked-firmware-complete-bound-review/phase-graph.json.xz').read_bytes()))
assert len(C)==1788 and len({c['address'] for c in C.values()})==1469 and set(C)==set(oldG['contexts']) and not G['remaining_queue']
for k,c in C.items():
 oc=oldG['contexts'][k];assert c['edges']==oc['edges'] and c['analysis']['local_upper']==oc['analysis']['local_upper'] and c.get('source_pruned')==oc.get('source_pruned')
 assert c['analysis']['complete'] and not c['unresolved']
 assert all(e['target'] for e in c['edges'])
 assert all(q['target'] in set(map(int,ng['functions']))|{0x61950} for q in c['analysis']['calls'].values() if not q['indirect'])
# Audit every embedded address integer/decimal-string in phase/rank/local-SP scripts.
# All code addresses map by the complete range/byte proof above; non-address numeric
# constants (masks, budgets and opcodes) are catalogued separately, never rebased.
constants={}
for name in ['phase_graph.py','bounded.py','local_sp.py']:
 tree=ast.parse((p/'analysis'/name).read_text())
 for node in ast.walk(tree):
  if isinstance(node,ast.Constant):
   vs=[node.value] if isinstance(node.value,int) and not isinstance(node.value,bool) else [int(node.value)] if isinstance(node.value,str) and node.value.isdigit() else []
   if isinstance(node.value,str):vs += [int(x,16) for x in re.findall(r'0x([0-9a-fA-F]+)',node.value)]
   for v in vs:
    if v>=256:constants.setdefault(v,[]).append(f'{name}:{node.lineno}')
catalog=[]
for v,locations in sorted(constants.items()):
 owners=[(int(k),f) for k,f in ng['functions'].items() if int(k)<=v<int(k)+f['size']]
 if owners:
  owner,f=owners[0];assert mem(old,v,min(2,owner+f['size']-v))==mem(new,v,min(2,owner+f['size']-v));kind='unchanged executable address'
 elif v==0x61950:assert mem(old,v,6)==mem(new,v,6)==bytes.fromhex('0338fdd87047');kind='unchanged rodata delay code'
 else:kind='numeric constant (not an embedded code address)'
 catalog.append(dict(value=v,kind=kind,locations=locations))
# Specific data tables/cache and roots have fresh executable bindings, not just SHA substitution.
assert mem(old,0x5ef50,0x48)==mem(new,0x5ef50,0x48) # init entries
assert mem(old,0x5ef98,0xc0)==mem(new,0x5ef98,0xc0) # device records
assert mem(old,0x5f058,48*8)==mem(new,0x5f058,48*8) # generated ISR dispatch
assert word(new,0x6249c)==0x405 and word(new,0x62498)==0x31a7f
assert word(new,0x2000000c)==0 and mem(new,0x20000380,1)==b'\0'
assert mem(old,0x20000008,8)==mem(new,0x20000008,8) # hidden error-destroy code/context
assert [norm(i) for _,i in ng['functions'][str(0x5ddb2)]['instructions']]==['movs\tr0, #12','bx\tlr']
assert {int(k) for k,f in ng['functions'].items() if any(e['target']==0x31a80 for e in f['direct'])}=={0x414}
assert not {'malloc','calloc','realloc','aligned_alloc','k_malloc','k_calloc','k_realloc'}&{s['name'] for s in new.symbols}
# Full reachable writeback coverage retains the independently reviewed forms.
writebacks=[];nonsp=0
for a in {c['address'] for c in C.values()}:
 if str(a) not in ng['functions']:continue
 for site,raw in ng['functions'][str(a)]['instructions']:
  ins=norm(raw)
  if re.match(r'(?:ldm|stm)',ins) and '!' in ins:
   base=ins.split(None,1)[1].split(',')[0].rstrip('!');loaded=re.search(r'\{([^}]+)\}',ins)[1].split(', ')
   assert not ins.startswith('ldm') or base not in loaded
  elif re.match(r'(?:ldr|str)(?:d|b|h)?(?:\.w)?\s',ins) and ('!' in ins or re.search(r'\],\s*#',ins)):
   base=re.search(r'\[([^,\]]+)',ins)[1]
  else:continue
  assert norm(dict(og['functions'][str(a)]['instructions'])[site])==ins
  nonsp += base!='sp';writebacks.append(dict(function=a,site=site,instruction=ins,base=base))
assert len(writebacks)==1752 and nonsp==403,(len(writebacks),nonsp,collections.Counter(x["base"] for x in writebacks))
assert all(c['analysis']['local_upper']==16 and c['analysis']['calls']['336']['sp'][1]==-16 for c in C.values() if c['address']==0x130)
# Source/config and build command applicability.
oldcfg=dict(x.split('=',1) for x in oldconfig.splitlines() if x.startswith('CONFIG_'))
newconfig=(p/'firmware/zephyr/.config').read_text();cfg=dict(x.split('=',1) for x in newconfig.splitlines() if x.startswith('CONFIG_'))
assert {k:(oldcfg.get(k),cfg.get(k)) for k in oldcfg.keys()|cfg.keys() if oldcfg.get(k)!=cfg.get(k)}=={'CONFIG_MAIN_STACK_SIZE':('27648','106496'),'CONFIG_ISR_STACK_SIZE':('2048','8192')}
for k,v in {'CONFIG_FPU':'y','CONFIG_MPU_STACK_GUARD':'y','CONFIG_HEAP_MEM_POOL_SIZE':'0','CONFIG_COMMON_LIBC_MALLOC_ARENA_SIZE':'0'}.items():assert cfg[k]==v
assert '# CONFIG_MULTITHREADING is not set' in newconfig and '# CONFIG_ZERO_LATENCY_IRQS is not set' in newconfig and '# CONFIG_DYNAMIC_INTERRUPTS is not set' in newconfig
handoff=json.loads((p/'handoff/input-receipt.json').read_text());assert len(handoff['source_hashes'])==227 and len(handoff['owners'])==24
for key in ['source_hashes','owners','imports','compiler_sha256','macro_tool_sha256']:assert handoff[key]==oldhandoff[key],key
assert oldcommands==json.loads((p/'firmware/compile_commands.json').read_text())
for name,h in json.loads((p/'source-hashes.json').read_text()).items():assert hashof(p/'inputs'/name)==h and hashof(root/name)==h,name
for name,h in json.loads((p/'compiler-source-hashes.json').read_text()).items():assert hashof(p/'compiler-inputs'/name)==h,name
# Actual ELF charge, extent, guard/alignment and bounds.
data=(p/'firmware/zephyr/zephyr.elf').read_bytes();phoff=struct.unpack_from('<I',data,28)[0];sz,num=struct.unpack_from('<HH',data,42);loads=[]
for i in range(num):
 row=struct.unpack_from('<IIIIIIII',data,phoff+i*sz)
 if row[0]==1:loads.append(row)
ram=[r for r in loads if 0x20000000<=r[2]<0x30000000];charge=sum(r[5] for r in ram);flash=sum(r[4] for r in loads);low=min(r[2] for r in ram);end=max(r[2]+r[5] for r in ram)
assert (charge,flash,low,end)==(255612,403400,0x20000000,0x2003e680)
assert charge<=262144 and end<=0x20040000 and end-low==255616
assert b['z_interrupt_stacks']['value']+b['z_interrupt_stacks']['size']==b['z_main_stack']['value']
assert b['z_main_stack']['value']+b['z_main_stack']['size']==end
assert charge-106496-8192==140924 and 106560-106496==8256-8192==64
sys.path.insert(0,str(p/'analysis'));import bounded
assert bounded.bound(G['root'])[0]==95349 and bounded.bound(G['extra_roots']['0x305f4'])[0]==95357
assert bounded.bound(G['extra_roots']['0x2d3a8'],startup=True)[0]==312
assert bounded.bound(G['extra_roots']['0x2d27c'])[0]==524 and bounded.bound(G['extra_roots']['0x2d488'])[0]==444
facts=json.loads((p/'firmware/reports/so08-layout-and-c-reservation.json').read_text())
assert facts['artifact_sha256']==hashof(p/'firmware/zephyr/zephyr.elf') and facts['map_sha256']==hashof(p/'firmware/zephyr/zephyr.map')
assert len(facts['values'])==160 and facts['reservation']['retained_bytes']==138880 and facts['values']['giftui_p08_metadata_extent']==16584 and facts['metadata_layout']['additional_retained_bytes']==0
receipt=json.loads((p/'receipts/complete-counter-result.json').read_text());assert receipt['collection_complete'] and receipt['passed'] and len(receipt['checks'])==227 and all(c['passed'] for c in receipt['checks'])
assert hashof(p/'receipts/complete-counter-result.json')==handoff['counter_receipt_sha256']
summary=dict(status='current-image-resource-pass-subject-to-independent-review',elf_sha256=hashof(p/'firmware/zephyr/zephyr.elf'),main_bound=95469,isr_bound=6672,main_payload=106496,isr_payload=8192,ram_charge=charge,ram_extent=end-low,physical_ram=262144,flash=flash,contexts=len(C),physical_functions=1469,writeback_sites=len(writebacks),non_sp_writebacks=nonsp,unresolved_calls=0,unknown_local_sp=0,code_ranges=len(ng['functions']),changed_allocated_words=len(deltas),swift_sources=227,owners=24,compiler_commands=len(oldcommands),rooted_successful_heap_bytes=0)
for name,value in [('current-resource-summary.json',summary),('address-map.json',address_map),('embedded-address-catalog.json',catalog),('reachable-writebacks.json',writebacks)]: (p/name).write_text(json.dumps(value,indent=2)+'\n')
print('PASS new ELF: main95469/106496, ISR6672/8192, RAM255612/262144, extent255616, flash403400; source-constrained proof complete')
