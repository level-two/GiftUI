import BankLayoutProbe
@main struct Main { static func main() { let count = giftuiP05Layout() + giftuiP05LayoutOracle(); print("P05 Layout assertions=\(count) failures=0") } }
