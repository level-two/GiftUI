import GiftUI
let key = _GiftUIModelKey<UInt8>(ownerInstance: 1, allocationGeneration: 1, slot: 0)
