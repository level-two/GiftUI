import GiftUI
        @ViewBuilder func excess() -> some View {
            Text<_GiftUIEmptyReadDomain>("a"); Text<_GiftUIEmptyReadDomain>("b")
            Text<_GiftUIEmptyReadDomain>("c"); Text<_GiftUIEmptyReadDomain>("d")
            Text<_GiftUIEmptyReadDomain>("e"); Text<_GiftUIEmptyReadDomain>("f")
        }
    