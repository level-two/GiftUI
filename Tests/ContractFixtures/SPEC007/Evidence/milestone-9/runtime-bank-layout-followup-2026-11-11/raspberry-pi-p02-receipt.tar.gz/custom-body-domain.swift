import GiftUI
        enum A: _GiftUIReadDomain { typealias Slot = UInt8 }
        enum B: _GiftUIReadDomain { typealias Slot = UInt8 }
        struct Wrong: View {
            typealias Domain = A
            func _giftUIEvaluate(read: borrowing _GiftUIFrameRead<A>) throws(_GiftUIAccessFailure) -> some View<B> { Text<B>("wrong") }
        }
    