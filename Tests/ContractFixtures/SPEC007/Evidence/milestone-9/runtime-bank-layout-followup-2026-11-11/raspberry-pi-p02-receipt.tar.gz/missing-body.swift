import GiftUI
        struct Missing: View { typealias Domain = _GiftUIEmptyReadDomain }
    