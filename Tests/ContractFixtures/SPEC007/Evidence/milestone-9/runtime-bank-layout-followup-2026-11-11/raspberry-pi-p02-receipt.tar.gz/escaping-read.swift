import GiftUI
        func escape<D: _GiftUIReadDomain>(_ read: borrowing _GiftUIFrameRead<D>) -> () -> D.Slot {
            { read.slots[0] }
        }
    