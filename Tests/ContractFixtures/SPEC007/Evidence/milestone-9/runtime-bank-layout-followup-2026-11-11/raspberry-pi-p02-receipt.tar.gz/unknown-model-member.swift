import GiftUI
struct Bad: View { let model: CounterModel; var body: some View {
model.service
Text("bad")
} }
