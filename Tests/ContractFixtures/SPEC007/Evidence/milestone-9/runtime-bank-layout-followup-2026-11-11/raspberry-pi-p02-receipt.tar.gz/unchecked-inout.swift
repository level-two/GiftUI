import GiftUI
struct Bad: View { let model: CounterModel; var body: some View {
Text(&value)
Text("bad")
} }
