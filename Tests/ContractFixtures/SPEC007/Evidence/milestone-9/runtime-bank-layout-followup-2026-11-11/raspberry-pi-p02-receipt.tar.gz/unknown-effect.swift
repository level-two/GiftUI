import GiftUI
struct Bad: View { let model: CounterModel; var body: some View {
externalService.start()
Text("bad")
} }
