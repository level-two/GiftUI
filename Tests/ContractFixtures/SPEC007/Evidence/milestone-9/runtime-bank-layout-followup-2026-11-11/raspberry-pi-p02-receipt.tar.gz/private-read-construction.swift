import GiftUI
func make(_ slots: Span<UInt8>) { _ = _GiftUIFrameRead<_GiftUIEmptyReadDomain>(slots: slots) }
