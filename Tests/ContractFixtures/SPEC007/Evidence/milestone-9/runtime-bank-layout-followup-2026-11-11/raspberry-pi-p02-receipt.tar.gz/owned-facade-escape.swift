import GiftUI
        import CounterSchema
        package struct Escape<D: CounterReadDomain> { let read: CounterRead<D> }
    