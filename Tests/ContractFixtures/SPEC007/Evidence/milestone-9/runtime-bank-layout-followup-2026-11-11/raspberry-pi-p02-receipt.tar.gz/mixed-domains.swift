import GiftUI
        enum A: _GiftUIReadDomain { typealias Slot = UInt8 }
        enum B: _GiftUIReadDomain { typealias Slot = UInt8 }
        @ViewBuilder func mixed() -> some View { Text<A>("a"); Text<B>("b") }
    