import GiftUI
struct Bad: View { let model: CounterModel; var body: some View {
externalService.frame()
Text("bad")
} }
